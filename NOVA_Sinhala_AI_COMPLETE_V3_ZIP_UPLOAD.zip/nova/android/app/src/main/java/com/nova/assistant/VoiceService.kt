package com.nova.assistant

import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.speech.*
import android.speech.tts.TextToSpeech
import androidx.core.app.NotificationCompat
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.*
import java.util.concurrent.CountDownLatch
import android.speech.tts.UtteranceProgressListener
import org.json.JSONArray
import org.json.JSONObject
import com.nova.assistant.ui.NovaState

/**
 * The real, persistent NOVA voice loop.
 * - Foreground service (android:stopWithTask="false") so it survives the app
 *   being swiped away from Recents, and keeps working with the screen off.
 * - Passively listens for a wake word ("Nova"/"නෝවා"). Once triggered, opens
 *   an "active session" window where the user can talk naturally without
 *   repeating the wake word each time.
 * - Sends recognized speech to the VPS backend's /chat endpoint, speaks the
 *   reply with TTS, and executes any device_actions the AI requested
 *   (open apps, WhatsApp, dialer, search, settings panels, UI taps).
 */
class VoiceService : Service(), TextToSpeech.OnInitListener {

    companion object {
        const val CHANNEL_ID = "nova_voice"
        const val NOTIF_ID = 7
        const val ACTION_STOP = "com.nova.assistant.action.STOP"
        private val WAKE_WORDS = listOf("nova", "නෝවා", "නොවා", "නෝව")
        private const val ACTIVE_SESSION_MS = 30 * 60_000L

        var instance: VoiceService? = null
            private set
    }

    private var sr: SpeechRecognizer? = null
    private lateinit var tts: TextToSpeech
    private var running = true
    private var activeSessionUntil = 0L
    private var autoContinueDepth = 0
    private var pendingTaskText: String? = null
    private var waitingForUnlock = false
    private var pendingNotification: Triple<String, String, String>? = null // app, title, text
    private var lastRate = 1.05f
    private var lastPitch = 1.0f
    private var ttsReady = false
    private var pendingActionResults = mutableListOf<String>()
    private val mainHandler = Handler(Looper.getMainLooper())

    private fun conversationId(): String {
        val p = getSharedPreferences("p", 0)
        var id = p.getString("conversation_id", null)
        if (id.isNullOrBlank()) {
            id = UUID.randomUUID().toString()
            p.edit().putString("conversation_id", id).apply()
        }
        return id
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        running = true
        NovaBus.isServiceRunning = true
        NovaBus.state = NovaState.IDLE
        NovaBus.lastError = ""

        tts = TextToSpeech(this, this)
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) {
                if (utteranceId == "nova-final" && running) mainHandler.post { listen() }
            }
            override fun onError(utteranceId: String?) {
                if (utteranceId == "nova-final" && running) mainHandler.post { listen() }
            }
        })

        val nm = getSystemService(NotificationManager::class.java)
        val channel = NotificationChannel(
            CHANNEL_ID, "Nova Voice Assistant", NotificationManager.IMPORTANCE_LOW
        ).apply { description = "Nova is listening in the background" }
        nm.createNotificationChannel(channel)

        startForeground(NOTIF_ID, buildNotification("Nova is active", "සූදානම්... 'Nova' කියලා කතාකරන්න"))
        listen()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    private fun buildNotification(title: String, text: String): Notification {
        val stopIntent = PendingIntent.getService(
            this, 0, Intent(this, VoiceService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val openIntent = PendingIntent.getActivity(
            this, 0, packageManager.getLaunchIntentForPackage(packageName),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .setContentIntent(openIntent)
            .addAction(0, "නවත්වන්න", stopIntent)
            .build()
    }

    private fun updateNotification(text: String) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(NOTIF_ID, buildNotification("Nova is active", text))
    }

    private fun isSessionActive() = System.currentTimeMillis() < activeSessionUntil

    private fun extendSession() {
        activeSessionUntil = System.currentTimeMillis() + ACTIVE_SESSION_MS
    }

    /** Called by NovaNotificationListener when a monitored app gets a new message. */
    fun announceIncoming(app: String, title: String, text: String) {
        if (!running) return
        mainHandler.post {
            if (NovaBus.state == NovaState.THINKING || NovaBus.state == NovaState.SPEAKING ||
                NovaBus.state == NovaState.EXECUTING
            ) return@post // don't interrupt something already in progress
            pendingNotification = Triple(app, title, text)
            extendSession()
            speak("ආ, $app එකෙන් $title reply එකක් දැම්මා. අහන්නද?")
        }
    }

    private fun stripWakeWord(raw: String): Pair<Boolean, String> {
        val lower = raw.lowercase(Locale.ROOT)
        for (w in WAKE_WORDS) {
            val idx = lower.indexOf(w)
            if (idx >= 0) {
                val rest = (raw.substring(0, idx) + raw.substring(idx + w.length)).trim()
                return true to rest
            }
        }
        return false to raw
    }

    private fun listen() {
        if (!running) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            NovaBus.state = NovaState.ERROR
            NovaBus.lastError = "Speech recognition මෙ device එකේ නෑ."
            return
        }
        NovaBus.state = NovaState.LISTENING
        updateNotification(if (isSessionActive()) "සවන් දෙනවා..." else "'Nova' කියලා කතාකරන්න")

        sr?.destroy()
        sr = SpeechRecognizer.createSpeechRecognizer(this)
        sr!!.setRecognitionListener(object : RecognitionListener {
            override fun onResults(r: Bundle) {
                val candidates = r.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
                val x = candidates.firstOrNull { it.isNotBlank() }
                if (x.isNullOrBlank()) {
                    if (running) mainHandler.postDelayed({ listen() }, 250)
                    return
                }

                val pending = pendingNotification
                if (pending != null) {
                    pendingNotification = null
                    val lower = x.lowercase(Locale.ROOT)
                    val yes = listOf("ඔව්", "ඔව", "අහන්නම්", "කියවන්න", "කියන්න", "yes", "read")
                    val no = listOf("එපා", "නෑ", "නැහැ", "no")
                    if (yes.any { lower.contains(it) }) {
                        NovaBus.transcript = x
                        speak("${pending.second} කිව්වේ — ${pending.third}")
                        return
                    } else if (no.any { lower.contains(it) }) {
                        speak("හරි.")
                        return
                    }
                    // else: not a yes/no — fall through and treat as a fresh command below
                }

                if (isSessionActive()) {
                    // Already in an active conversation: no wake word needed.
                    NovaBus.transcript = x
                    extendSession()
                    send(x)
                } else {
                    val (waked, rest) = stripWakeWord(x)
                    if (waked) {
                        extendSession()
                        if (rest.isBlank()) {
                            NovaBus.transcript = x
                            speak("මොකක්ද ඕන?")
                        } else {
                            NovaBus.transcript = rest
                            send(rest)
                        }
                    } else if (running) {
                        mainHandler.postDelayed({ listen() }, 220)
                    }
                }
            }
            override fun onError(e: Int) {
                if (running) mainHandler.postDelayed({ listen() }, 220)
            }
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(b: Bundle?) {}
            override fun onEvent(t: Int, p: Bundle?) {}
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "si-LK")
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "si-LK")
        i.putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, false)
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        try {
            sr!!.startListening(i)
        } catch (e: Exception) {
            if (running) mainHandler.postDelayed({ listen() }, 220)
        }
    }

    private fun hasOpenVerb(t: String): Boolean = listOf(
        "open", "launch", "start", "show", "go to",
        "ඔපන්", "ඕපන්", "ඇර", "අරින්න", "අරි", "යන්න", "පෙන්ව", "විවෘත"
    ).any { t.contains(it) }

    private fun tryLocalPhoneCommand(raw: String): Boolean {
        val original = raw.trim()
        val t = original.lowercase(Locale.ROOT)
        val svc = NovaAccessibilityService.instance
        val hasCompound = listOf("කරලා", "කරලා පස්සේ", "පස්සේ", "then", "after that", "and then", "ඊට පස්සේ", "and ").any { t.contains(it) }

        fun done(ok: Boolean, success: String, failure: String): Boolean {
            if (ok) {
                NovaBus.lastError = ""
                speak(success)
                return true
            }
            val km = getSystemService(Context.KEYGUARD_SERVICE) as android.app.KeyguardManager
            if (km.isKeyguardLocked) {
                NovaBus.lastError = "device_locked"
                speak("මට screen එක lock වෙලා තියෙන නිසා මෙතනින් එහාට යන්න බෑ. Phone එක unlock කරලා දෙන්න; ඊට පස්සේ මම මේ වැඩේම continue කරන්නම්.")
            } else if (NovaAccessibilityService.instance == null) {
                NovaBus.lastError = "accessibility_disabled"
                speak("Phone එක control කරන්න Accessibility permission එක ON කරලා දෙන්න. ඒක ON කළාම මම ආයෙම මේ වැඩේ කරගෙන යන්නම්.")
            } else {
                NovaBus.lastError = "phone_action_failed"
                speak(failure)
            }
            return true
        }

        // These deterministic commands deliberately stay on-device. They avoid
        // an unnecessary VPS round-trip for the most common controls and make
        // simple commands feel immediate even when the free AI provider is busy.
        if (t.matches(Regex(".*(back|go back|බැක්|ආපහු|පස්සට).*")) && !hasCompound) {
            return done(svc?.back() ?: false, "හරි, ආපහු ගියා.", "ආපහු යන්න බැරි වුණා.")
        }
        if (t.matches(Regex(".*(home|හෝම්|මුල් පිටුව).*")) && !hasCompound) {
            return done(svc?.home() ?: false, "හරි, Home එකට ගියා.", "Home එකට යන්න බැරි වුණා.")
        }
        if (t.matches(Regex(".*(recent apps|recents|recent|රීසන්ට්|අන්තිම ඇප්).*")) && !hasCompound) {
            return done(svc?.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_RECENTS) ?: false,
                "හරි, recent apps ඇරියා.", "Recent apps ඇරගන්න බැරි වුණා.")
        }
        if (t.matches(Regex(".*(quick settings|quick panel|ක්වික් සෙටින්|ක්වික් පැනල්).*")) && !hasCompound) {
            return done(svc?.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS) ?: false,
                "හරි, quick settings ඇරියා.", "Quick settings ඇරගන්න බැරි වුණා.")
        }
        if (t.matches(Regex(".*(notification|notifications|නොටිෆිකේෂන්|දැනුම්දීම්).*")) && !hasCompound) {
            return done(svc?.notifications() ?: false, "හරි, notifications ඇරියා.", "Notifications ඇරගන්න බැරි වුණා.")
        }

        if (t.contains("wifi") || t.contains("wi-fi") || t.contains("වයිෆයි") || t.contains("වයි-ෆයි")) {
            if (hasOpenVerb(t) || t.contains("go") || t.contains("ඇර") || t.contains("යන්න") || t.contains("පෙන්ව")) {
                return done(openIntentResult(Intent(Settings.ACTION_WIFI_SETTINGS)), "හරි, Wi-Fi settings ඇරියා.", "Wi-Fi settings ඇරගන්න බැරි වුණා.")
            }
        }
        if (t.contains("bluetooth") || t.contains("බ්ලූටූත්")) {
            if (hasOpenVerb(t) || t.contains("go") || t.contains("ඇර") || t.contains("යන්න") || t.contains("පෙන්ව")) {
                return done(openIntentResult(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)), "හරි, Bluetooth settings ඇරියා.", "Bluetooth settings ඇරගන්න බැරි වුණා.")
            }
        }
        // Fast local app navigation: common "open/go to <app>" commands are
        // executed directly on the phone instead of waiting for a VPS/model round-trip.
        // This keeps the human-like response fast while the full agent remains available
        // for everything that needs screen reasoning after the app opens.
        if (!hasCompound) {
            val appMatch = Regex(
                "^(?:open|launch|start|go to|show|ඔපන්|ඕපන්|අරින්න|අරි|ඇර|යන්න|යන්නකො|පෙන්ව)\\s+(.+)$",
                RegexOption.IGNORE_CASE
            ).find(original)
            if (appMatch != null) {
                val requested = appMatch.groupValues[1].trim()
                    .replace(Regex("\\s+(app|application)$", RegexOption.IGNORE_CASE), "")
                if (requested.isNotBlank() &&
                    !requested.lowercase(Locale.ROOT).contains("settings") &&
                    !requested.lowercase(Locale.ROOT).contains("සෙටින්")) {
                    val opened = openAppByName(requested)
                    if (opened) return done(true, "හරි, $requested ඇරියා.", "")
                }
            }
        }

        if (t.contains("settings") || t.contains("setting") || t.contains("සෙටින්") || t.contains("සෙටිං") || t.contains("සැකසුම්")) {
            if (!hasCompound && (hasOpenVerb(t) || t.contains("go") || t.contains("ඇර") || t.contains("අරි") || t.contains("යන්න") || t.contains("පෙන්ව") || t == "settings" || t == "සෙටින්" || t == "සැකසුම්")) {
                return done(openIntentResult(Intent(Settings.ACTION_SETTINGS)), "හරි, Settings ඇරියා.", "Settings ඇරගන්න බැරි වුණා.")
            }
        }

        // Read the current screen without sending the whole request to the VPS.
        if (!hasCompound && t.matches(Regex(".*(read|tell me what's on screen|read screen|screen read|කියව|ස්ක්‍රීන් එක කියව|තිබ්බෙ මොනවද|මොනවද තියෙන්නේ).*"))) {
            val items = svc?.screenSnapshot(18).orEmpty()
            if (items.isEmpty()) return done(false, "", "දැනට screen එකේ කියවන්න දෙයක් හම්බ වුණේ නෑ.")
            val spoken = items.map { it.substringBefore(" | bounds=").replace(Regex("\\[.*?\\] "), "") }
                .filter { it.isNotBlank() }
                .distinct().take(12).joinToString(". ")
            NovaBus.response = spoken
            speak(spoken)
            return true
        }

        // Direct text entry: focus the best editable control, then type. This is
        // useful for search boxes, messages, forms, browser fields, etc.
        if (!hasCompound) {
            val m = Regex("^(?:type|write|enter|ටයිප්|ටයිප් කරන්න|ලියන්න|ඇතුල් කරන්න)\\s+(.+)$", RegexOption.IGNORE_CASE).find(original)
            if (m != null) {
                val text = m.groupValues[1].trim()
                if (text.isNotBlank()) {
                    val focused = svc?.focusInput() ?: false
                    val typed = if (focused) svc?.setText(text) ?: false else false
                    return done(typed, "හරි, ටයිප් කළා.", "ටයිප් කරන්න input එකක් හම්බ වුණේ නෑ.")
                }
            }
        }

        // Direct screen-aware tap. The accessibility tree decides which visible
        // control is the best match; coordinates are not required from the user.
        if (!hasCompound) {
            val m = Regex("^(?:tap|click|press|ටැප්|ක්ලික්|ඔය එක ඔබන්න|එක ඔබන්න)\\s+(.+)$", RegexOption.IGNORE_CASE).find(original)
            if (m != null) {
                val q = m.groupValues[1].trim()
                if (q.isNotBlank()) {
                    return done(svc?.clickQuery(q) ?: false, "හරි, ඒක ඔබලා.", "ඒක screen එකේ හොයාගන්න බැරි වුණා.")
                }
            }
        }

        if (!hasCompound && t.matches(Regex(".*(scroll|scroll down|ස්ක්‍රෝල්|පහළට|පහලට).*"))) {
            return done(svc?.scrollForward() ?: false, "හරි, පහළට ගියා.", "පහළට scroll කරන්න බැරි වුණා.")
        }
        if (!hasCompound && t.matches(Regex(".*(scroll up|scroll backward|ඉහළට|උඩට).*"))) {
            return done(svc?.scrollBackward() ?: false, "හරි, ඉහළට ගියා.", "ඉහළට scroll කරන්න බැරි වුණා.")
        }
        if (!hasCompound && t.matches(Regex(".*(volume up|increase volume|ශබ්දය වැඩි|වොලියුම් වැඩි).*"))) {
            val am = getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
            am.adjustVolume(android.media.AudioManager.ADJUST_RAISE, android.media.AudioManager.FLAG_SHOW_UI)
            return done(true, "හරි, volume වැඩි කළා.", "Volume එක වෙනස් කරන්න බැරි වුණා.")
        }
        if (!hasCompound && t.matches(Regex(".*(volume down|decrease volume|ශබ්දය අඩු|වොලියුම් අඩු).*"))) {
            val am = getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
            am.adjustVolume(android.media.AudioManager.ADJUST_LOWER, android.media.AudioManager.FLAG_SHOW_UI)
            return done(true, "හරි, volume අඩු කළා.", "Volume එක වෙනස් කරන්න බැරි වුණා.")
        }

        // Simple app-opening commands stay local. Compound requests go to the
        // agent so it can inspect the screen and continue through multiple steps.
        if (!hasCompound && (hasOpenVerb(t) || t.contains("ඇර") || t.contains("අරින්න") || t.contains("යන්න"))) {
            val app = extractSimpleAppName(original)
            if (app.isNotBlank()) {
                val ok = if (app.equals("settings", true) || app.contains("සෙටින්") || app.contains("සැකසුම්"))
                    openIntentResult(Intent(Settings.ACTION_SETTINGS))
                else openAppByName(app)
                return done(ok, "හරි, $app ඇරියා.", "$app ඇරගන්න බැරි වුණා.")
            }
        }

        // Universal on-device fallbacks for short, unambiguous commands. These
        // do not depend on the VPS/model being available, so common human-style
        // commands still work when the remote free-model quota is exhausted.
        if (!hasCompound) {
            val normalized = t.replace(Regex("\\s+"), " ").trim()
            val openWords = listOf("open", "launch", "start", "show", "go to", "ඔපන්", "ඕපන්", "ඇර", "අරින්න", "අරි", "යන්න", "පෙන්ව", "විවෘත")
            val closeWords = listOf("close", "exit", "back", "බැක්", "ආපහු", "පස්සට")

            // "WhatsApp", "Settings", etc. without an explicit verb.
            if (normalized.length <= 40 && openWords.none { normalized.contains(it) } &&
                closeWords.none { normalized == it || normalized.endsWith(" $it") }) {
                val aliasOnly = extractSimpleAppName(normalized)
                val knownStandaloneApp = listOf(
                    "whatsapp", "youtube", "facebook", "instagram", "telegram",
                    "chrome", "camera", "gallery", "play store", "settings"
                ).contains(aliasOnly.lowercase(Locale.ROOT))
                if (knownStandaloneApp) {
                    val ok = if (aliasOnly.equals("settings", true))
                        openIntentResult(Intent(Settings.ACTION_SETTINGS)) else openAppByName(aliasOnly)
                    if (ok) return done(true, "හරි, $aliasOnly ඇරියා.", "$aliasOnly ඇරගන්න බැරි වුණා.")
                }
            }

            // Natural-language "tap/click the visible thing" without requiring
            // the user to know the accessibility action name.
            val tapMatch = Regex("(?:tap|click|press|select|open|choose|ටැප්|ක්ලික්|ඔබන්න|තෝරන්න|ඇර)\\s+(?:the\\s+|එක\\s+|අර\\s+)?(.+)$", RegexOption.IGNORE_CASE).find(original)
            if (tapMatch != null) {
                val q = tapMatch.groupValues[1].trim().removeSuffix(".")
                if (q.isNotBlank() && q.length <= 80) {
                    val ok = svc?.clickQuery(q) ?: false
                    if (ok) return done(true, "හරි, ඒක කළා.", "ඒක screen එකේ හොයාගන්න බැරි වුණා.")
                }
            }

            // Generic "type/write ..." into the currently focused/first editable field.
            val typeMatch = Regex("^(?:type|write|enter|ටයිප්|ලියන්න|ඇතුල් කරන්න)\\s+(.+)$", RegexOption.IGNORE_CASE).find(original)
            if (typeMatch != null) {
                val text = typeMatch.groupValues[1].trim()
                val ok = (svc?.focusInput() == true) && (svc?.setText(text) == true)
                if (ok) return done(true, "හරි, ටයිප් කළා.", "ටයිප් කරන්න input එකක් හම්බ වුණේ නෑ.")
            }
        }
        return false
    }

    private fun extractSimpleAppName(raw: String): String {
        val t = raw.trim()
        val aliases = listOf(
            "whatsapp" to listOf("whatsapp", "වට්සැප්", "වට්ස්ඇප්"),
            "youtube" to listOf("youtube", "යූටියුබ්"),
            "facebook" to listOf("facebook", "ෆේස්බුක්"),
            "instagram" to listOf("instagram", "ඉන්ස්ටග්‍රෑම්"),
            "telegram" to listOf("telegram", "ටෙලිග්‍රෑම්"),
            "chrome" to listOf("chrome", "ක්‍රෝම්"),
            "camera" to listOf("camera", "කැමරා"),
            "gallery" to listOf("gallery", "ගැලරි"),
            "play store" to listOf("play store", "ප්ලේ ස්ටෝර්"),
            "settings" to listOf("settings", "setting", "සෙටින්", "සෙටිං", "සැකසුම්")
        )
        val low = t.lowercase(Locale.ROOT)
        aliases.firstOrNull { (_, keys) -> keys.any { low.contains(it) } }?.let { return it.first }
        val cleaned = t.replace(Regex("(?i)\\b(open|launch|start|go to)\\b"), "")
            .replace(Regex("^(ඇර|අරින්න|අරි|යන්න|ඔපන්|ඕපන්)\\s*"), "")
            .replace(Regex("(?i)\\b(the|app|application)\\b"), "")
            .trim()
        return cleaned.takeIf { it.length in 1..40 } ?: ""
    }

    private fun openIntentResult(intent: Intent): Boolean {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            startActivity(intent)
            true
        } catch (_: Exception) { false }
    }

    private fun currentDeviceState(): JSONObject {
        val km = getSystemService(Context.KEYGUARD_SERVICE) as android.app.KeyguardManager
        val svc = NovaAccessibilityService.instance
        return JSONObject()
            .put("keyguard_locked", km.isKeyguardLocked)
            .put("accessibility_enabled", svc != null)
            .put("foreground_package", svc?.rootInActiveWindow?.packageName?.toString() ?: "")
            .put("android_api", Build.VERSION.SDK_INT)
    }

    /**
     * Return a cheap fingerprint of the currently visible accessibility tree.
     * The autonomous loop uses this to wait for a real UI transition instead of
     * blindly firing the next action after a fixed sleep.
     */
    private fun screenFingerprint(): String {
        val items = NovaAccessibilityService.instance?.screenSnapshot(80).orEmpty()
        return items.joinToString("\n").hashCode().toString()
    }

    private fun waitForScreenChange(before: String, timeoutMs: Long = 3500L): Boolean {
        val deadline = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < deadline) {
            Thread.sleep(120)
            val now = screenFingerprint()
            if (now != before && now.isNotBlank()) return true
        }
        return false
    }

    private fun send(text: String, isAutoContinue: Boolean = false) {
        NovaBus.state = NovaState.THINKING
        updateNotification("හිතනවා...")
        if (!isAutoContinue && tryLocalPhoneCommand(text)) {
            autoContinueDepth = 0
            pendingTaskText = null
            waitingForUnlock = false
            return
        }
        if (!isAutoContinue && text.isNotBlank() && !text.startsWith("[auto:")) {
            pendingTaskText = text
        }
        Thread {
            var serverReached = false
            try {
                val p = getSharedPreferences("p", 0)
                val u = p.getString("url", "") ?: ""
                val token = p.getString("token", "") ?: ""
                if (u.isBlank()) {
                    speak("මුලින් Settings එකෙන් VPS ලිපිනය සකස් කරන්න.")
                    return@Thread
                }
                val accessibilityScreen = NovaAccessibilityService.instance?.screenSnapshot() ?: emptyList()
                // Capture the real visible screen as a single live frame. The
                // accessibility tree remains the primary structured UI source;
                // the image lets a vision-capable model understand icons, layout,
                // colors and controls that have no accessibility text.
                val liveImage = NovaAccessibilityService.instance?.liveScreenImageBase64()

                val body = JSONObject()
                    .put("text", text)
                    .put("conversation_id", conversationId())
                    .put("device_state", currentDeviceState())
                if (accessibilityScreen.isNotEmpty()) {
                    val arr = JSONArray()
                    accessibilityScreen.forEach { arr.put(it) }
                    body.put("screen", arr)
                }
                if (!liveImage.isNullOrBlank()) {
                    body.put("screen_image_base64", liveImage)
                    body.put("screen_image_mime", "image/jpeg")
                }
                val activity = NovaNotificationListener.recentActivity(10)
                if (activity.isNotEmpty()) {
                    val arr = JSONArray()
                    activity.forEach { arr.put(JSONObject().put("app", it.app).put("title", it.title).put("text", it.text)) }
                    body.put("recent_activity", arr)
                }
                if (pendingActionResults.isNotEmpty()) {
                    val arr = JSONArray()
                    pendingActionResults.forEach { arr.put(it) }
                    body.put("action_results", arr)
                    pendingActionResults = mutableListOf()
                }

                val c = URL(u.trimEnd('/') + "/chat").openConnection() as HttpURLConnection
                c.requestMethod = "POST"
                c.doOutput = true
                c.connectTimeout = 5000
                c.readTimeout = 35000
                c.setRequestProperty("Content-Type", "application/json")
                c.setRequestProperty("X-Nova-Token", token)
                c.outputStream.use { it.write(body.toString().toByteArray()) }

                val code = c.responseCode
                serverReached = true
                if (code >= 400) {
                    val err = c.errorStream?.bufferedReader()?.readText() ?: "HTTP $code"
                    throw RuntimeException("HTTP $code: $err")
                }
                val respText = c.inputStream.bufferedReader().use { it.readText() }
                val resp = JSONObject(respText)
                val reply = resp.optString("reply", "")
                val continueTask = resp.optBoolean("continue_task", false)
                resp.optJSONObject("voice")?.let { v ->
                    lastRate = v.optDouble("rate", 1.05).toFloat().coerceIn(0.85f, 1.15f)
                    lastPitch = v.optDouble("pitch", 1.0).toFloat().coerceIn(0.9f, 1.1f)
                }

                val actions = resp.optJSONArray("device_actions")
                var screenChanged = false
                if (actions != null && actions.length() > 0) {
                    // Execute on Android's main thread, then wait for the visible
                    // UI to settle/change before asking the model for its next
                    // decision. This is the important observation -> action ->
                    // observation loop; it prevents fast consecutive taps from
                    // racing an app transition.
                    val beforeFingerprint = screenFingerprint()
                    val latch = CountDownLatch(1)
                    mainHandler.post {
                        try { executeDeviceActions(actions) } finally { latch.countDown() }
                    }
                    latch.await(7000, java.util.concurrent.TimeUnit.MILLISECONDS)
                    screenChanged = waitForScreenChange(beforeFingerprint, 3500L)
                }

                if (reply.isNotBlank()) NovaBus.response = reply

                val actionStillNeedsObservation = actions != null && actions.length() > 0 && !waitingForUnlock && autoContinueDepth < 24
                if ((continueTask || actionStillNeedsObservation || screenChanged) && autoContinueDepth < 24) {
                    autoContinueDepth++
                    if (reply.isNotBlank()) speakWithoutResumingListen(reply)
                    val delay = if (pendingActionResults.any { it.contains("=failed") || it.contains("=error:") }) 450L else 250L
                    mainHandler.postDelayed({ send("[auto:screen_update]", isAutoContinue = true) }, delay)
                } else {
                    autoContinueDepth = 0
                    if (!waitingForUnlock) pendingTaskText = null
                    if (reply.isBlank() && isAutoContinue) {
                        if (running) listen()
                    } else {
                        speak(reply.ifBlank { "හරි." })
                    }
                }
            } catch (e: Exception) {
                autoContinueDepth = 0
                val detail = e.message ?: e.javaClass.simpleName
                NovaBus.lastError = detail
                NovaBus.state = NovaState.ERROR
                if (serverReached) {
                    // HTTP reached the VPS, so never mislabel an AI/provider/action
                    // failure as a network/VPS connection failure.
                    val short = detail.replace(Regex("\\s+"), " ").take(180)
                    speak("VPS එකට සම්බන්ධයි. ඒත් NOVAගේ වැඩේ අතරේ දෝෂයක් ආවා. $short")
                } else {
                    speak("VPS එකට connection එක හදාගන්න බැරි වුණා. URL එක, token එක, internet එක හෝ port එක check කරන්න ඕන.")
                }
            }
        }.start()
    }

    private fun startUnlockResumeWatcher() {
        if (!waitingForUnlock || pendingTaskText.isNullOrBlank() || !running) return
        mainHandler.postDelayed({
            if (!running || !waitingForUnlock) return@postDelayed
            val km = getSystemService(Context.KEYGUARD_SERVICE) as android.app.KeyguardManager
            if (!km.isKeyguardLocked) {
                waitingForUnlock = false
                val task = pendingTaskText
                if (!task.isNullOrBlank()) {
                    speakWithoutResumingListen("හරි, unlock කරලා තියෙනවා. මම කලින් වැඩේම continue කරනවා.")
                    mainHandler.postDelayed({ send(task, isAutoContinue = true) }, 450)
                }
            } else {
                startUnlockResumeWatcher()
            }
        }, 900)
    }

    // ---------- Device action execution ----------

    private fun executeDeviceActions(actions: JSONArray) {
        val results = mutableListOf<String>()
        for (i in 0 until actions.length()) {
            try {
                val a = actions.getJSONObject(i)
                val name = a.optString("action")
                val args = a.optJSONObject("arguments") ?: JSONObject()
                var ok = true
                when (name) {
                    "ui.back" -> ok = NovaAccessibilityService.instance?.back() ?: false
                    "ui.home" -> ok = NovaAccessibilityService.instance?.home() ?: false
                    "ui.notifications" -> ok = NovaAccessibilityService.instance?.notifications() ?: false
                    "ui.click_text" -> ok = args.optString("text").takeIf { it.isNotBlank() }
                        ?.let { NovaAccessibilityService.instance?.clickText(it) } ?: false
                    "ui.click_description" -> ok = args.optString("description").takeIf { it.isNotBlank() }
                        ?.let { NovaAccessibilityService.instance?.clickByDescription(it) } ?: false
                    "ui.click_query" -> ok = args.optString("query").takeIf { it.isNotBlank() }
                        ?.let { NovaAccessibilityService.instance?.clickQuery(it) } ?: false
                    "ui.focus_input" -> ok = NovaAccessibilityService.instance?.focusInput() ?: false
                    "ui.clear_input" -> ok = NovaAccessibilityService.instance?.clearInput() ?: false
                    "ui.type_text" -> ok = NovaAccessibilityService.instance?.setText(args.optString("text")) ?: false
                    "ui.tap" -> ok = NovaAccessibilityService.instance?.tap(
                        args.optDouble("x").toFloat(), args.optDouble("y").toFloat()) ?: false
                    "ui.swipe" -> ok = NovaAccessibilityService.instance?.swipe(
                        args.optDouble("x").toFloat(), args.optDouble("y").toFloat(),
                        args.optDouble("x2").toFloat(), args.optDouble("y2").toFloat(),
                        args.optLong("duration_ms",350L)) ?: false
                    "ui.scroll" -> {
                        ok = if (args.optString("direction","forward").equals("backward",true))
                            NovaAccessibilityService.instance?.scrollBackward() ?: false
                        else NovaAccessibilityService.instance?.scrollForward() ?: false
                    }
                    "ui.long_press" -> ok = NovaAccessibilityService.instance?.longPress(
                        args.optDouble("x").toFloat(), args.optDouble("y").toFloat(),
                        args.optLong("duration_ms",650L)) ?: false
                    "ui.power_dialog" -> ok = NovaAccessibilityService.instance?.powerDialog() ?: false
                    "ui.lock_screen" -> ok = NovaAccessibilityService.instance?.lockScreen() ?: false
                    "ui.screenshot" -> ok = NovaAccessibilityService.instance?.takeScreenshot() ?: false
                    "ui.read_screen" -> {
                        val items = NovaAccessibilityService.instance?.screenSnapshot(18).orEmpty()
                        if (items.isEmpty()) {
                            speak("දැනට screen එකේ කියවන්න දෙයක් හම්බ වුණේ නෑ.")
                            ok = false
                        } else {
                            val spoken = items.map { it.substringBefore(" | bounds=").replace(Regex("\\[.*?\\] "), "") }
                                .filter { it.isNotBlank() }.distinct().take(12).joinToString(". ")
                            NovaBus.response = spoken
                            speak(spoken)
                            ok = true
                        }
                    }
                    "ui.recent" -> ok = NovaAccessibilityService.instance?.performGlobalAction(
                        android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_RECENTS) ?: false
                    "ui.quick_settings" -> ok = NovaAccessibilityService.instance?.performGlobalAction(
                        android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS) ?: false
                    "device.status" -> {
                        val km = getSystemService(Context.KEYGUARD_SERVICE) as android.app.KeyguardManager
                        results.add("device.status=locked:${km.isKeyguardLocked},accessibility:${NovaAccessibilityService.instance != null}")
                    }
                    "media.play_pause" -> {
                        // GLOBAL_ACTION_MEDIA_PLAY_PAUSE was added in API 36.
                        // Keep the app compatible with the project's minSdk while
                        // allowing the API-36 global media action when available.
                        if (android.os.Build.VERSION.SDK_INT >= 36) {
                            ok = NovaAccessibilityService.instance?.performGlobalAction(
                                android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_MEDIA_PLAY_PAUSE
                            ) ?: false
                        } else {
                            ok = false
                            speak("මෙම Android version එකේ media play/pause global action එක support කරන්නේ නැහැ.")
                        }
                    }
                    "media.volume_up" -> {
                        val am=getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
                        am.adjustVolume(android.media.AudioManager.ADJUST_RAISE, android.media.AudioManager.FLAG_SHOW_UI)
                    }
                    "media.volume_down" -> {
                        val am=getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
                        am.adjustVolume(android.media.AudioManager.ADJUST_LOWER, android.media.AudioManager.FLAG_SHOW_UI)
                    }
                    "media.mute" -> {
                        val am=getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
                        am.adjustVolume(android.media.AudioManager.ADJUST_MUTE, android.media.AudioManager.FLAG_SHOW_UI)
                    }
                    "clipboard.write" -> {
                        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                        cm.setPrimaryClip(android.content.ClipData.newPlainText("Nova", args.optString("text")))
                        ok = true
                    }
                    "clipboard.read" -> {
                        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                        val clip = cm.primaryClip
                        val value = if (clip != null && clip.itemCount > 0) clip.getItemAt(0).coerceToText(this).toString() else ""
                        pendingActionResults.add("clipboard.read=" + value.take(1000))
                        ok = true
                    }
                    "app.open" -> { ok = openAppByName(args.optString("app_name")) }
                    "app.open_package" -> {
                        val pkg = args.optString("package_name")
                        ok = pkg.isNotBlank() && packageManager.getLaunchIntentForPackage(pkg)?.let { openIntent(it); true } == true
                    }
                    "app.youtube_search" -> { openUrl("https://www.youtube.com/results?search_query=" + enc(args.optString("query"))) }
                    "app.google_search" -> { openUrl("https://www.google.com/search?q=" + enc(args.optString("query"))) }
                    "whatsapp.open_chat" -> {
                        val num = args.optString("number").filter { it.isDigit() || it == '+' }
                        val msg = args.optString("message")
                        val autoSend = args.optBoolean("auto_send", false)
                        if (num.isBlank()) ok = false else {
                            val url = "https://wa.me/$num" + if (msg.isNotBlank()) "?text=" + enc(msg) else ""
                            openUrl(url)
                            if (autoSend && msg.isNotBlank()) {
                                mainHandler.postDelayed({
                                    val svc = NovaAccessibilityService.instance
                                    var sent = svc?.clickByDescription("Send") ?: false
                                    if (!sent) sent = svc?.clickByDescription("යවන්න") ?: false
                                    if (!sent) NovaBus.lastError = "whatsapp_send_button_not_found"
                                    pendingActionResults.add("whatsapp.send=${if (sent) "ok" else "failed"}")
                                }, 800L)
                            }
                        }
                    }
                    "call.dial" -> {
                        val num = args.optString("number")
                        ok = num.isNotBlank()
                        if (ok) openIntent(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$num")))
                    }
                    "settings.open_wifi" -> openIntent(Intent(Settings.ACTION_WIFI_SETTINGS))
                    "settings.open_data" -> openIntent(Intent(Settings.ACTION_WIRELESS_SETTINGS))
                    "settings.open_bluetooth" -> openIntent(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
                    "settings.open_general" -> openIntent(Intent(Settings.ACTION_SETTINGS))
                    "reminder.set" -> {
                        ok = scheduleReminder(args.optString("message"), args.optInt("delay_minutes", -1), args.optString("at_hhmm"))
                    }
                    else -> ok = false
                }
                if (!ok) {
                    val km = getSystemService(Context.KEYGUARD_SERVICE) as android.app.KeyguardManager
                    if (km.isKeyguardLocked) {
                        results.add("device_locked=true")
                        waitingForUnlock = true
                        startUnlockResumeWatcher()
                    }
                }
                results.add("$name=${if (ok) "ok" else "failed"}")
            } catch (e: Exception) {
                results.add("${actions.optJSONObject(i)?.optString("action") ?: "unknown"}=error:${e.javaClass.simpleName}")
            }
        }
        pendingActionResults.addAll(results)
    }

    private fun scheduleReminder(message: String, delayMinutes: Int, atHhmm: String): Boolean {
        if (message.isBlank()) return false
        val alarm = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(this, ReminderReceiver::class.java).putExtra("message", message)
        val requestCode = (System.currentTimeMillis() and 0x7fffffff).toInt()
        val pi = PendingIntent.getBroadcast(
            this, requestCode, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val now = Calendar.getInstance()
        val whenMs: Long = when {
            delayMinutes >= 0 -> System.currentTimeMillis() + delayMinutes.coerceAtLeast(1) * 60_000L
            Regex("^\\d{2}:\\d{2}$").matches(atHhmm) -> {
                val parts = atHhmm.split(":")
                val h = parts[0].toIntOrNull() ?: return false
                val m = parts[1].toIntOrNull() ?: return false
                if (h !in 0..23 || m !in 0..59) return false
                now.set(Calendar.HOUR_OF_DAY, h)
                now.set(Calendar.MINUTE, m)
                now.set(Calendar.SECOND, 0)
                now.set(Calendar.MILLISECOND, 0)
                if (now.timeInMillis <= System.currentTimeMillis()) now.add(Calendar.DAY_OF_YEAR, 1)
                now.timeInMillis
            }
            else -> return false
        }
        alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, whenMs, pi)
        return true
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private fun openUrl(url: String) {
        openIntent(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
    }

    private fun openIntent(intent: Intent) {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { startActivity(intent) } catch (_: Exception) { }
    }

    private fun openAppByName(name: String): Boolean {
        if (name.isBlank()) return false
        val pm = packageManager
        val apps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
        val normalized = name.trim().lowercase(Locale.ROOT)
        val target = apps.firstOrNull {
            pm.getApplicationLabel(it).toString().lowercase(Locale.ROOT).contains(normalized)
        } ?: apps.firstOrNull {
            it.packageName.lowercase(Locale.ROOT).contains(normalized)
        } ?: return false
        val intent = pm.getLaunchIntentForPackage(target.packageName) ?: return false
        openIntent(intent)
        return true
    }

    // ---------- TTS ----------

    private fun speak(s: String) {
        if (s.isBlank()) return
        mainHandler.post {
            NovaBus.state = NovaState.SPEAKING
            updateNotification("කතා කරනවා...")
            if (!ttsReady) {
                mainHandler.postDelayed({ if (running) speak(s) }, 120)
                return@post
            }
            tts.setSpeechRate(lastRate.coerceIn(0.88f, 1.16f))
            tts.setPitch(lastPitch.coerceIn(0.92f, 1.08f))
            val utteranceId = "nova-final"
            tts.speak(s, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
        }
    }

    private fun speakWithoutResumingListen(s: String) {
        mainHandler.post {
            NovaBus.state = NovaState.EXECUTING
            updateNotification("කරගෙන යනවා...")
            tts.setSpeechRate(lastRate)
            tts.setPitch(lastPitch)
            tts.speak(s, TextToSpeech.QUEUE_FLUSH, null, "nova")
        }
    }

    override fun onInit(s: Int) {
        if (s == TextToSpeech.SUCCESS) {
            val result = tts.setLanguage(Locale("si", "LK"))
            ttsReady = result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED
            if (!ttsReady) {
                // Some Android TTS engines expose Sinhala as `si` but not `si-LK`.
                // Try the language-only locale before falling back to English.
                val siOnly = tts.setLanguage(Locale("si"))
                ttsReady = siOnly != TextToSpeech.LANG_MISSING_DATA && siOnly != TextToSpeech.LANG_NOT_SUPPORTED
                if (!ttsReady) tts.language = Locale.US
            }
            tts.setSpeechRate(1.02f)
            tts.setPitch(1.0f)
        }
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        // No-op on purpose: android:stopWithTask="false" + this override keep
        // Nova running after the app is swiped away from Recents.
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        instance = null
        running = false
        NovaBus.isServiceRunning = false
        NovaBus.state = NovaState.OFFLINE
        sr?.destroy()
        tts.shutdown()
        super.onDestroy()
    }

    override fun onBind(i: Intent?): IBinder? = null
}
