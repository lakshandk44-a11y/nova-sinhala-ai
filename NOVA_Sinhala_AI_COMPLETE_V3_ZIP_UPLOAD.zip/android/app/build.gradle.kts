plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    buildFeatures {
        compose = true
    }
    namespace="com.nova.assistant"
    compileSdk=35
    defaultConfig { applicationId="com.nova.assistant"; minSdk=26; targetSdk=35; versionCode=1; versionName="0.2.0" }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}
dependencies {
    implementation("androidx.compose.ui:ui:1.7.8")
    implementation("androidx.compose.ui:ui-tooling-preview:1.7.8")
    implementation("androidx.compose.material3:material3:1.3.1")
    implementation("androidx.activity:activity-compose:1.10.0")
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
}
