"""
Fetches the Gemini API's *live* list of available models (client.models.list())
and caches it for a while, so model_router.py can drop names that Google has
renamed/retired and auto-discover new same-family models — instead of every
Gemini rename silently breaking the hardcoded GEMINI_MODELS list in .env.

Fails open: if the live fetch errors (network hiccup, quota, etc.) callers
just fall back to trusting the configured list as-is, exactly like before
this module existed.
"""
import re
import time

_CACHE_TTL_SECONDS = 3600  # re-check at most once an hour
_cache: dict = {"ids": None, "fetched_at": 0.0}

# Family keywords we auto-adopt newly discovered models for, cheapest-first.
# A model whose name contains one of these (and supports generateContent) is
# treated as a same-family drop-in even if it isn't in .env yet.
_FAMILY_PATTERNS = ("flash-lite", "flash", "pro")


def _strip_prefix(name: str) -> str:
    return name.split("/", 1)[1] if name.startswith("models/") else name


def live_model_ids(client) -> set[str] | None:
    """Returns the set of model IDs that currently support generateContent,
    using an in-memory cache. Returns None if the live fetch fails/hasn't
    succeeded yet — callers should treat None as "unknown, don't filter"."""
    now = time.time()
    if _cache["ids"] is not None and (now - _cache["fetched_at"]) < _CACHE_TTL_SECONDS:
        return _cache["ids"]
    try:
        ids = set()
        for m in client.models.list():
            actions = getattr(m, "supported_actions", None) or []
            if "generateContent" in actions:
                ids.add(_strip_prefix(m.name))
        _cache["ids"] = ids
        _cache["fetched_at"] = now
        return ids
    except Exception:
        # Network hiccup / quota on the listing call itself — keep whatever
        # we had cached before (even if stale) rather than breaking chat.
        return _cache["ids"]


def reconcile(configured: list[str], client) -> list[str]:
    """Takes the ordered candidate list built from GEMINI_MODELS and:
      1. Drops any entry that the live API confirms no longer exists
         (renamed/retired) — avoids repeating a guaranteed-404 call.
      2. Appends newly-discovered same-family models not already listed,
         as extra fallbacks, cheapest-looking first.
    If the live list can't be fetched, returns `configured` unchanged.
    """
    live = live_model_ids(client)
    if not live:
        return configured

    valid = [m for m in configured if m in live]
    if not valid:
        # Everything configured is stale (e.g. a whole-sale Gemini rename) —
        # fall back to auto-discovering candidates straight from the live
        # list instead of returning nothing and guaranteeing a 404.
        valid = configured

    known = set(valid)
    discovered = []
    for pattern in _FAMILY_PATTERNS:
        for name in sorted(live):
            if pattern in name and name not in known and "image" not in name and "audio" not in name and "tts" not in name and "live" not in name:
                discovered.append(name)
                known.add(name)

    return valid + discovered
