package com.nova.assistant

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class NovaAccessibilityService : AccessibilityService() {

    companion object {
        var instance: NovaAccessibilityService? = null
            private set
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun clickText(text: String): Boolean {
        val root=rootInActiveWindow ?: return false
        val nodes=root.findAccessibilityNodeInfosByText(text)
        for (node in nodes) {
            val ok=if (node.isClickable)
                node.performAction(AccessibilityNodeInfo.ACTION_CLICK) else false
            node.recycle()
            if (ok) return true
        }
        return false
    }

    /** For icon-only controls (e.g. WhatsApp's Send button has no visible text,
     * only a contentDescription), since findAccessibilityNodeInfosByText is not
     * reliable for those. */
    fun clickByDescription(description: String): Boolean {
        val root = rootInActiveWindow ?: return false
        var found = false
        fun walk(node: AccessibilityNodeInfo?, depth: Int) {
            if (node == null || found || depth > 20) return
            val desc = node.contentDescription?.toString()
            if (desc != null && desc.equals(description, ignoreCase = true) && node.isClickable) {
                found = node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                return
            }
            for (i in 0 until node.childCount) {
                if (found) break
                walk(node.getChild(i), depth + 1)
            }
        }
        walk(root, 0)
        return found
    }

    fun back(): Boolean = performGlobalAction(GLOBAL_ACTION_BACK)
    fun home(): Boolean = performGlobalAction(GLOBAL_ACTION_HOME)
    fun notifications(): Boolean = performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)

    fun tap(x:Float,y:Float):Boolean {
        val path=Path().apply { moveTo(x,y) }
        val stroke=GestureDescription.StrokeDescription(path,0,40)
        val gesture=GestureDescription.Builder().addStroke(stroke).build()
        return dispatchGesture(gesture,null,null)
    }

    /**
     * Best-effort snapshot of what's currently on screen — both what's
     * clickable/typeable AND plain readable text — so Nova can actually read
     * and reason about a screen ("meke mokakda thiyenne"), not just know
     * what's tappable. Each item is tagged so the AI knows what it can do
     * with it: [button], [input], or plain readable text.
     *
     * Real platform limits (not something Nova can work around): apps that
     * mark a screen FLAG_SECURE (banking PIN entry, some payment screens)
     * hide their content from accessibility entirely by OS design, and some
     * web pages only expose text once it's actually laid out on screen.
     */
    fun screenSnapshot(maxItems: Int = 60): List<String> {
        val root = rootInActiveWindow ?: return emptyList()
        val out = mutableListOf<String>()
        val seen = HashSet<String>()
        fun walk(node: AccessibilityNodeInfo?, depth: Int) {
            if (node == null || out.size >= maxItems || depth > 24) return
            val label = (node.text?.toString() ?: node.contentDescription?.toString())?.trim()
            if (!label.isNullOrBlank() && seen.add(label)) {
                out.add(
                    when {
                        node.isEditable -> "[input] $label"
                        node.isClickable -> "[button] $label"
                        else -> label
                    }
                )
            }
            for (i in 0 until node.childCount) {
                if (out.size >= maxItems) break
                walk(node.getChild(i), depth + 1)
            }
        }
        walk(root, 0)
        return out
    }

    override fun onDestroy() {
        if (instance === this) instance = null
        super.onDestroy()
    }
}
