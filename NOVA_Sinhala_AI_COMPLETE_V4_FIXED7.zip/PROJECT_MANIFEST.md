# Nova project manifest

The project is split into:
1. Android client: voice/UI/permissions/device execution.
2. VPS server: AI orchestration/memory/tools/scheduler/audit.
3. Secure protocol: authenticated request/action/confirmation flow.
4. UI: futuristic animated assistant interface.
5. Operations: GitHub Actions + VPS systemd/nginx.
6. Documentation: master spec, limits, setup, security and completion status.

Never add unrestricted shell/root control to the AI. Android permissions remain user-controlled.
