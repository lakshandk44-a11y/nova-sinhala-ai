# NOVA — Sinhala Personal AI Agent

This repository is the complete project foundation for the Nova Sinhala-first personal AI companion:
Android client + device agent + VPS AI backend + memory + tools + secure deployment.

## Architecture
- `android/` — Android UI/client, voice service, permissions, device-control foundation.
- `server/` — VPS API, AI orchestration foundation, memory, audit.
- `deploy/` — VPS service/reverse-proxy templates.
- `docs/` — master specification.
- `.github/` — GitHub Actions APK build.

## Important Android limitation
Android permissions are granted by the user and Android controls background execution.
A third-party app cannot guarantee unrestricted control of every app or an unkillable microphone
process. Nova is designed to use the maximum legitimate, user-authorized capabilities and
to recover when the OS/OEM stops background work.

## Build
Push this repository to GitHub. GitHub Actions builds `app-debug.apk`.
See `docs/ANDROID_SETUP.md` and `docs/VPS_SETUP.md`.

Never commit API keys, tokens, passwords or SSH keys.
