import os
from dataclasses import dataclass
from dotenv import load_dotenv

load_dotenv()

# Free-tier Gemini models, ordered roughly cheapest/lightest -> heaviest.
# The router (model_router.py) picks one per request based on task
# complexity, and rotates to the next one automatically if a model's
# free-tier quota is exhausted (HTTP 429 / RESOURCE_EXHAUSTED).
DEFAULT_FREE_MODELS = [
    "gemini-3.5-flash-lite",
    "gemini-3.5-flash",
    "gemini-3.6-flash",
    "gemini-3.1-flash-lite",
    "gemini-3.1-pro-preview",
    # older models kept as last-resort fallbacks only; Google may retire
    # these for new users at any time (404 "no longer available"), which
    # agent.py now treats as skip-to-next-candidate rather than a crash
    "gemini-2.5-flash",
    "gemini-2.0-flash",
]

def _parse_models(raw: str) -> list[str]:
    items = [m.strip() for m in raw.split(",") if m.strip()]
    return items or list(DEFAULT_FREE_MODELS)

@dataclass(frozen=True)
class Settings:
    provider: str = os.getenv("AI_PROVIDER", "gemini").strip().lower()
    gemini_api_key: str = os.getenv("GEMINI_API_KEY", "")
    openrouter_api_key: str = os.getenv("OPENROUTER_API_KEY", "")
    openrouter_model: str = os.getenv("OPENROUTER_MODEL", "openrouter/free")
    openrouter_base_url: str = os.getenv("OPENROUTER_BASE_URL", "https://openrouter.ai/api/v1")
    # Optional Groq failover. Put up to five API keys from separate Groq accounts
    # in GROQ_KEYS, comma-separated. Nova rotates keys per request and retries
    # the remaining keys when Groq returns a rate-limit response.
    groq_keys: tuple = tuple(k.strip() for k in os.getenv("GROQ_KEYS", "").split(",") if k.strip())
    groq_model: str = os.getenv("GROQ_MODEL", "llama-3.3-70b-versatile")
    groq_base_url: str = os.getenv("GROQ_BASE_URL", "https://api.groq.com/openai/v1")
    # Kept for backwards compatibility / manual override; the router uses
    # `models` below to pick automatically unless GEMINI_MODEL is pinned.
    model: str = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")
    models: tuple = tuple(_parse_models(os.getenv("GEMINI_MODELS", ",".join(DEFAULT_FREE_MODELS))))
    auto_model_select: bool = os.getenv("GEMINI_AUTO_MODEL", "true").lower() in ("1", "true", "yes")
    token: str = os.getenv("NOVA_API_TOKEN", "")
    db_path: str = os.getenv("NOVA_DB_PATH", "./data/nova.sqlite3")
    # NOTE: 0.0.0.0 so the process actually listens on the VPS's public
    # network interface. 127.0.0.1 (the old default) only accepts
    # connections from the VPS itself, which is the #1 cause of the
    # Android app reporting "unable to connect to VPS" — nothing outside
    # the VPS can reach it. Keep a firewall (ufw/security group) open only
    # on NOVA_PORT, and put nginx+TLS in front for real production use.
    host: str = os.getenv("NOVA_HOST", "0.0.0.0")
    port: int = int(os.getenv("NOVA_PORT", "8787"))

settings = Settings()
