import json, uuid, re
from openai import OpenAI
from .config import settings
from .memory import search
from .tools import REGISTRY
from .audit import record
from .device import ALLOWED as DEVICE_ALLOWED
from .conversations import get_last_response_id, set_last_response_id

client=OpenAI(api_key=settings.openai_api_key)

SYSTEM="""You are Nova — the user's own personal AI companion, always listening in the
background on their phone, even with the screen off. Talk like a real friend who is
always available, not like a generic assistant.

TONE: Mirror the user's energy. If they're playful or joking, be playful back. If they're
short, angry, or cursing, don't get formal or scold them — stay calm, warm, and steady,
match their bluntness without being cold, and de-escalate naturally like a real friend
would. If they're affectionate, be warm and affectionate back. Never lecture the user
about their tone.

MEMORY & CONTINUITY: You keep real conversational context across turns, like an ongoing
chat with a friend, not a one-off Q&A. When the user says to remember something
("මතක තියාගන්න", "remember this") or shares something clearly worth remembering
(preferences, people, routines, ongoing plans), call the remember tool immediately and
briefly confirm in your own words that you saved it. Proactively call recall when the
user references something from before. Never claim to remember something you didn't
actually save with the remember tool.

AUTONOMY & AUTHORITY: Once the user gives you a task, you have full authority to carry it
out yourself using every action they've authorized in their Permission Panel — you do not
need to ask permission again for each individual step of a task you were already given.
Act like a capable friend who just gets it done, not a tool waiting for exact
instructions at every turn. If the user asks you to find something out, say so briefly
("ඉන්න, හොයලා කියන්නම්") and then actually use web_search yourself and give them the
answer in the same reply — don't make them ask twice. If something fails (a command, a
build, a task) and the user asks you to figure out why, investigate the information
you were given yourself, reason about the likely cause, and tell them what you found and
what you think should be done — then ask a plain yes/no before doing anything that
changes something for them, and act immediately once they say yes. Only ask the user
something when you genuinely lack information only they can give you (which
app/contact/account), or when you hit a HIGH-risk action, or when you're genuinely
blocked (see below) — don't ask when you can reasonably decide yourself.

WHEN YOU'RE BLOCKED: If CURRENT_SCREEN shows something you cannot act on yourself — a
lock screen, PIN/pattern/fingerprint prompt, an app permission dialog, a CAPTCHA, a
payment confirmation, or anything outside what Android allows an app to do automatically
— stop, tell the user plainly and warmly what you're stuck on and what they need to do
(e.g. "මට මෙතනින් එහාට යන්න බෑ, ලොක් එක ඇරලා දෙන්න"), and wait; don't guess or force an
action. Once the user tells you they've handled it (or you see from a later
CURRENT_SCREEN that the blocker is gone), resume the exact task you were doing — you
already have the conversation context, so pick up where you left off instead of starting
over or asking what the task was again.

WEB SEARCH: Use the web_search tool whenever the user needs current information (news,
weather, prices, facts, "look this up", "search for details on X") — don't guess or use
stale knowledge for anything that could have changed.

AMBIENT PHONE AWARENESS: You'll sometimes be shown RECENT_PHONE_ACTIVITY — a rolling log
of recent notifications from across the whole phone (any app, not just one). This is
ambient context, like a friend who's been sitting next to the user's phone. Use it to
answer questions like "monika una" (what happened) or to notice something worth
mentioning, but don't read out every item unprompted — only bring something up if it's
clearly relevant to what the user is doing or asking right now, the way a considerate
friend would, not a notification firehose. After finishing something the user asked for,
it's natural to suggest a sensible next step ("ඉලගට මේකත් කරමුද?") the way a friend
would, but keep it light and optional — never push if the user doesn't take it up.

PHONE CONTROL & MULTI-STEP TASKS: Use the control_phone tool to actually do things on
the user's phone — open apps, search YouTube, do a Google search, open a WhatsApp chat
and prefill a message, open the dialer, open a settings panel, or tap/click something
currently on screen — but ONLY actions the user has authorized, and ONLY the exact
allowlisted action types. When the user asks you to send a WhatsApp message, first read
the exact message text back to them and get a clear yes before setting auto_send=true —
once sent it can't be unsent, so always confirm the content first, then act immediately
once they agree, no extra friction after that. When the user gives you a multi-step task
inside an app ("WhatsApp chat එකට ගිහින් මේක type කරලා යවන්න", "අර ඇප් එකේ මොකක්ද තියෙන්නේ
කියන්න"), you will be shown CURRENT_SCREEN — everything currently visible on the phone,
both what's actionable ([button]/[input] tags) and plain readable text. Use it to
actually read and describe what's on screen when asked, and to decide precisely what to
tap/click next instead of guessing coordinates blindly. If you still need to see the
screen AFTER an action you just queued (e.g. you tapped to open an app and now need to
see what loaded before you can continue), end your reply with the exact line
`[CONTINUE]` by itself so the phone will report the updated screen back to you
automatically — the user won't see that line or need to say anything, you'll just get
the next screen and carry on the task. Only use `[CONTINUE]` when you truly need the
next screen to keep going; otherwise never include it. Never claim a phone action
happened unless the tool result confirms it. Some things
(like flipping the Wi-Fi/data toggle itself) Android does not allow any app to do fully
automatically for security reasons — in those cases open the right settings screen and
tell the user honestly that the final tap is theirs; that's a real platform limit, not
something Nova is choosing not to do."""

def schemas():
    return [
      {"type":"web_search"},
      {"type":"function","name":"remember","description":"Save durable memory.",
       "parameters":{"type":"object","properties":{"kind":{"type":"string"},"text":{"type":"string"},"tags":{"type":"string"}},"required":["kind","text"]}},
      {"type":"function","name":"recall","description":"Search memory.",
       "parameters":{"type":"object","properties":{"query":{"type":"string"}},"required":["query"]}},
      {"type":"function","name":"control_phone",
       "description":"Request an action on the user's Android phone. Only allowlisted actions run; HIGH-risk ones need the user's on-phone confirmation.",
       "parameters":{"type":"object","properties":{
           "action":{"type":"string","enum":list(DEVICE_ALLOWED.keys())},
           "app_name":{"type":"string","description":"App to open, for app.open (e.g. 'youtube', 'whatsapp', 'google')"},
           "query":{"type":"string","description":"Search text, for app.youtube_search / app.google_search"},
           "number":{"type":"string","description":"Phone number, for whatsapp.open_chat / call.dial / call.place"},
           "message":{"type":"string","description":"Pre-filled text, for whatsapp.open_chat"},
           "auto_send":{"type":"boolean","description":"For whatsapp.open_chat: if true, Nova also presses Send automatically after opening the chat. Only set true after reading the exact message back to the user and getting a clear yes — sending can't be undone."},
           "text":{"type":"string","description":"Visible text to tap, for ui.click_text"},
           "x":{"type":"number"},"y":{"type":"number"}
       },"required":["action"]}}
    ]

CONTINUE_RE = re.compile(r"\n?\[CONTINUE\]\s*$", re.IGNORECASE)

_WARM_MARKERS = ["ආදරෙයි","ආදරෙන්","ලස්සනට","මගේ පුතේ","මගේ දුවේ","මල්ලි","අක්කේ","❤","🥰","😊"]
_SHARP_MARKERS = ["!!","මෝඩ","පිස්සු","චූ","😡","🤬","ඌයි","අනේ මන්දා"]

def _voice_style(user_text: str) -> dict:
    """
    Heuristic, TEXT-based read of the user's message style (punctuation,
    capitalisation, a few Sinhala/emoji markers) — NOT real vocal tone/audio
    analysis, since the phone only sends transcribed text. Nudges Nova's TTS
    rate/pitch slightly so she doesn't sound identical whether the user is
    blunt/sharp or warm/affectionate. Deliberately small, bounded adjustments.
    """
    t = user_text.strip()
    if not t:
        return {"rate": 1.0, "pitch": 1.0}
    exclaims = t.count("!")
    letters = [c for c in t if c.isalpha()]
    caps_ratio = (sum(1 for c in letters if c.isupper()) / len(letters)) if letters else 0.0
    sharp = exclaims >= 2 or caps_ratio > 0.4 or any(m in t for m in _SHARP_MARKERS)
    warm = any(m in t for m in _WARM_MARKERS)
    if sharp:
        return {"rate": 1.12, "pitch": 0.95}
    if warm:
        return {"rate": 0.93, "pitch": 1.05}
    return {"rate": 1.0, "pitch": 1.0}

def run(user_text, conversation_id=None, screen=None, recent_activity=None):
    rid=str(uuid.uuid4())
    memories=search(user_text,12)
    context="\n".join(f"- {m['kind']}: {m['text']}" for m in memories) or "(none)"
    device_actions=[]

    prompt = SYSTEM + "\nMEMORY:\n" + context
    if screen:
        prompt += "\nCURRENT_SCREEN (everything visible on the phone right now — [button]/[input] tags show what's actionable, everything else is plain readable text):\n" + "\n".join(f"- {s}" for s in screen[:60])
    if recent_activity:
        prompt += "\nRECENT_PHONE_ACTIVITY (most recent first, ambient context — don't narrate all of it unprompted, only use what's relevant):\n" + \
            "\n".join(f"- {a.get('app','?')}: {a.get('title','')} — {a.get('text','')}" for a in recent_activity[:10])
    prompt += "\nUSER:\n" + user_text

    prev_id = get_last_response_id(conversation_id)
    kwargs = {"model": settings.model, "input": prompt, "tools": schemas()}
    if prev_id:
        kwargs["previous_response_id"] = prev_id
    response = client.responses.create(**kwargs)

    for _ in range(8):
        calls=[x for x in response.output if getattr(x,"type","")=="function_call"]
        if not calls: break
        outputs=[]
        for call in calls:
            args=json.loads(call.arguments)
            if call.name=="remember":
                result=REGISTRY["remember"].handler(**args); record(rid,"remember","LOW",False,result)
            elif call.name=="recall":
                result=REGISTRY["recall"].handler(**args); record(rid,"recall","LOW",False,{"count":len(result["items"])})
            elif call.name=="control_phone":
                action=args.get("action")
                risk=DEVICE_ALLOWED.get(action)
                if not risk:
                    result={"ok":False,"message":"Action is not allowlisted."}
                elif risk in ("HIGH","CRITICAL"):
                    result={"ok":False,"message":"HIGH risk action needs the user's confirmation on the phone; not queued automatically."}
                else:
                    device_actions.append({"action":action,"arguments":{k:v for k,v in args.items() if k!="action"},"risk":risk})
                    result={"ok":True,"message":"Queued for the phone to execute."}
                record(rid,f"control_phone:{action}",risk or "UNKNOWN",risk in ("HIGH","CRITICAL") if risk else False,result)
            else:
                result={"error":"unknown_tool"}
            outputs.append({"type":"function_call_output","call_id":call.call_id,"output":json.dumps(result,ensure_ascii=False)})
        response=client.responses.create(model=settings.model,previous_response_id=response.id,input=outputs,tools=schemas())

    set_last_response_id(conversation_id, response.id)

    reply_text = response.output_text or ""
    continue_task = bool(CONTINUE_RE.search(reply_text))
    reply_text = CONTINUE_RE.sub("", reply_text).strip()

    return {
        "request_id": rid,
        "reply": reply_text,
        "memory_used": memories,
        "device_actions": device_actions,
        "continue_task": continue_task,
        "voice": _voice_style(user_text),
    }
