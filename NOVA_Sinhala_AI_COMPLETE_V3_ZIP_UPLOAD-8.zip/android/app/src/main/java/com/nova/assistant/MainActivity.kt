package com.nova.assistant

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.MaterialTheme
import androidx.core.content.ContextCompat
import com.nova.assistant.ui.*

class MainActivity : ComponentActivity() {

    private fun prefs() = getSharedPreferences("p", Context.MODE_PRIVATE)

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { NovaBus.permissionsTick++ }

    private fun hasRequiredPermissions(): Boolean {
        val mic = ContextCompat.checkSelfPermission(this, android.Manifest.permission.RECORD_AUDIO)
        val notif = if (Build.VERSION.SDK_INT >= 33)
            ContextCompat.checkSelfPermission(this, android.Manifest.permission.POST_NOTIFICATIONS)
        else android.content.pm.PackageManager.PERMISSION_GRANTED
        return mic == android.content.pm.PackageManager.PERMISSION_GRANTED &&
                notif == android.content.pm.PackageManager.PERMISSION_GRANTED
    }

    private fun requestRequiredPermissions() {
        val needed = mutableListOf(android.Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) needed.add(android.Manifest.permission.POST_NOTIFICATIONS)
        permissionLauncher.launch(needed.toTypedArray())
    }

    private fun isIgnoringBatteryOptimizations(): Boolean {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        return pm.isIgnoringBatteryOptimizations(packageName)
    }

    @Suppress("BatteryLife")
    private fun requestIgnoreBatteryOptimizations() {
        val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
        intent.data = Uri.parse("package:$packageName")
        startActivity(intent)
    }

    private fun openAccessibilitySettings() {
        startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
    }

    private fun openNotificationListenerSettings() {
        startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
    }

    private fun startNova(url: String, token: String, autoStart: Boolean) {
        prefs().edit()
            .putString("url", url)
            .putString("token", token)
            .putBoolean("autostart", autoStart)
            .apply()
        val intent = Intent(this, VoiceService::class.java)
        ContextCompat.startForegroundService(this, intent)
    }

    private fun stopNova() {
        val intent = Intent(this, VoiceService::class.java).setAction(VoiceService.ACTION_STOP)
        startService(intent)
    }

    override fun onResume() {
        super.onResume()
        NovaBus.permissionsTick++
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val p = prefs()

        setContent {
            MaterialTheme {
                NovaHome(
                    initialUrl = p.getString("url", "") ?: "",
                    initialToken = p.getString("token", "") ?: "",
                    initialAutoStart = p.getBoolean("autostart", false),
                    hasPermissions = { hasRequiredPermissions() },
                    hasBatteryExemption = { isIgnoringBatteryOptimizations() },
                    permissionList = { PermissionCenter.list(this) },
                    onRequestPermissions = { requestRequiredPermissions() },
                    onRequestBatteryExemption = { requestIgnoreBatteryOptimizations() },
                    onOpenAccessibilitySettings = { openAccessibilitySettings() },
                    onOpenNotificationSettings = { openNotificationListenerSettings() },
                    onStart = { url, token, autoStart -> startNova(url, token, autoStart) },
                    onStop = { stopNova() }
                )
            }
        }
    }
}
