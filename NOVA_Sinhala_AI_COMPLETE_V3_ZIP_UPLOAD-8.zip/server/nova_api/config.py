import os
from dataclasses import dataclass
from dotenv import load_dotenv

load_dotenv()

@dataclass(frozen=True)
class Settings:
    gemini_api_key: str = os.getenv("GEMINI_API_KEY", "")
    model: str = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")
    token: str = os.getenv("NOVA_API_TOKEN", "")
    db_path: str = os.getenv("NOVA_DB_PATH", "./data/nova.sqlite3")
    host: str = os.getenv("NOVA_HOST", "127.0.0.1")
    port: int = int(os.getenv("NOVA_PORT", "8787"))

settings = Settings()
