# NOVA V12 — Universal Human-Agent Reliability Upgrade

V12 keeps the existing NOVA V11 project and strengthens the autonomous screen/action loop.

Flow:

1. User speaks/types a request.
2. NOVA captures the current Accessibility tree and live screen frame.
3. The model decides the next concrete action.
4. Android executes it.
5. Action results are returned.
6. NOVA captures the new screen and reasons again.
7. This repeats until `task_done`, a real user-only blocker, or the bounded safety depth is reached.

No Android security boundary is bypassed.
