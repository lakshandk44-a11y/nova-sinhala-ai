# ZIP structure

The source archive is intentionally a complete project archive, not a collection of
partial snippets.

The bootstrap workflow extracts the entire archive into `.nova-source`. It then uses the
detected project root without deleting unrelated files.

Required:
- android/
- server/
- docs/
- deploy/
- scripts/
- PROJECT_MANIFEST.md

The workflow only builds/checks the required targets; it does not rewrite or remove the
source tree.
