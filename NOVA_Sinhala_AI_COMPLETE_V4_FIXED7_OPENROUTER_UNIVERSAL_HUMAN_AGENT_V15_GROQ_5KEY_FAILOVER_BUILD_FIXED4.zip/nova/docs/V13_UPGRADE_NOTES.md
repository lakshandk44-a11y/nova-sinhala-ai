# NOVA V13 – Autonomous Observation/Action Upgrade

This release preserves the V12 project tree and existing features and strengthens the phone execution loop.

## Changes
- Increased the OpenRouter agent tool-loop ceiling from 12 to 24 model/tool turns.
- Android now fingerprints the accessibility screen before a device action.
- After executing actions, Android waits for the visible UI to change/settle before requesting the next reasoning turn.
- A completed action now triggers a fresh screen observation turn even when a free model forgets to emit `[CONTINUE]`.
- Failed/error actions still return through the next screen observation so the model can choose a different strategy.
- Existing lock-screen resume behavior remains intact.

## Verification
- Python server modules pass `python -m compileall`.
- The archive is rebuilt from the complete project tree.
- Android Gradle compilation was not run in this environment because the project does not contain `gradlew` and no Gradle installation is available.

## Important platform boundary
This does not and cannot bypass Android security boundaries such as PIN/password/CAPTCHA or protected UI. Those require user intervention. "Universal" means the agent can attempt generic accessibility/gesture interaction across apps; it is not a mathematical guarantee that every third-party UI is automatable.
