# Important limits

1. Android controls OS permissions and background execution.
2. Accessibility cannot legitimately grant arbitrary hidden access to every application.
3. A screen-off always-listening assistant requires a suitable Android audio/wake-word design
   and device testing; ordinary speech recognition is not a guaranteed hotword service.
4. The VPS cannot directly manipulate the phone unless the Android app is connected and
   authorized to execute a requested action.
5. The model must not be given unrestricted shell/root access.
6. Financial, destructive, credential and privacy-sensitive actions require confirmation.
