# V14 Upgrade Notes — Universal Human-Style Phone Control

This release keeps the existing NOVA V13 architecture and features and adds stronger local fallbacks for natural Sinhala/Singlish phone commands.

## Added

- Common app-opening commands can execute locally without waiting for the VPS/model.
- Standalone app names such as WhatsApp, YouTube, Facebook, Instagram, Telegram, Chrome, Camera, Gallery, Play Store and Settings can be opened directly.
- Natural-language tap/click/select commands can use the current accessibility screen and click the best visible matching control.
- Natural-language type/write/enter commands can focus the current editable field and type text locally.
- Speech recognition requests partial results and restarts faster after empty/error recognition results.
- Existing VPS + OpenRouter agent loop, live accessibility snapshot, one-frame screen image, action verification, continuation loop, memory, reminders, notifications, and permission/security boundaries are preserved.

## Important platform boundary

Android does not permit a normal app to have unrestricted, invisible control of every application or every secure surface. Nova can operate the phone through the AccessibilityService capabilities granted by Android, but secure credential screens, some FLAG_SECURE content, CAPTCHAs, payment confirmations, and other OS-protected operations can still require the user.

The screen image is a fresh frame captured for each reasoning turn/action cycle; it is not an unrestricted hidden continuous recorder.
