# NOVA Universal Human Agent V10 – Upgrade Notes

This build keeps the V9 architecture and existing features, and strengthens the missing execution path without removing the existing phone-control stack.

## Added / improved
- Fast on-device handling for natural “open/go to <app>” commands, avoiding a VPS round-trip for simple app navigation.
- Existing screen-aware accessibility actions remain intact: click by text/description/query, coordinate tap, type, scroll, swipe, long-press, Back, Home, Recents, notifications and settings panels.
- Existing live screen snapshot + accessibility tree are preserved.
- Existing automatic screen-refresh loop after UI-changing actions is preserved and given a slightly safer settle time.
- Existing unlock-block detection and resume flow is preserved.
- Existing Sinhala TTS / speech recognition / memory / reminders / notification awareness are preserved.
- Server Python sources pass `python -m compileall`.

## Important Android limits
No Android application can honestly guarantee unrestricted control of every screen. Secure credential screens, some protected apps, CAPTCHAs, OS permission confirmations, and certain system-protected toggles can require the user. V10 is designed to stop safely at those boundaries and resume the pending task after the user clears the blocker.

## Build note
The source is configured for Java/Kotlin JVM 17. Run the Android build with the project's Gradle wrapper or an installed Gradle/Android Studio environment. This container did not have Gradle installed, so an APK build could not be performed here.
