# VPS setup

```bash
sudo mkdir -p /opt/nova
sudo chown "$USER":"$USER" /opt/nova
cd /opt/nova
git clone YOUR_GITHUB_REPOSITORY .
cd server
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
nano .env
uvicorn nova_api.main:app --host 0.0.0.0 --port 8787
```

Install the systemd service from `deploy/nova.service` after verifying the backend.

Use HTTPS/reverse proxy in production.

## "unable to connect to VPS" checklist

This is almost always one of these five things, in order of how often it
actually happens:

1. **Server bound to 127.0.0.1 instead of 0.0.0.0.** `127.0.0.1` only
   accepts connections from inside the VPS itself — the phone app can
   never reach it, no matter what IP you type in the app. Both
   `.env.example` and `deploy/nova.service` now default to `0.0.0.0`;
   double check your `.env` doesn't still have `NOVA_HOST=127.0.0.1` from
   an older copy.
2. **Firewall / cloud security group not open on the port.** Run
   `sudo ufw allow 8787/tcp` (or open port 8787, or 443 if you're using
   nginx) — and if your VPS provider has its own firewall/security-group
   panel (Vultr, DigitalOcean, AWS, etc.), open it there too, not just in
   `ufw`.
3. **App is pointed at the wrong base URL.** It must be
   `http://YOUR_VPS_IP:8787` (no trailing slash) if you're hitting uvicorn
   directly, or `https://your-domain.com` if nginx+TLS is in front. `http`
   vs `https` and the port number are the most common typos.
4. **Token mismatch.** `NOVA_API_TOKEN` in `.env` on the server must be
   the *exact* same string entered in the app's Nova token field. A
   mismatch gives `401`, not a connection failure — if you're seeing
   "unable to connect" specifically (not a 401), it's #1–3 above.
5. **Server not actually running / crashed on start.** After starting it,
   confirm from *another machine* (not the VPS itself):
   ```bash
   curl -i http://YOUR_VPS_IP:8787/health -H "X-Nova-Token: YOUR_TOKEN"
   ```
   If that curl also fails, the problem is server/network-side (#1 or #2),
   not the Android app. If it succeeds but the app still fails, the
   problem is the app's saved base URL/token (#3/#4).

For production, don't skip the nginx + Let's Encrypt step in
`deploy/nginx.nova.conf.example` — keeping the raw HTTP port open long-term
means the token travels unencrypted and the phone can be pointed at by
anyone who finds the IP.
