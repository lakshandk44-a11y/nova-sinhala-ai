# Architecture

```text
YOU -> Sinhala Voice -> Android Nova
                         | UI / TTS / Permissions / Device Agent
                         |
                      HTTPS
                         v
                    Nova VPS
              API / Agent / Memory
                    |        |
                    v        v
                 Model     Tools
```

Phone = voice/UI/device execution surface.
VPS = AI orchestration/memory/tool surface.
