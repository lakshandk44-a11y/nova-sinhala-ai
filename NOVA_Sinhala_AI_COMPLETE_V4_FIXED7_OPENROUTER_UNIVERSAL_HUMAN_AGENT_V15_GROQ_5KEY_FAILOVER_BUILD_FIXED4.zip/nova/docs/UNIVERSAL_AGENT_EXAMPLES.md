# Universal command examples

The assistant accepts natural language rather than requiring technical action names.

- "Settings open කරන්න" / "සෙටින් ඇරන්න"
- "WhatsApp open කරන්න"
- "Back යන්න"
- "Recent apps open කරන්න"
- "Notifications පෙන්නන්න"
- "පහළට scroll කරන්න"
- "මේක tap කරන්න" + a visible label
- "මේක type කරන්න ..." when an input is visible
- "Screen එක කියවලා මට කියන්න"
- Compound requests such as "WhatsApp open කරලා ..." are delegated to the agent so it can inspect the screen between steps.

These examples are additions; existing NOVA features remain in place.
