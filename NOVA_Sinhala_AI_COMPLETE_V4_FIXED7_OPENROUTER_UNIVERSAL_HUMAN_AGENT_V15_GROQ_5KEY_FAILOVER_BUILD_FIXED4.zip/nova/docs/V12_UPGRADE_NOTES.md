# NOVA V12 Upgrade Notes

This release preserves the existing V11 project and adds reliability to the autonomous observation/action loop.

## Changes
- Failed UI actions no longer automatically terminate an active phone task.
- `action_results` are fed into the next reasoning turn so the agent can inspect the fresh screen and choose an alternative action.
- Successful and failed UI actions both trigger a bounded fresh-screen observation turn unless the agent explicitly marks the task complete.
- Android waits slightly longer after a failed/error action before taking the next observation, while successful actions keep a short delay for responsiveness.
- Existing Accessibility, screen-image capture, voice, memory, reminders, app navigation, UI actions, lock-screen handling, and OpenRouter compatibility are preserved.

## Platform boundary
Android still controls secure surfaces such as PIN/password entry and CAPTCHA. NOVA does not bypass those protections; it pauses and resumes after the user clears the blocker.
