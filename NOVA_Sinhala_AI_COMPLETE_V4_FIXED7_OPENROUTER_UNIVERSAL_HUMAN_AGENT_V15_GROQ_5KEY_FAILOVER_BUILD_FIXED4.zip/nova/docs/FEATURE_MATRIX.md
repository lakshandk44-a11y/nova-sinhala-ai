# Feature matrix

| Feature | Foundation | Production completion |
|---|---|---|
| Sinhala conversation | Yes | streaming optimization |
| VPS AI backend | Yes | production hardening |
| Memory | Yes | semantic/vector memory |
| Voice input | Yes | dedicated wake-word engine |
| Sinhala TTS | Yes | premium streaming voice |
| Android foreground service | Yes | device/OEM testing |
| Accessibility device control | Yes | per-action dispatcher |
| Permission Center | Foundation | Compose UI |
| Futuristic UI | specification | full animated Compose UI |
| Tool registry | Yes | more adapters |
| Audit | Yes | retention/export policy |
| Scheduler | architecture | implementation |
| Self-maintenance | architecture | bounded jobs |
| GitHub APK build | Yes | signing/release pipeline |
| VPS deployment | Yes | HTTPS/monitoring/backups |
