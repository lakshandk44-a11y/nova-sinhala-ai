# Security

- Keep API keys and tokens outside Git.
- Authenticate every VPS request.
- Never give the model unrestricted shell access.
- Android permissions are user-granted.
- High/critical tools require confirmation.
- Audit every tool execution.
- Do not keep sensitive voice data indefinitely by default.
