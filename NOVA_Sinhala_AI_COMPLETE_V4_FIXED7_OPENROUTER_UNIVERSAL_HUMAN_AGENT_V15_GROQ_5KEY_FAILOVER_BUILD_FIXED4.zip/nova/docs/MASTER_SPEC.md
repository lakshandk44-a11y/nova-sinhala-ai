# NOVA MASTER SPECIFICATION

Nova is a Sinhala-first personal AI companion/agent.

## Core experience
LISTEN -> UNDERSTAND -> RECALL -> PLAN -> ACT -> OBSERVE -> VERIFY -> SPEAK -> REMEMBER

- Natural Sinhala conversation.
- Long-term memory.
- Multi-step task planning.
- User-authorized Android device actions.
- VPS AI/orchestration.
- Permission center.
- Futuristic animated UI.
- Task/activity/audit views.
- Recovery/persistence strategy within Android rules.
- Controlled self-maintenance.

## Android
The app is the device execution surface. It can use only permissions/capabilities granted
by Android and the user. Accessibility is used only after the user enables it. A normal
third-party app cannot guarantee unrestricted control of every app or an unkillable
screen-off microphone process; OEM and Android restrictions remain.

## UI
Original implementation inspired by the user's supplied futuristic reference:
animated central AI core, rings, waveform, live transcript, task cards, tool/device/memory
status, listening/thinking/executing/speaking/error/offline states.

## Memory
profile, preference, project, task, episodic, conversation summary.
Operations: save, recall, update, forget, compact, health, export.

## Agent
Tools are allowlisted and have:
name, schema, risk, confirmation requirement, timeout, audit policy.

High/critical actions require confirmation.

## Self maintenance
Monitor disk, database size, logs, service health and backups. Maintenance is bounded,
audited and must not silently rewrite/deploy arbitrary production code.
