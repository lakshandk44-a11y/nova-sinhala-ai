# NOVA V15 — Groq Multi-Key Failover

V15 keeps the V14 phone-control/agent architecture and adds a provider failover path for OpenRouter rate limits and temporary outages.

## What changed

- Existing OpenRouter path remains the primary provider when `AI_PROVIDER=openrouter`.
- If OpenRouter returns a rate-limit/quota or temporary 5xx/timeout failure, NOVA can automatically retry the same task through Groq.
- `GROQ_KEYS` accepts multiple API keys separated by commas. The implementation rotates the starting key for each request and tries the remaining configured keys after a 429/temporary failure.
- The current default Groq model is `llama-3.3-70b-versatile`, which supports tool use and JSON mode.
- If a Groq model rejects the attached screen image, NOVA retries the request without the image and keeps the live accessibility-tree snapshot, so phone control can still continue.
- `/health` reports only the number of configured Groq keys, never the keys themselves.

## Configuration

In the real VPS `server/.env` (do not commit real secrets):

```text
GROQ_KEYS=YOUR_KEY_1,YOUR_KEY_2,YOUR_KEY_3,YOUR_KEY_4,YOUR_KEY_5
GROQ_MODEL=llama-3.3-70b-versatile
GROQ_BASE_URL=https://api.groq.com/openai/v1
```

The five values must be real Groq API keys. If they belong to the same account/organization, they may share the same quota; five keys do not mathematically guarantee five independent quotas.

## Phone-control behavior retained

The existing V14 Android accessibility service, screen snapshot, per-turn screen image, action execution, action-result feedback, autonomous continuation loop, reminders, memory, voice service, and security/confirmation boundaries remain in the ZIP. V15 does not remove those features.

## Important platform limit

The screen image is captured as a fresh frame for each reasoning turn, not as a hidden continuous video stream. Android security boundaries such as secure credential screens, CAPTCHA/payment confirmations, and other OS-protected surfaces can still require the user.
