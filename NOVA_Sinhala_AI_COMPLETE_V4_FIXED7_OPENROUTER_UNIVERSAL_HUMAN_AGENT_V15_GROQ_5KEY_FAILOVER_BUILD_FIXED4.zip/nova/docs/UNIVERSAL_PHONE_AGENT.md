# NOVA Universal Phone Agent

This layer extends the existing NOVA controls without removing the original features.

## Behavior
- Simple controls such as Back, Home, Recents, Quick Settings, Settings, Wi-Fi, Bluetooth, volume, visible-text tap, typing and screen reading can execute locally for low latency.
- Compound requests are sent to the existing OpenRouter agent with the current accessibility screen snapshot.
- After UI-changing actions, NOVA automatically requests a fresh screen snapshot and continues the task until `task_done` or a genuine Android/platform blocker.
- The agent must not claim a phone action happened unless the device reports an execution result.
- Screen reading uses Android Accessibility content, not a hidden or unrestricted screen recorder.

## Platform limits
Android still controls secure screens, lock/PIN prompts, CAPTCHAs, some permission dialogs, and other protected surfaces. NOVA stops at those boundaries and resumes after the user handles the blocker.
