# Android setup

1. Push the project to GitHub.
2. Run Actions -> Build Nova Android APK.
3. Install the generated APK.
4. Configure the VPS HTTPS endpoint and Nova token.
5. Grant microphone and notification permissions.
6. Enable Accessibility only if device control is wanted.
7. Review battery/background restrictions on the target phone.
8. Start Nova.

The architecture supports foreground operation and recovery, but Android/OEM policies can
still stop background work. Production always-on wake-word behavior requires a dedicated
wake-word/audio implementation and device testing.
