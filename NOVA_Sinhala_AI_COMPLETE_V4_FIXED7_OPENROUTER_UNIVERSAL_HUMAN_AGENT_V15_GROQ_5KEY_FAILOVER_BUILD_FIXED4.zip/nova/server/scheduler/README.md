# Scheduler
Scheduled tasks need owner, schedule, action, risk, confirmation policy, retries,
last-run and next-run state. APScheduler is included as the first dependency.
