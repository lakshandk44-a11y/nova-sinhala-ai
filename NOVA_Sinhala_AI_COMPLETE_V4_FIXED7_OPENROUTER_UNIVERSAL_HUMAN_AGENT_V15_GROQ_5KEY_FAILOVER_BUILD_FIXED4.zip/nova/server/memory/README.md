# Memory

Initial SQLite memory is implemented in `app.py`. Production evolution should split retrieval, compaction, deletion, semantic search and backups into modules here.
