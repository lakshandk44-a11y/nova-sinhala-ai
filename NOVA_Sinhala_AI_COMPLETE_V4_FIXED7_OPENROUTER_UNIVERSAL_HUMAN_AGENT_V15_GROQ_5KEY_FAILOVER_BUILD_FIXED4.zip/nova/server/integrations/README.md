# Integrations
Future controlled adapters: GitHub, calendar, messaging, web/search, VPS operations
and project tools. Each adapter gets narrow schemas and explicit permissions.
