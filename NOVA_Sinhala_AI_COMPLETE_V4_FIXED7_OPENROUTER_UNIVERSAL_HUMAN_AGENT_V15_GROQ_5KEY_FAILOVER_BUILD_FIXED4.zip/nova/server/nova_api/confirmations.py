import time, uuid
_pending={}

def request(action,arguments,risk="HIGH"):
    cid=str(uuid.uuid4())
    _pending[cid]={"id":cid,"action":action,"arguments":arguments,"risk":risk,"created":time.time(),"expires":time.time()+120}
    return _pending[cid]

def resolve(cid,approved):
    item=_pending.pop(cid,None)
    if not item or item["expires"]<time.time(): return {"ok":False,"reason":"expired_or_missing"}
    return {"ok":True,"approved":bool(approved),"confirmation":item}
