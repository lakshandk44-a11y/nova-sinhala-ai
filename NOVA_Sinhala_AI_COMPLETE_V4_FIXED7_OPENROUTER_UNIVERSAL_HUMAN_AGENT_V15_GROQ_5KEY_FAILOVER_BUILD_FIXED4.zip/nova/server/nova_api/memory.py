import time, json
from .db import connect

def remember(kind, text, tags=""):
    now=time.time()
    c=connect()
    c.execute("INSERT INTO memory(kind,text,tags,created_at,updated_at) VALUES(?,?,?,?,?)",(kind,text,tags,now,now))
    c.commit(); c.close()

def search(query, limit=20):
    c=connect()
    rows=c.execute("SELECT id,kind,text,tags,updated_at FROM memory ORDER BY updated_at DESC LIMIT 5000").fetchall()
    c.close()
    terms=[x.lower() for x in query.split() if len(x)>1]
    scored=[]
    for r in rows:
        hay=f"{r['kind']} {r['text']} {r['tags']}".lower()
        score=sum(t in hay for t in terms)
        if score: scored.append((score,r["updated_at"],dict(r)))
    scored.sort(reverse=True)
    return [x[2] for x in scored[:limit]]

def forget(memory_id):
    c=connect(); c.execute("DELETE FROM memory WHERE id=?",(memory_id,)); c.commit(); c.close()

def health():
    c=connect()
    count=c.execute("SELECT COUNT(*) FROM memory").fetchone()[0]
    c.close()
    return {"memory_count":count}
