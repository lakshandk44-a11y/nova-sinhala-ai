"""
Picks which free-tier Gemini model to use for a given request, and gives
agent.py an ordered fallback list to retry against if a model's free quota
is exhausted (429 / RESOURCE_EXHAUSTED) or it errors out.

Nothing here calls the network — it's pure text heuristics over the user's
message (+ whether tools/screen context are involved), so it's cheap to run
on every request.
"""
from .config import settings

# Substrings that mark a model ID as non-text (image/audio/tts/agent
# generation) rather than a plain chat model. Shared with agent.py's final
# safety net before it ever spends a network call on a candidate.
NON_TEXT_MODEL_MARKERS = ("image", "audio", "tts", "-live", "agent", "deep-research", "vision")


# Rough weight classes among the free-tier models. Higher = more capable /
# more expensive against the free quota, so we only reach for it when the
# task actually looks like it needs it.
_WEIGHT = {
    "gemini-3.1-flash-lite": 0,
    "gemini-3.5-flash-lite": 0,
    "gemini-3.5-flash": 1,
    "gemini-3.6-flash": 1,
    "gemini-3.1-pro-preview": 2,
    # kept for backwards compatibility if an older .env is still in use
    "gemini-2.0-flash-lite": 0,
    "gemini-2.5-flash-lite": 0,
    "gemini-2.0-flash": 1,
    "gemini-2.5-flash": 1,
    "gemini-2.5-pro": 2,
}

_HARD_KEYWORDS = (
    "code", "බග්", "bug", "debug", "error", "traceback", "regex",
    "hesalanna", "ගණන", "calculate", "compare", "analy", "explain why",
    "plan", "step by step", "step-by-step", "translate", "summarize",
    "summarise", "පින්තූර", "image", "json", "sql", "algorithm",
)


def _complexity_score(user_text: str, screen: list | None, recent_activity: list | None) -> int:
    t = (user_text or "").strip()
    score = 0
    length = len(t)
    if length > 400:
        score += 2
    elif length > 120:
        score += 1
    if any(k in t.lower() for k in _HARD_KEYWORDS):
        score += 1
    if t.count("?") >= 2:
        score += 1
    if screen:
        score += 1  # reasoning over on-screen UI needs more care
    if recent_activity and len(recent_activity) > 5:
        score += 1
    return score


def pick_models(user_text: str, screen: list | None = None, recent_activity: list | None = None) -> list[str]:
    # OpenRouter has its own model router. Keep the rest of Nova's model
    # selection logic unchanged for Gemini.
    if getattr(settings, "provider", "gemini") == "openrouter":
        return [settings.openrouter_model]
    """
    Returns an ordered list of model IDs to try, most-appropriate first,
    all drawn from settings.models (GEMINI_MODELS env, comma separated).
    agent.py should call the API with models[0], and on a 429/quota/5xx
    error retry with the next one in the list before giving up.
    """
    candidates = list(settings.models) or [settings.model]

    # Defense in depth: no matter where a candidate list comes from (.env,
    # DEFAULT_FREE_MODELS, or model_discovery's auto-discovery), never let a
    # non-text model (image/audio/tts/agent generation) end up in the chat
    # fallback chain. Calling those through this text `interactions.create`
    # path always fails (400/404/429-with-zero-quota) and, if it happens to
    # be the *last* candidate, that failure is what actually surfaces to the
    # user instead of a real answer.
    candidates = [m for m in candidates if not any(k in m for k in NON_TEXT_MODEL_MARKERS)] or candidates

    if not settings.auto_model_select:
        # Manual pin: always try the configured model first, then fall
        # back through the rest of the free list if it's out of quota.
        # (settings.model itself also passes through the same non-text
        # filter as the auto-select candidates above — a pinned image/
        # audio/agent model in GEMINI_MODEL would otherwise bypass the
        # filter entirely and always fail with a permanent zero-quota
        # 429, since those models simply aren't on the free chat tier.)
        pinned = settings.model
        if any(k in pinned for k in NON_TEXT_MODEL_MARKERS):
            pinned = candidates[0] if candidates else pinned
        ordered = [pinned] + [m for m in candidates if m != pinned]
        return ordered

    score = _complexity_score(user_text, screen, recent_activity)
    target_weight = 2 if score >= 3 else (1 if score >= 1 else 0)

    def weight(m: str) -> int:
        return _WEIGHT.get(m, 1)

    # Best match for the target weight class first...
    same = [m for m in candidates if weight(m) == target_weight]
    # ...then progressively cheaper models as quota-exhaustion fallbacks...
    lighter = sorted((m for m in candidates if weight(m) < target_weight), key=weight, reverse=True)
    # ...and heavier ones as a last resort if everything lighter is out of quota.
    heavier = sorted((m for m in candidates if weight(m) > target_weight), key=weight)

    ordered = same + lighter + heavier
    seen = set()
    result = []
    for m in ordered:
        if m not in seen:
            seen.add(m)
            result.append(m)
    return result or [settings.model]
