from fastapi import Header, HTTPException
from .config import settings

def require_auth(x_nova_token: str | None = Header(default=None)):
    if not settings.token or x_nova_token != settings.token:
        raise HTTPException(status_code=401, detail="Invalid Nova token")
