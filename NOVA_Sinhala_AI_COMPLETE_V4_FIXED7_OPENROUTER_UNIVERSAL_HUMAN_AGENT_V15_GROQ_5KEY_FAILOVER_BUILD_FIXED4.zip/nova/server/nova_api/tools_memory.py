from .tools import register, Tool
from .memory import remember, search, forget

def save_memory(kind,text,tags=""):
    remember(kind,text,tags); return {"ok":True}

def recall_memory(query):
    return {"items":search(query)}

def delete_memory(memory_id):
    forget(memory_id); return {"ok":True}

register(Tool("remember","Save durable memory.","LOW",False,save_memory))
register(Tool("recall","Search Nova memory.","LOW",False,recall_memory))
register(Tool("forget_memory","Delete a memory item.","HIGH",True,delete_memory))
