from pydantic import BaseModel, Field
from typing import Any

class DeviceAction(BaseModel):
    request_id: str
    action_id: str
    action: str
    arguments: dict[str, Any] = Field(default_factory=dict)
    permission: str
    risk: str = "LOW"
    requires_confirmation: bool = False

class ActionResult(BaseModel):
    request_id: str
    action_id: str
    ok: bool
    message: str
    data: dict[str, Any] = Field(default_factory=dict)
