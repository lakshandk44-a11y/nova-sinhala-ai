import json, time
from .db import connect

def record(request_id, tool, risk, confirmation, result):
    c=connect()
    c.execute("INSERT INTO audit(request_id,tool,risk,confirmation,result,created_at) VALUES(?,?,?,?,?,?)",
              (request_id,tool,risk,int(confirmation),json.dumps(result,ensure_ascii=False),time.time()))
    c.commit(); c.close()

def recent(limit=200):
    c=connect()
    rows=c.execute("SELECT request_id,tool,risk,confirmation,result,created_at FROM audit ORDER BY id DESC LIMIT ?",(limit,)).fetchall()
    c.close()
    return [dict(r) for r in rows]
