from dataclasses import dataclass
from typing import Any, Callable

@dataclass
class Tool:
    name: str
    description: str
    risk: str
    confirmation: bool
    handler: Callable[..., Any]

REGISTRY={}

def register(tool): REGISTRY[tool.name]=tool
def get(name): return REGISTRY.get(name)
def list_tools():
    return [{"name":t.name,"description":t.description,"risk":t.risk,"confirmation":t.confirmation} for t in REGISTRY.values()]
