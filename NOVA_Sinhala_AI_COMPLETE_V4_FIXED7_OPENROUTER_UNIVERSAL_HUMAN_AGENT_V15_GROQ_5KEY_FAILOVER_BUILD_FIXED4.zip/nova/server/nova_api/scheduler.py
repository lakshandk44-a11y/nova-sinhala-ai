import time, threading
from .tasks import list_tasks

class Scheduler:
    def __init__(self): self.running=False
    def start(self):
        if self.running:return
        self.running=True
        threading.Thread(target=self.loop,daemon=True).start()
    def loop(self):
        while self.running:
            # Scheduler intentionally observes tasks first. Actual action dispatch should
            # go through the same authenticated Android permission/confirmation pipeline.
            time.sleep(10)
