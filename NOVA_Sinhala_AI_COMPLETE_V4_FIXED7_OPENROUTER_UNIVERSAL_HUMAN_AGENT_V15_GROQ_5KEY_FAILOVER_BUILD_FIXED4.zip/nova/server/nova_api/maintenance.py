import os, shutil, time
from pathlib import Path
from .config import settings

def health():
    root=Path(settings.db_path).resolve().parent
    total,used,free=shutil.disk_usage(root)
    db=Path(settings.db_path)
    return {
      "disk_total_bytes":total,"disk_used_bytes":used,"disk_free_bytes":free,
      "database_bytes":db.stat().st_size if db.exists() else 0,
      "timestamp":time.time()
    }

def bounded_cleanup(max_db_bytes=500*1024*1024):
    # Intentionally conservative: never delete database records automatically.
    h=health()
    return {"ok":h["database_bytes"]<=max_db_bytes,"health":h,"action":"no destructive cleanup performed"}
