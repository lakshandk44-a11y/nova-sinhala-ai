"""
Lightweight session continuity so Nova keeps real dialogue context turn to
turn (not just long-term memory), and so a multi-step in-app task can be
resumed as the phone reports back updated screen state.
"""
import time
from .db import connect

def _ensure_table():
    c = connect()
    c.execute(
        "CREATE TABLE IF NOT EXISTS conversations ("
        "conversation_id TEXT PRIMARY KEY, "
        "last_response_id TEXT, "
        "updated_at REAL NOT NULL)"
    )
    c.commit()
    c.close()

_ensure_table()

def get_last_response_id(conversation_id: str | None):
    if not conversation_id:
        return None
    c = connect()
    row = c.execute(
        "SELECT last_response_id FROM conversations WHERE conversation_id=?",
        (conversation_id,),
    ).fetchone()
    c.close()
    return row["last_response_id"] if row else None

def set_last_response_id(conversation_id: str | None, response_id: str):
    if not conversation_id:
        return
    c = connect()
    c.execute(
        "INSERT INTO conversations (conversation_id, last_response_id, updated_at) VALUES (?,?,?) "
        "ON CONFLICT(conversation_id) DO UPDATE SET last_response_id=excluded.last_response_id, updated_at=excluded.updated_at",
        (conversation_id, response_id, time.time()),
    )
    c.commit()
    c.close()
