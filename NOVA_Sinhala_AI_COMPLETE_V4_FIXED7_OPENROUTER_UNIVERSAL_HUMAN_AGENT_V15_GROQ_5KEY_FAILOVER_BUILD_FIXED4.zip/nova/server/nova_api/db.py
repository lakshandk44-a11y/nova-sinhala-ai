import sqlite3
from pathlib import Path
from .config import settings

def connect():
    Path(settings.db_path).parent.mkdir(parents=True, exist_ok=True)
    c = sqlite3.connect(settings.db_path)
    c.row_factory = sqlite3.Row
    c.execute("CREATE TABLE IF NOT EXISTS memory (id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT NOT NULL, text TEXT NOT NULL, tags TEXT DEFAULT '', created_at REAL NOT NULL, updated_at REAL NOT NULL)")
    c.execute("CREATE TABLE IF NOT EXISTS audit (id INTEGER PRIMARY KEY AUTOINCREMENT, request_id TEXT, tool TEXT, risk TEXT, confirmation INTEGER, result TEXT, created_at REAL NOT NULL)")
    c.commit()
    return c
