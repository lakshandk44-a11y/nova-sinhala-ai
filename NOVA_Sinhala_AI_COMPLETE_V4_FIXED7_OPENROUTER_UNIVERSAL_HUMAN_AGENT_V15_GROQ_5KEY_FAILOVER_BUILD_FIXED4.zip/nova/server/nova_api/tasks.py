import sqlite3, time, uuid
from .db import connect

def init():
    c=connect()
    c.execute("""CREATE TABLE IF NOT EXISTS tasks(
      id TEXT PRIMARY KEY, title TEXT NOT NULL, schedule TEXT, enabled INTEGER NOT NULL,
      action TEXT NOT NULL, args TEXT DEFAULT '{}', risk TEXT DEFAULT 'LOW',
      requires_confirmation INTEGER DEFAULT 0, last_run REAL, next_run REAL)""")
    c.commit(); c.close()

def create(title,schedule,action,args="{}",risk="LOW",confirmation=True):
    init(); tid=str(uuid.uuid4())
    c=connect()
    c.execute("INSERT INTO tasks VALUES(?,?,?,?,?,?,?,?,?,?)",
      (tid,title,schedule,1,action,args,risk,int(confirmation),None,None))
    c.commit(); c.close(); return tid

def list_tasks():
    init(); c=connect()
    rows=c.execute("SELECT * FROM tasks ORDER BY title").fetchall()
    c.close(); return [dict(r) for r in rows]

def set_enabled(task_id,enabled):
    init(); c=connect(); c.execute("UPDATE tasks SET enabled=? WHERE id=?",(int(enabled),task_id)); c.commit(); c.close()
