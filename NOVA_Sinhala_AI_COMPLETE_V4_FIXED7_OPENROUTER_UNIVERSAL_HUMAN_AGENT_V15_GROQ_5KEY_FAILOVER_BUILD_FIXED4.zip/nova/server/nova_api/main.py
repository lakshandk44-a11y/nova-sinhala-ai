from fastapi import FastAPI, Header
from pydantic import BaseModel
from .config import settings
from .security import require_auth
from .agent import run
from .memory import search, health
from .audit import recent
from .tools import list_tools
from . import tools_memory
from .models import DeviceAction
from .device import enqueue
from .tasks import list_tasks,create,set_enabled
from .maintenance import health as maintenance_health,bounded_cleanup
from .confirmations import request as create_confirmation, resolve as resolve_confirmation

app=FastAPI(title="Nova Sinhala AI",version="2.0.0")

class ChatRequest(BaseModel):
    text:str
    conversation_id:str|None=None
    screen:list[str]|None=None
    recent_activity:list[dict]|None=None
    action_results:list[str]|None=None
    device_state:dict|None=None
    screen_image_base64:str|None=None
    screen_image_mime:str|None=None

class TaskRequest(BaseModel):
    title:str; schedule:str; action:str; args:str="{}"; risk:str="LOW"; requires_confirmation:bool=True

class ConfirmationRequest(BaseModel):
    action:str; arguments:dict={}; risk:str="HIGH"

@app.get("/health")
def health_endpoint(x_nova_token: str|None=Header(default=None)):
    require_auth(x_nova_token); return {"ok":True,"model":settings.model,"models":list(settings.models),"auto_model_select":settings.auto_model_select,"service":"nova","openrouter_configured":bool(settings.openrouter_api_key),"groq_keys_configured":len(getattr(settings,"groq_keys",()) or ())}

@app.post("/chat")
def chat(req:ChatRequest,x_nova_token: str|None=Header(default=None)):
    require_auth(x_nova_token); return run(req.text, req.conversation_id, req.screen, req.recent_activity, req.action_results, req.device_state, req.screen_image_base64, req.screen_image_mime)

@app.get("/memory")
def memory(q:str="",x_nova_token: str|None=Header(default=None)):
    require_auth(x_nova_token); return {"items":search(q,100) if q else []}

@app.get("/memory/health")
def memory_health(x_nova_token: str|None=Header(default=None)):
    require_auth(x_nova_token); return health()

@app.get("/tools")
def tools(x_nova_token: str|None=Header(default=None)):
    require_auth(x_nova_token); return {"tools":list_tools()}

@app.get("/audit")
def audit(x_nova_token: str|None=Header(default=None)):
    require_auth(x_nova_token); return {"items":recent()}

@app.post("/device/action")
def device_action(a:DeviceAction,x_nova_token: str|None=Header(default=None)):
    require_auth(x_nova_token); return enqueue(a)

@app.get("/tasks")
def tasks(x_nova_token: str|None=Header(default=None)):
    require_auth(x_nova_token); return {"tasks":list_tasks()}

@app.post("/tasks")
def task_create(t:TaskRequest,x_nova_token: str|None=Header(default=None)):
    require_auth(x_nova_token)
    return {"id":create(t.title,t.schedule,t.action,t.args,t.risk,t.requires_confirmation)}

@app.post("/tasks/{task_id}/enabled/{enabled}")
def task_enabled(task_id:str,enabled:bool,x_nova_token: str|None=Header(default=None)):
    require_auth(x_nova_token); set_enabled(task_id,enabled); return {"ok":True}

@app.get("/maintenance")
def maintenance(x_nova_token: str|None=Header(default=None)):
    require_auth(x_nova_token); return maintenance_health()

@app.post("/maintenance/safe-check")
def maintenance_check(x_nova_token: str|None=Header(default=None)):
    require_auth(x_nova_token); return bounded_cleanup()

@app.post("/confirmations")
def confirmation(r:ConfirmationRequest,x_nova_token: str|None=Header(default=None)):
    require_auth(x_nova_token); return create_confirmation(r.action,r.arguments,r.risk)

@app.post("/confirmations/{cid}/{approved}")
def confirmation_resolve(cid:str,approved:bool,x_nova_token: str|None=Header(default=None)):
    require_auth(x_nova_token); return resolve_confirmation(cid,approved)
