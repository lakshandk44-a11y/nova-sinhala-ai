# Realtime channel
Authenticated WebSocket channel planned for partial STT, assistant state, tool progress,
confirmation events and streaming audio. REST `/chat` remains the fallback.
