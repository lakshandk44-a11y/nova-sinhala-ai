# Agent

Reserved for planner, tool selection, bounded multi-step execution, observation, retries and confirmations.
