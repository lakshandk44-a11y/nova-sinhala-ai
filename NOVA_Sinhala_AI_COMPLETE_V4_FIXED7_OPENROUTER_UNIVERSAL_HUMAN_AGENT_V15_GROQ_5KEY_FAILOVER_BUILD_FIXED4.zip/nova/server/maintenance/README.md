# Maintenance
Bounded health tasks: disk usage, database size, log cleanup, backup checks and service
health. Destructive operations require explicit policy/confirmation.
