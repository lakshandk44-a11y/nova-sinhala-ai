# Security

Reserved for authentication, authorization, risk policy, secret handling, audit and confirmation policy.
