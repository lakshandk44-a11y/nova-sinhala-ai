# Wake word
Production always-on wake-word engine belongs here. A dedicated on-device wake engine
must be selected/tested for the actual phone. Android SpeechRecognizer alone is not a
guaranteed hotword detector.
