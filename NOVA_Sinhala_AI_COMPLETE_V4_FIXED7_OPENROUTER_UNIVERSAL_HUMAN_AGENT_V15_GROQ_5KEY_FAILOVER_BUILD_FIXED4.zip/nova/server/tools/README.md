# Tool registry

Production tools must define name, JSON schema, risk class, permission requirement,
timeout, audit behavior and destructive/reversible status. Never expose unrestricted
shell execution to the model.
