# NOVA - ZIP-first GitHub workflow

## Important GitHub limitation

GitHub does not execute files merely because they are inside an uploaded ZIP.
A GitHub Actions workflow itself must exist in `.github/workflows/` in the repository.

Therefore the reliable ZIP-first arrangement is:

1. Create an empty GitHub repository.
2. Put the bootstrap files from this package into the repository once.
3. Rename the complete NOVA source archive to `nova-source.zip`.
4. Upload `nova-source.zip`.
5. GitHub Actions extracts the archive.
6. The workflow validates `android/`, `server/`, and the project manifest.
7. The backend is syntax-checked.
8. The Android Gradle project is built.
9. The resulting APK is uploaded as a GitHub Actions artifact.

## Why this is different from "GitHub automatically opens ZIP"

GitHub itself does not automatically unpack arbitrary ZIP uploads into a repository.
The workflow performs that extraction explicitly.

## Phone-only usage

The repository can be operated from the GitHub Android/mobile website. The Actions
workflow can be started from the Actions tab after the ZIP is uploaded.

## Required source ZIP structure

The source archive must contain:

android/
server/
docs/
deploy/
scripts/
PROJECT_MANIFEST.md

It can also contain the other NOVA directories/files. Nothing from the source should
be silently discarded by the bootstrap workflow.

## Production rule

Do not put secrets, API keys, VPS passwords, signing keys, or private tokens in the ZIP.
Use GitHub Actions Secrets and/or the VPS environment file.
