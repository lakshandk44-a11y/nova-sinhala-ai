package com.nova.assistant.ui

enum class NovaState { IDLE, LISTENING, THINKING, EXECUTING, SPEAKING, CONFIRMATION, ERROR, OFFLINE }

data class NovaUiState(
    val state: NovaState = NovaState.IDLE,
    val transcript: String = "",
    val response: String = "",
    val task: String = "",
    val connected: Boolean = false,
    val memoryCount: Int = 0
)
