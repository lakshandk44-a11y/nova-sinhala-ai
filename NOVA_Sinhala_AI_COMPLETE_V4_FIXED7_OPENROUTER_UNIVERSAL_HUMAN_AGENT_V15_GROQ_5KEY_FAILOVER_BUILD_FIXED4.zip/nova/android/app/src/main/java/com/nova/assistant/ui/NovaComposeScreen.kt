package com.nova.assistant.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.nova.assistant.NovaBus

/**
 * Root screen. Holds the settings form (VPS URL / token / auto-start) and
 * shows the live state published by VoiceService via NovaBus, so the UI
 * reflects what the persistent background service is actually doing.
 */
@Composable
fun NovaHome(
    initialUrl: String,
    initialToken: String,
    initialAutoStart: Boolean,
    hasPermissions: () -> Boolean,
    hasBatteryExemption: () -> Boolean,
    permissionList: () -> List<com.nova.assistant.NovaPermission>,
    onRequestPermissions: () -> Unit,
    onRequestBatteryExemption: () -> Unit,
    onOpenAccessibilitySettings: () -> Unit,
    onOpenNotificationSettings: () -> Unit,
    onStart: (url: String, token: String, autoStart: Boolean) -> Unit,
    onStop: () -> Unit
) {
    var url by remember { mutableStateOf(initialUrl) }
    var token by remember { mutableStateOf(initialToken) }
    var autoStart by remember { mutableStateOf(initialAutoStart) }
    var showSettings by remember { mutableStateOf(initialUrl.isBlank()) }
    val tick = com.nova.assistant.NovaBus.permissionsTick // establishes recomposition dependency

    val infinite = rememberInfiniteTransition(label = "nova")
    val pulse by infinite.animateFloat(
        0.85f, 1.15f,
        infiniteRepeatable(tween(1200), RepeatMode.Reverse), label = "pulse"
    )
    val pulseColor = MaterialTheme.colorScheme.primary

    Column(
        Modifier
            .fillMaxSize()
            .padding(18.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("NOVA", style = MaterialTheme.typography.headlineMedium)
            TextButton(onClick = { showSettings = !showSettings }) {
                Text(if (showSettings) "වහන්න" else "Settings")
            }
        }
        Text(stateLabel(NovaBus.state))

        Canvas(Modifier.fillMaxWidth().height(220.dp)) {
            val c = Offset(size.width / 2, size.height / 2)
            drawCircle(color = pulseColor, radius = 80f * pulse, center = c)
            drawCircle(color = pulseColor, radius = 120f * pulse, center = c, alpha = .18f)
            drawCircle(color = pulseColor, radius = 160f * pulse, center = c, alpha = .08f)
        }

        if (NovaBus.transcript.isNotBlank()) {
            Text("ඔයා: " + NovaBus.transcript, style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(6.dp))
        }
        if (NovaBus.response.isNotBlank()) {
            Text("Nova: " + NovaBus.response, style = MaterialTheme.typography.bodyMedium)
        }
        if (NovaBus.lastError.isNotBlank() && NovaBus.state == NovaState.ERROR) {
            Spacer(Modifier.height(6.dp))
            Text("⚠ " + NovaBus.lastError, color = MaterialTheme.colorScheme.error)
        }

        Spacer(Modifier.height(16.dp))

        if (showSettings) {
            PermissionPanel(
                permissions = permissionList(),
                onRequestBasic = onRequestPermissions,
                onOpenAccessibility = onOpenAccessibilitySettings,
                onOpenNotificationSettings = onOpenNotificationSettings,
                onRequestBattery = onRequestBatteryExemption
            )
            Spacer(Modifier.height(16.dp))
            SettingsForm(
                url = url, onUrlChange = { url = it },
                token = token, onTokenChange = { token = it },
                autoStart = autoStart, onAutoStartChange = { autoStart = it }
            )
            Spacer(Modifier.height(16.dp))
        }

        val running = NovaBus.isServiceRunning
        Button(
            onClick = {
                if (running) {
                    onStop()
                } else {
                    if (!hasPermissions()) {
                        onRequestPermissions()
                        return@Button
                    }
                    if (url.isBlank()) {
                        showSettings = true
                        return@Button
                    }
                    onStart(url.trim(), token.trim(), autoStart)
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(if (running) "නවත්වන්න" else "කතා කරන්න")
        }

        if (!running) {
            Spacer(Modifier.height(6.dp))
            Text(
                "'කතා කරන්න' ඔබලා Service එක on කළාට පස්සේ, Display එක off කළත් app එක Recents එකෙන් swipe කළත් Nova නවත්තින්නේ නෑ. ඕන වෙලාවක 'Nova' කියලා නම කියන්න — එයා ඔබලාට උත්තර දෙනවා.",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

@Composable
private fun PermissionPanel(
    permissions: List<com.nova.assistant.NovaPermission>,
    onRequestBasic: () -> Unit,
    onOpenAccessibility: () -> Unit,
    onOpenNotificationSettings: () -> Unit,
    onRequestBattery: () -> Unit
) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Text("Permission Panel", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(4.dp))
            Text(
                "Nova ට මේ permissions ටික ඕන. එකින් එක ඔබලා දෙන්න.",
                style = MaterialTheme.typography.bodySmall
            )
            Spacer(Modifier.height(10.dp))
            permissions.forEach { perm ->
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(perm.title, style = MaterialTheme.typography.bodyLarge)
                        Text(perm.description, style = MaterialTheme.typography.bodySmall)
                    }
                    if (perm.enabled) {
                        Text("✅", style = MaterialTheme.typography.titleMedium)
                    } else {
                        TextButton(onClick = {
                            when (perm.id) {
                                "microphone", "notifications" -> onRequestBasic()
                                "device_control" -> onOpenAccessibility()
                                "notification_listener" -> onOpenNotificationSettings()
                                "battery" -> onRequestBattery()
                            }
                        }) { Text("දෙන්න") }
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsForm(
    url: String, onUrlChange: (String) -> Unit,
    token: String, onTokenChange: (String) -> Unit,
    autoStart: Boolean, onAutoStartChange: (Boolean) -> Unit
) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Text("VPS සම්බන්ධතාවය", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = url,
                onValueChange = onUrlChange,
                label = { Text("Server URL (https://your-vps:8787)") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = token,
                onValueChange = onTokenChange,
                label = { Text("Nova API Token") },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(checked = autoStart, onCheckedChange = onAutoStartChange)
                Spacer(Modifier.width(8.dp))
                Text("Phone එක restart උනාට Nova auto-start වෙන්න")
            }
        }
    }
}

private fun stateLabel(s: NovaState): String = when (s) {
    NovaState.IDLE -> "සූදානම්"
    NovaState.LISTENING -> "සවන් දෙනවා..."
    NovaState.THINKING -> "හිතනවා..."
    NovaState.EXECUTING -> "ක්‍රියාත්මක කරනවා..."
    NovaState.SPEAKING -> "කතා කරනවා..."
    NovaState.CONFIRMATION -> "තහවුරු කිරීමක් අවශ්‍යයි"
    NovaState.ERROR -> "දෝෂයක්"
    NovaState.OFFLINE -> "නවත්වා ඇත"
}
