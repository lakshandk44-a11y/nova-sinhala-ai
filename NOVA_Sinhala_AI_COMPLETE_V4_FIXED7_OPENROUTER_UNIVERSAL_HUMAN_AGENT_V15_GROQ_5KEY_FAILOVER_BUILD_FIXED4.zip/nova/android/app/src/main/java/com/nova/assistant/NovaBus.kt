package com.nova.assistant

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.nova.assistant.ui.NovaState

/**
 * Simple in-process, thread-safe-ish global state bridge between VoiceService
 * (which runs the real chat loop) and the Compose UI. Compose's snapshot
 * system automatically triggers recomposition for any Composable that reads
 * these values, from any thread.
 */
object NovaBus {
    var state by mutableStateOf(NovaState.OFFLINE)
    var transcript by mutableStateOf("")
    var response by mutableStateOf("")
    var isServiceRunning by mutableStateOf(false)
    var lastError by mutableStateOf("")
    var permissionsTick by mutableStateOf(0)
}
