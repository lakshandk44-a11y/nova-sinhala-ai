# NOVA FUTURISTIC UI

Main screen:
- animated central AI core/orb
- concentric glow rings
- waveform
- live Sinhala transcript
- response
- current task card
- memory/tool/device/VPS status

States:
IDLE, LISTENING, THINKING, EXECUTING, SPEAKING, WAITING_CONFIRMATION, ERROR, OFFLINE

Screens:
Home, Conversation, Memory, Tools, Device Control, Permission Center,
Tasks/Scheduler, Activity/Audit, Security, VPS/System Health.

The final implementation should use Jetpack Compose/Canvas/Lottie-style animation.
The visual reference is inspiration only; assets/code remain original.
