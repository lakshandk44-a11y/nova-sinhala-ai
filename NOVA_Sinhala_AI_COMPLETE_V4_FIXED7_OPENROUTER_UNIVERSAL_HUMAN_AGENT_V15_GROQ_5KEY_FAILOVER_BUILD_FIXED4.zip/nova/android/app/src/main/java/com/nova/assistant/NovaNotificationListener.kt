package com.nova.assistant

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

data class PhoneActivityItem(val app: String, val title: String, val text: String, val at: Long)

/**
 * Watches ALL notification activity on the phone (once the user grants
 * Notification Access), not just one app. Everything readable gets kept in
 * a small rolling buffer so Nova has ambient context of what's going on —
 * "what happened while I was away" — but Nova only interrupts the user
 * out loud for the apps that genuinely warrant it (messaging/calls); the
 * rest is quietly available as context for when the user asks.
 */
class NovaNotificationListener : NotificationListenerService() {

    companion object {
        private const val MAX_BUFFER = 25

        // Apps worth interrupting the user for immediately. Everything else
        // still gets logged into the activity buffer, just not spoken aloud.
        private val PROACTIVE_PACKAGES = setOf(
            "com.whatsapp", "com.whatsapp.w4b",
            "com.google.android.apps.messaging", "com.android.mms",
            "org.telegram.messenger", "com.facebook.orca",
            "com.google.android.dialer", "com.android.dialer"
        )

        private val IGNORED_PACKAGES = setOf(
            "com.nova.assistant", "android", "com.android.systemui"
        )

        private val buffer = ArrayDeque<PhoneActivityItem>()

        /** Snapshot of recent phone activity, most recent first, for the AI's context. */
        fun recentActivity(limit: Int = 12): List<PhoneActivityItem> =
            synchronized(buffer) { buffer.toList().takeLast(limit).reversed() }
    }

    private fun appLabel(pkg: String): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (_: Exception) { pkg }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val pkg = sbn.packageName
        if (pkg in IGNORED_PACKAGES) return

        val extras = sbn.notification.extras
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        if (title.isBlank() && text.isBlank()) return

        val label = appLabel(pkg)
        synchronized(buffer) {
            buffer.addLast(PhoneActivityItem(label, title, text, System.currentTimeMillis()))
            while (buffer.size > MAX_BUFFER) buffer.removeFirst()
        }

        if (pkg in PROACTIVE_PACKAGES && title.isNotBlank() && text.isNotBlank()) {
            VoiceService.instance?.announceIncoming(label, title, text)
        }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {}
}
