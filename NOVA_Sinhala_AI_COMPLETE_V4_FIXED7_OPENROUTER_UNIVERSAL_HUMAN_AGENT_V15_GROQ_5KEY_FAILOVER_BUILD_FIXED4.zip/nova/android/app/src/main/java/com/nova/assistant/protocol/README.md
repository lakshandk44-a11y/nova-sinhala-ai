# Android <-> VPS protocol

Future authenticated events:
DEVICE_STATUS
REQUEST_ACTION
ACTION_PROGRESS
ACTION_RESULT
CONFIRMATION_REQUEST
CONFIRMATION_RESULT

Every action must carry request_id, action_id, permission, risk, arguments and timestamp.
