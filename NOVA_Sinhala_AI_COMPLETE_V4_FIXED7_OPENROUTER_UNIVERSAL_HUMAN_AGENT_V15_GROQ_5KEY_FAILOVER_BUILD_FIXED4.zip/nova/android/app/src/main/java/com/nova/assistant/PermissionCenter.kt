package com.nova.assistant

import android.content.Context
import android.os.Build
import android.provider.Settings
import android.text.TextUtils
import androidx.core.content.ContextCompat

data class NovaPermission(
    val id: String,
    val title: String,
    val description: String,
    val enabled: Boolean,
    val risk: String
)

/**
 * Reads the REAL, live state of every permission Nova needs, straight from
 * the Android system — nothing here is a placeholder. Used to render the
 * in-app Permission Panel.
 */
object PermissionCenter {

    fun microphoneGranted(ctx: Context): Boolean =
        ContextCompat.checkSelfPermission(ctx, android.Manifest.permission.RECORD_AUDIO) ==
            android.content.pm.PackageManager.PERMISSION_GRANTED

    fun notificationsGranted(ctx: Context): Boolean =
        if (Build.VERSION.SDK_INT >= 33)
            ContextCompat.checkSelfPermission(ctx, android.Manifest.permission.POST_NOTIFICATIONS) ==
                android.content.pm.PackageManager.PERMISSION_GRANTED
        else true

    fun accessibilityEnabled(ctx: Context): Boolean {
        val expected = "${ctx.packageName}/${ctx.packageName}.NovaAccessibilityService"
        val enabledServices = Settings.Secure.getString(
            ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        val splitter = TextUtils.SimpleStringSplitter(':')
        splitter.setString(enabledServices)
        while (splitter.hasNext()) {
            if (splitter.next().equals(expected, ignoreCase = true)) return true
        }
        return false
    }

    fun notificationListenerEnabled(ctx: Context): Boolean {
        val enabled = Settings.Secure.getString(ctx.contentResolver, "enabled_notification_listeners") ?: ""
        return enabled.contains(ctx.packageName)
    }

    fun bootAutoStartEnabled(ctx: Context): Boolean =
        ctx.getSharedPreferences("p", Context.MODE_PRIVATE).getBoolean("autostart", false)

    fun batteryExemptionGranted(ctx: Context): Boolean {
        val pm = ctx.getSystemService(Context.POWER_SERVICE) as android.os.PowerManager
        return pm.isIgnoringBatteryOptimizations(ctx.packageName)
    }

    fun list(ctx: Context): List<NovaPermission> = listOf(
        NovaPermission("microphone", "Microphone", "හඬින් කතාකිරීම සඳහා",
            microphoneGranted(ctx), "MEDIUM"),
        NovaPermission("notifications", "Notifications", "Nova එකේ status/confirmations",
            notificationsGranted(ctx), "LOW"),
        NovaPermission("device_control", "Device control (Accessibility)", "Authorized ක්‍රියා (tap/click) device එකේ execute කිරීම",
            accessibilityEnabled(ctx), "HIGH"),
        NovaPermission("notification_listener", "Notification access", "WhatsApp reply ආවම Nova දැනගෙන ඔයාට කියනවා",
            notificationListenerEnabled(ctx), "HIGH"),
        NovaPermission("battery", "Battery optimization ඉවත් කිරීම", "Background එකේ service එක නොනවත්වා run වෙන්න",
            batteryExemptionGranted(ctx), "MEDIUM"),
        NovaPermission("boot", "Restart උනාට auto-start", "Phone එක restart උනාට Nova ආපහු පටන්ගන්නවා",
            bootAutoStartEnabled(ctx), "MEDIUM")
    )
}
