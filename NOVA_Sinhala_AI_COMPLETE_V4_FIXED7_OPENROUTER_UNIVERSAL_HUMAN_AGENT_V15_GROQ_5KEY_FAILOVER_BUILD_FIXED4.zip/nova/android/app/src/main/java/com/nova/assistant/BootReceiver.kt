package com.nova.assistant

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (Intent.ACTION_BOOT_COMPLETED != intent?.action) return

        val prefs = context.getSharedPreferences("p", Context.MODE_PRIVATE)
        val autoStart = prefs.getBoolean("autostart", false)
        val url = prefs.getString("url", "") ?: ""

        // Only auto-start if the user previously opted in and a server URL is
        // already configured. RECORD_AUDIO, once granted, persists across reboot.
        if (autoStart && url.isNotBlank()) {
            val serviceIntent = Intent(context, VoiceService::class.java)
            ContextCompat.startForegroundService(context, serviceIntent)
        }
    }
}
