package com.nova.assistant

import java.net.HttpURLConnection
import java.net.URL

class NovaConnection(private val baseUrl:String, private val token:String) {
    fun postChat(text:String):String {
        val c=URL("$baseUrl/chat").openConnection() as HttpURLConnection
        c.requestMethod="POST"; c.doOutput=true
        c.setRequestProperty("Content-Type","application/json")
        c.setRequestProperty("X-Nova-Token",token)
        c.outputStream.use { it.write("""{"text":${json(text)}}""".toByteArray()) }
        return c.inputStream.bufferedReader().readText()
    }
    private fun json(s:String)=org.json.JSONObject.quote(s)
}
