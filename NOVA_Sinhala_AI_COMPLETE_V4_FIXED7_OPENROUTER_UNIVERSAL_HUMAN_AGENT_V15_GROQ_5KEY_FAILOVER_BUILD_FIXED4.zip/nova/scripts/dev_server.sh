#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../server"
source .venv/bin/activate
uvicorn nova_api.main:app --reload --host 0.0.0.0 --port 8787
