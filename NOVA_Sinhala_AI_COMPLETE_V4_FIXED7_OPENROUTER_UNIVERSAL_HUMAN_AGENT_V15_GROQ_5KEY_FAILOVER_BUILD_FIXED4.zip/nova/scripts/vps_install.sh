#!/usr/bin/env bash
set -euo pipefail
sudo mkdir -p /opt/nova
sudo chown "$USER":"$USER" /opt/nova
echo "Clone the repository into /opt/nova, then:"
echo "cd /opt/nova/server && python3 -m venv .venv && source .venv/bin/activate && pip install -r requirements.txt"
