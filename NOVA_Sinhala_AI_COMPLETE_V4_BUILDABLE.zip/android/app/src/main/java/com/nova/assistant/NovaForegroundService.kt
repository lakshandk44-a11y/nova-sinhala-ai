package com.nova.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.IBinder

class NovaForegroundService : Service() {
    override fun onCreate() {
        super.onCreate()
        val channel=NotificationChannel("nova","Nova Assistant",NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        val n=Notification.Builder(this,"nova")
            .setContentTitle("Nova is active")
            .setContentText("Voice assistant is running")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true).build()
        startForeground(1001,n)
    }
    override fun onStartCommand(intent:Intent?,flags:Int,startId:Int):Int = START_STICKY
    override fun onBind(intent:Intent?):IBinder? = null
}
