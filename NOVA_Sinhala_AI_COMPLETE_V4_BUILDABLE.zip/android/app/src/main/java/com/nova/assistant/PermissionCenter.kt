package com.nova.assistant

data class NovaPermission(
    val id:String,
    val title:String,
    val description:String,
    var enabled:Boolean,
    val risk:String
)

class PermissionCenter {
    val permissions=mutableListOf(
        NovaPermission("microphone","Microphone","Voice conversation",false,"MEDIUM"),
        NovaPermission("notifications","Notifications","Assistant status and confirmations",false,"LOW"),
        NovaPermission("android.device_control","Device control","Authorized Accessibility actions",false,"HIGH"),
        NovaPermission("boot","Start after reboot","Start Nova after device restart",false,"MEDIUM")
    )
    fun enabled(id:String)=permissions.firstOrNull{it.id==id}?.enabled==true
}
