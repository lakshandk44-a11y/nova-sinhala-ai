package com.nova.assistant

import android.app.*
import android.content.*
import android.os.*
import android.speech.*
import android.speech.tts.TextToSpeech
import java.net.HttpURLConnection
import java.net.URL
import java.util.*
import org.json.JSONObject

class VoiceService:Service(),TextToSpeech.OnInitListener{
 private var sr:SpeechRecognizer?=null
 private lateinit var tts:TextToSpeech
 private var running=true
 override fun onCreate(){
  super.onCreate();tts=TextToSpeech(this,this)
  val ch=NotificationChannel("nova","Nova assistant",NotificationManager.IMPORTANCE_LOW)
  getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
  val n=Notification.Builder(this,"nova").setContentTitle("Nova is active")
   .setContentText("Sinhala voice assistant is running").setSmallIcon(android.R.drawable.ic_btn_speak_now).build()
  startForeground(7,n);listen()
 }
 private fun listen(){
  if(!running||!SpeechRecognizer.isRecognitionAvailable(this))return
  sr?.destroy();sr=SpeechRecognizer.createSpeechRecognizer(this)
  sr!!.setRecognitionListener(object:RecognitionListener{
   override fun onResults(r:Bundle){val x=r.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull();if(!x.isNullOrBlank())send(x);if(running)Handler(Looper.getMainLooper()).postDelayed({listen()},450)}
   override fun onError(e:Int){if(running)Handler(Looper.getMainLooper()).postDelayed({listen()},1000)}
   override fun onReadyForSpeech(p:Bundle?){};override fun onBeginningOfSpeech(){};override fun onRmsChanged(v:Float){}
   override fun onBufferReceived(b:ByteArray?){};override fun onEndOfSpeech(){};override fun onPartialResults(b:Bundle?){}
   override fun onEvent(t:Int,p:Bundle?){}
  })
  val i=Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
  i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,"si-LK");i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS,false)
  sr!!.startListening(i)
 }
 private fun send(text:String){Thread{
  try{
   val p=getSharedPreferences("p",0);val u=p.getString("url","")?:"";val token=p.getString("token","")?:""
   if(u.isBlank()){speak("මුලින් VPS ලිපිනය සකස් කරන්න.");return@Thread}
   val c=URL(u.trimEnd('/')+"/chat").openConnection() as HttpURLConnection
   c.requestMethod="POST";c.doOutput=true;c.connectTimeout=15000;c.readTimeout=60000
   c.setRequestProperty("Content-Type","application/json");c.setRequestProperty("X-Nova-Token",token)
   c.outputStream.use{it.write(JSONObject().put("text",text).toString().toByteArray())}
   speak(JSONObject(c.inputStream.bufferedReader().readText()).optString("reply","මට උත්තරයක් ලැබුණේ නැහැ."))
  }catch(e:Exception){speak("VPS එකට සම්බන්ධ වෙන්න බැරි වුණා.")}
 }.start()}
 private fun speak(s:String){Handler(Looper.getMainLooper()).post{tts.speak(s,TextToSpeech.QUEUE_FLUSH,null,"nova",null)}}
 override fun onInit(s:Int){if(s==TextToSpeech.SUCCESS)tts.language=Locale("si","LK")}
 override fun onStartCommand(i:Intent?,f:Int,id:Int)=START_STICKY
 override fun onDestroy(){running=false;sr?.destroy();tts.shutdown();super.onDestroy()}
 override fun onBind(i:Intent?)=null
}
