package com.nova.assistant

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class NovaAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun clickText(text: String): Boolean {
        val root=rootInActiveWindow ?: return false
        val nodes=root.findAccessibilityNodeInfosByText(text)
        for (node in nodes) {
            val ok=if (node.isClickable)
                node.performAction(AccessibilityNodeInfo.ACTION_CLICK) else false
            node.recycle()
            if (ok) return true
        }
        return false
    }

    fun back(): Boolean = performGlobalAction(GLOBAL_ACTION_BACK)
    fun home(): Boolean = performGlobalAction(GLOBAL_ACTION_HOME)
    fun notifications(): Boolean = performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)

    fun tap(x:Float,y:Float):Boolean {
        val path=Path().apply { moveTo(x,y) }
        val stroke=GestureDescription.StrokeDescription(path,0,40)
        val gesture=GestureDescription.Builder().addStroke(stroke).build()
        return dispatchGesture(gesture,null,null)
    }
}
