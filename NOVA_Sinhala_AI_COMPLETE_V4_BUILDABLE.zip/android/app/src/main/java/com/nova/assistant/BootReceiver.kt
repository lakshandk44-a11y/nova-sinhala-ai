package com.nova.assistant

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (Intent.ACTION_BOOT_COMPLETED == intent?.action) {
            // The production version should start only if the user has enabled
            // "start Nova after reboot". Android background-start restrictions apply.
        }
    }
}
