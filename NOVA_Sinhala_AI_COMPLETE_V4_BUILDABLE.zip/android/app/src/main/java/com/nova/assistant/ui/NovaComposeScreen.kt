package com.nova.assistant.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.unit.dp

@Composable
fun NovaHome(state:NovaUiState, onListen:()->Unit) {
    val infinite= rememberInfiniteTransition(label="nova")
    val pulse by infinite.animateFloat(0.85f,1.15f,
        infiniteRepeatable(tween(1200),RepeatMode.Reverse),label="pulse")
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Text("NOVA",style=MaterialTheme.typography.headlineMedium)
        Text(state.state.name)
        Canvas(Modifier.fillMaxWidth().height(260.dp)) {
            val c=Offset(size.width/2,size.height/2)
            drawCircle(radius=80f*pulse,center=c)
            drawCircle(radius=120f*pulse,center=c,alpha=.18f)
            drawCircle(radius=160f*pulse,center=c,alpha=.08f)
        }
        Text(state.transcript)
        Spacer(Modifier.height(8.dp))
        Text(state.response)
        Spacer(Modifier.height(12.dp))
        Button(onClick=onListen,Modifier.fillMaxWidth()) { Text("කතා කරන්න") }
    }
}
