from .audit import record
from .models import DeviceAction, ActionResult

# The VPS never directly controls Android. It creates signed/authenticated action requests;
# the Android client validates permission and executes the narrow allowlisted action.
ALLOWED = {
    "device.status": "LOW",
    "ui.back": "LOW",
    "ui.home": "LOW",
    "ui.notifications": "LOW",
    "ui.tap": "MEDIUM",
    "ui.click_text": "MEDIUM",
    "media.play_pause": "LOW",
    "clipboard.read": "HIGH",
    "clipboard.write": "HIGH",
}

def validate_action(a: DeviceAction):
    expected=ALLOWED.get(a.action)
    if not expected:
        return False, "Action is not allowlisted."
    if a.permission != "android.device_control":
        return False, "Required Android permission is not granted."
    if a.requires_confirmation and a.risk in ("HIGH","CRITICAL"):
        return False, "User confirmation is required on the phone."
    return True, "validated"

def enqueue(a: DeviceAction):
    ok,msg=validate_action(a)
    result=ActionResult(a.request_id,a.action_id,ok,msg,{})
    record(a.request_id,a.action,a.risk,a.requires_confirmation,result.model_dump())
    return result
