import json, uuid
from openai import OpenAI
from .config import settings
from .memory import search
from .tools import REGISTRY
from .audit import record

client=OpenAI(api_key=settings.openai_api_key)

SYSTEM="""You are Nova, a Sinhala-first personal AI companion.
Speak naturally in Sinhala by default and behave like a helpful trusted companion.
Use memory when relevant. Plan multi-step work and use only authorized tools.
Never claim a tool/action succeeded unless its result confirms it.
Ask before destructive, financial, credential, privacy-sensitive or irreversible actions.
Android actions execute on the phone; the VPS is the orchestration layer."""

def schemas():
    return [
      {"type":"function","name":"remember","description":"Save durable memory.",
       "parameters":{"type":"object","properties":{"kind":{"type":"string"},"text":{"type":"string"},"tags":{"type":"string"}},"required":["kind","text"]}},
      {"type":"function","name":"recall","description":"Search memory.",
       "parameters":{"type":"object","properties":{"query":{"type":"string"}},"required":["query"]}}
    ]

def run(user_text):
    rid=str(uuid.uuid4())
    memories=search(user_text,12)
    context="\n".join(f"- {m['kind']}: {m['text']}" for m in memories) or "(none)"
    response=client.responses.create(model=settings.model,input=SYSTEM+"\nMEMORY:\n"+context+"\nUSER:\n"+user_text,tools=schemas())

    for _ in range(8):
        calls=[x for x in response.output if getattr(x,"type","")=="function_call"]
        if not calls: break
        outputs=[]
        for call in calls:
            args=json.loads(call.arguments)
            if call.name=="remember":
                result=REGISTRY["remember"].handler(**args); record(rid,"remember","LOW",False,result)
            elif call.name=="recall":
                result=REGISTRY["recall"].handler(**args); record(rid,"recall","LOW",False,{"count":len(result["items"])})
            else:
                result={"error":"unknown_tool"}
            outputs.append({"type":"function_call_output","call_id":call.call_id,"output":json.dumps(result,ensure_ascii=False)})
        response=client.responses.create(model=settings.model,previous_response_id=response.id,input=outputs,tools=schemas())

    return {"request_id":rid,"reply":response.output_text,"memory_used":memories}
