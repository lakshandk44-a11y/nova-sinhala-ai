import os, json, sqlite3, time, uuid
from dotenv import load_dotenv
from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel
from openai import OpenAI

load_dotenv()
TOKEN=os.getenv("NOVA_API_TOKEN","")
MODEL=os.getenv("OPENAI_MODEL","gpt-5")
DB=os.getenv("NOVA_DB_PATH","./data/nova.sqlite3")
os.makedirs(os.path.dirname(DB) or ".", exist_ok=True)
client=OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
app=FastAPI(title="Nova Sinhala AI",version="0.2.0")

def auth(token):
    if not TOKEN or token != TOKEN:
        raise HTTPException(401,"Invalid Nova token")

def db():
    c=sqlite3.connect(DB)
    c.execute("""CREATE TABLE IF NOT EXISTS memory(
      id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT NOT NULL, text TEXT NOT NULL,
      created_at REAL NOT NULL, updated_at REAL NOT NULL)""")
    c.execute("""CREATE TABLE IF NOT EXISTS audit(
      id INTEGER PRIMARY KEY AUTOINCREMENT, request_id TEXT, action TEXT, risk TEXT,
      result TEXT, created_at REAL)""")
    c.commit(); return c

def remember(kind,text):
    now=time.time(); c=db()
    c.execute("INSERT INTO memory(kind,text,created_at,updated_at) VALUES(?,?,?,?)",
              (kind,text,now,now)); c.commit(); c.close()
    return {"ok":True}

def recall(query,limit=12):
    c=db()
    rows=c.execute("SELECT kind,text FROM memory ORDER BY updated_at DESC LIMIT 2000").fetchall()
    c.close()
    terms=[x.lower() for x in query.split() if len(x)>2]
    scored=[]
    for kind,text in rows:
        score=sum(t in text.lower() for t in terms)
        if score: scored.append((score,kind,text))
    scored.sort(reverse=True)
    return [{"kind":k,"text":t} for _,k,t in scored[:limit]]

def audit(rid,action,risk,result):
    c=db()
    c.execute("INSERT INTO audit(request_id,action,risk,result,created_at) VALUES(?,?,?,?,?)",
              (rid,action,risk,json.dumps(result,ensure_ascii=False),time.time()))
    c.commit(); c.close()

TOOLS=[
 {"type":"function","name":"remember",
  "description":"Remember a durable fact, preference, project detail, or explicit memory request.",
  "parameters":{"type":"object","properties":{"kind":{"type":"string"},"text":{"type":"string"}},
                "required":["kind","text"]}},
 {"type":"function","name":"recall",
  "description":"Recall relevant information from Nova long-term memory.",
  "parameters":{"type":"object","properties":{"query":{"type":"string"}},
                "required":["query"]}}
]

SYSTEM="""You are Nova, a Sinhala-first personal AI companion.
Speak naturally in Sinhala by default. Be warm and conversational.
Understand natural requests, remember relevant context, plan multi-step tasks and use tools.
Report progress when a task takes time. Never claim completion without confirmation.
Ask before destructive, irreversible, financial, credential or privacy-sensitive actions.
The Android app is the device executor; the VPS must never pretend it directly controls the phone."""

class ChatRequest(BaseModel):
    text:str
    conversation_id:str|None=None

@app.get("/health")
def health(x_nova_token:str|None=Header(default=None)):
    auth(x_nova_token)
    return {"ok":True,"model":MODEL,"service":"nova"}

@app.post("/chat")
def chat(req:ChatRequest,x_nova_token:str|None=Header(default=None)):
    auth(x_nova_token)
    rid=str(uuid.uuid4())
    memories=recall(req.text)
    context="\n".join(f"- {m['kind']}: {m['text']}" for m in memories) or "(none)"
    prompt=SYSTEM+"\nRelevant memory:\n"+context+"\n\nUser:\n"+req.text
    response=client.responses.create(model=MODEL,input=prompt,tools=TOOLS)

    for _ in range(6):
        calls=[x for x in response.output if getattr(x,"type",None)=="function_call"]
        if not calls: break
        outs=[]
        for call in calls:
            args=json.loads(call.arguments)
            if call.name=="remember":
                result=remember(args["kind"],args["text"]); audit(rid,call.name,"LOW",result)
            elif call.name=="recall":
                result=recall(args["query"]); audit(rid,call.name,"LOW",{"count":len(result)})
            else: result={"error":"Unknown tool"}
            outs.append({"type":"function_call_output","call_id":call.call_id,
                         "output":json.dumps(result,ensure_ascii=False)})
        response=client.responses.create(model=MODEL,previous_response_id=response.id,
                                         input=outs,tools=TOOLS)
    return {"request_id":rid,"reply":response.output_text,"memory_used":memories}

@app.get("/memory")
def memory(q:str="",x_nova_token:str|None=Header(default=None)):
    auth(x_nova_token); return {"items":recall(q,50)}

@app.get("/audit")
def audit_log(x_nova_token:str|None=Header(default=None)):
    auth(x_nova_token)
    c=db(); rows=c.execute("SELECT request_id,action,risk,result,created_at FROM audit ORDER BY id DESC LIMIT 200").fetchall(); c.close()
    keys=["request_id","action","risk","result","created_at"]
    return {"items":[dict(zip(keys,r)) for r in rows]}
