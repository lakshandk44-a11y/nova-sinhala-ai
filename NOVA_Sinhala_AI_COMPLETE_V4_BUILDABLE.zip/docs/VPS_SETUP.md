# VPS setup

```bash
sudo mkdir -p /opt/nova
sudo chown "$USER":"$USER" /opt/nova
cd /opt/nova
git clone YOUR_GITHUB_REPOSITORY .
cd server
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
nano .env
uvicorn nova_api.main:app --host 127.0.0.1 --port 8787
```

Install the systemd service from `deploy/nova.service` after verifying the backend.

Use HTTPS/reverse proxy in production.
