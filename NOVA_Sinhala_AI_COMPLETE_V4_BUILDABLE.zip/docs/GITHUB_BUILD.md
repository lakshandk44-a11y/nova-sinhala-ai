# GitHub ZIP-first build

The repository stores the complete NOVA source as a ZIP. The GitHub workflow extracts it
and builds the Android project with Gradle 8.9, so a `gradlew` file is not required inside
the uploaded source archive.

The workflow:
- locates duplicate-safe `NOVA_Sinhala_AI_COMPLETE_V3_ZIP_UPLOAD*.zip`
- validates the ZIP
- extracts the entire source tree
- checks the backend Python
- installs Java 17
- downloads Gradle 8.9
- builds `assembleDebug`
- uploads the APK artifact

No source files are intentionally deleted during extraction.
