#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../server"
source .venv/bin/activate
uvicorn nova_api.main:app --reload --host 127.0.0.1 --port 8787
