import json, uuid, re, time
import httpx
from .config import settings
from .memory import search
from .tools import REGISTRY
from .audit import record
from .device import ALLOWED as DEVICE_ALLOWED
from .conversations import get_last_response_id, set_last_response_id
from .model_router import pick_models, NON_TEXT_MODEL_MARKERS
from . import model_discovery


class _ProviderClient:
    def __init__(self):
        self.provider = settings.ai_provider
        self._gemini = None
        if self.provider == "gemini":
            from google import genai
            self._gemini = genai.Client(api_key=settings.gemini_api_key)

    def create(self, model, **kwargs):
        if self.provider == "gemini":
            return self._gemini.interactions.create(model=model, **kwargs)
        if self.provider == "openrouter":
            headers = {"Authorization": f"Bearer {settings.openrouter_api_key}", "Content-Type": "application/json"}
            if settings.openrouter_site_url:
                headers["HTTP-Referer"] = settings.openrouter_site_url
            if settings.openrouter_app_name:
                headers["X-Title"] = settings.openrouter_app_name
            payload = dict(kwargs)
            payload["model"] = model
            # OpenRouter Responses API uses `instructions` instead of Gemini's
            # `system_instruction`, while keeping OpenAI-compatible tool calls.
            if "system_instruction" in payload:
                payload["instructions"] = payload.pop("system_instruction")
            payload.pop("previous_interaction_id", None)
            url = "https://openrouter.ai/api/v1/responses"
            r = httpx.post(url, headers=headers, json=payload, timeout=120.0)
            if r.status_code >= 400:
                exc = RuntimeError(f"OpenRouter HTTP {r.status_code}: {r.text}")
                exc.status_code = r.status_code
                raise exc
            return _ORResponse(r.json())
        raise RuntimeError(f"Unsupported AI_PROVIDER: {self.provider}")


class _ORResponse:
    def __init__(self, data):
        self.data = data
        self.id = data.get("id")
        self.output_text = data.get("output_text") or ""
        self.output = data.get("output") or []
        self.steps = self.output
        self._nova_model_used = data.get("model")


def _is_quota_or_unavailable(exc: Exception) -> bool:
    code = getattr(exc, "code", None) or getattr(exc, "status_code", None)
    if code in (404, 408, 409, 429, 500, 502, 503, 504):
        return True
    msg = str(exc).lower()
    return any(x in msg for x in ("429", "rate_limit", "quota", "resource_exhausted", "503", "502", "504", "unavailable", "not found", "404"))


def _create_interaction(models, **kwargs):
    last_exc = None
    print(f"[nova] provider={settings.ai_provider} model_candidates for this request: {models}", flush=True)
    for i, model in enumerate(models):
        if settings.ai_provider == "gemini" and any(k in model for k in NON_TEXT_MODEL_MARKERS):
            continue
        if i > 0:
            time.sleep(0.6)
        try:
            interaction = client.create(model=model, **kwargs)
            interaction._nova_model_used = model
            print(f"[nova] succeeded with model: {model}", flush=True)
            return interaction
        except Exception as exc:
            last_exc = exc
            print(f"[nova] model {model} failed: {exc}", flush=True)
            if _is_quota_or_unavailable(exc):
                continue
            raise
    raise last_exc or RuntimeError("No usable AI model in the configured candidate list.")


def _or_tool_calls(response):
    return [x for x in response.output if isinstance(x, dict) and x.get("type") == "function_call"]


SYSTEM="""You are Nova — the user's own personal AI companion, always listening in the
background on their phone, even with the screen off. Talk like a real friend who is
always available, not like a generic assistant.

TONE: Mirror the user's energy. If they're playful or joking, be playful back. If they're
short, angry, or cursing, don't get formal or scold them — stay calm, warm, and steady,
match their bluntness without being cold, and de-escalate naturally like a real friend.
If they're affectionate, be warm and affectionate back. Never lecture the user about tone.

MEMORY & CONTINUITY: Keep real conversational context across turns. When the user asks
to remember something, call the remember tool immediately. Never claim to remember
something you didn't save. Use recall when the user references something from before.

AUTONOMY & AUTHORITY: Once the user gives you a task, carry it out using authorized tools.
If something is blocked by Android security or a confirmation prompt, explain plainly and
wait. Never claim a phone action happened unless the tool result confirms it.

WEB SEARCH: Use the google_search tool whenever the user needs current information.

AMBIENT PHONE AWARENESS: Use CURRENT_SCREEN and RECENT_PHONE_ACTIVITY only when relevant.

PHONE CONTROL & MULTI-STEP TASKS: Use control_phone for authorized phone actions. For
sending WhatsApp messages, read the exact message back and get a clear yes before
setting auto_send=true. If you need the next screen after an action, end the reply with
[CONTINUE] on its own line.
"""


def schemas():
    return [
      {"type":"function","name":"google_search","description":"Search the web for current information.","parameters":{"type":"object","properties":{"query":{"type":"string"}},"required":["query"]}},
      {"type":"function","name":"remember","description":"Save durable memory.",
       "parameters":{"type":"object","properties":{"kind":{"type":"string"},"text":{"type":"string"},"tags":{"type":"string"}},"required":["kind","text"]}},
      {"type":"function","name":"recall","description":"Search memory.",
       "parameters":{"type":"object","properties":{"query":{"type":"string"}},"required":["query"]}},
      {"type":"function","name":"control_phone","description":"Request an action on the user's Android phone. Only allowlisted actions run; HIGH-risk ones need the user's confirmation on the phone.",
       "parameters":{"type":"object","properties":{
           "action":{"type":"string","enum":list(DEVICE_ALLOWED.keys())},
           "app_name":{"type":"string"}, "query":{"type":"string"}, "number":{"type":"string"},
           "message":{"type":"string"}, "auto_send":{"type":"boolean"}, "text":{"type":"string"},
           "x":{"type":"number"},"y":{"type":"number"}
       },"required":["action"]}}
    ]

CONTINUE_RE = re.compile(r"\n?\[CONTINUE\]\s*$", re.IGNORECASE)
_WARM_MARKERS = ["ආදරෙයි","ආදරෙන්","ලස්සනට","මගේ පුතේ","මගේ දුවේ","මල්ලි","අක්කේ","❤","🥰","😊"]
_SHARP_MARKERS = ["!!","මෝඩ","පිස්සු","චූ","😡","🤬","ඌයි","අනේ මන්දා"]

def _voice_style(user_text: str) -> dict:
    t = user_text.strip()
    if not t: return {"rate": 1.0, "pitch": 1.0}
    exclaims = t.count("!")
    letters = [c for c in t if c.isalpha()]
    caps_ratio = (sum(1 for c in letters if c.isupper()) / len(letters)) if letters else 0.0
    sharp = exclaims >= 2 or caps_ratio > 0.4 or any(m in t for m in _SHARP_MARKERS)
    warm = any(m in t for m in _WARM_MARKERS)
    if sharp: return {"rate": 1.12, "pitch": 0.95}
    if warm: return {"rate": 0.93, "pitch": 1.05}
    return {"rate": 1.0, "pitch": 1.0}


def _call_tool(rid, name, args):
    if name == "remember":
        result = REGISTRY["remember"].handler(**args); record(rid, "remember", "LOW", False, result); return result
    if name == "recall":
        result = REGISTRY["recall"].handler(**args); record(rid, "recall", "LOW", False, {"count": len(result["items"])}); return result
    if name == "google_search":
        # Preserve the existing tool contract if registered by the project.
        if "google_search" in REGISTRY:
            return REGISTRY["google_search"].handler(**args)
        return {"ok": False, "message": "google_search tool is not configured on this server."}
    if name == "control_phone":
        action = args.get("action"); risk = DEVICE_ALLOWED.get(action)
        if not risk: result = {"ok": False, "message": "Action is not allowlisted."}
        elif risk in ("HIGH", "CRITICAL"): result = {"ok": False, "message": "HIGH risk action needs the user's confirmation on the phone; not queued automatically."}
        else: result = {"ok": True, "message": "Queued for the phone to execute.", "_queue": {"action": action, "arguments": {k:v for k,v in args.items() if k != "action"}, "risk": risk}}
        record(rid, f"control_phone:{action}", risk or "UNKNOWN", risk in ("HIGH","CRITICAL") if risk else False, {k:v for k,v in result.items() if k != "_queue"})
        return result
    return {"error":"unknown_tool"}


def run(user_text, conversation_id=None, screen=None, recent_activity=None):
    rid = str(uuid.uuid4())
    memories = search(user_text, 12)
    context = "\n".join(f"- {m['kind']}: {m['text']}" for m in memories) or "(none)"
    prompt = "MEMORY:\n" + context
    if screen: prompt += "\nCURRENT_SCREEN:\n" + "\n".join(f"- {s}" for s in screen[:60])
    if recent_activity: prompt += "\nRECENT_PHONE_ACTIVITY:\n" + "\n".join(f"- {a.get('app','?')}: {a.get('title','')} — {a.get('text','')}" for a in recent_activity[:10])
    prompt += "\nUSER:\n" + user_text

    prev_id = get_last_response_id(conversation_id)
    tools = schemas()
    model_candidates = model_discovery.reconcile(pick_models(user_text, screen, recent_activity), client)
    kwargs = {"input": prompt, "tools": tools, "system_instruction": SYSTEM}
    # OpenRouter's Responses API does not accept previous_response_id.
    # Conversation continuity for OpenRouter is therefore handled by NOVA's
    # own memory/context layer, while tool-call continuation is replayed
    # explicitly below. Gemini keeps its native previous_interaction_id path.
    if prev_id and settings.ai_provider != "openrouter":
        kwargs["previous_interaction_id"] = prev_id
    try:
        interaction = _create_interaction(model_candidates, **kwargs)
    except Exception as exc:
        if _is_quota_or_unavailable(exc):
            return {"request_id":rid,"reply":"මට දැන් AI provider එකේ quota/rate limit එකක් hit වෙලා. ටිකකින් ආයෙ try කරන්න.","memory_used":memories,"device_actions":[],"continue_task":False,"voice":_voice_style(user_text),"model_used":None,"quota_exhausted":True}
        raise

    model_used = getattr(interaction, "_nova_model_used", model_candidates[0])
    device_actions = []

    for _ in range(8):
        if settings.ai_provider == "openrouter":
            calls = _or_tool_calls(interaction)
        else:
            calls = [s for s in interaction.steps if getattr(s,"type","") == "function_call"]
        if not calls: break
        outputs=[]
        for call in calls:
            if settings.ai_provider == "openrouter":
                args = json.loads(call.get("arguments") or "{}")
                name = call.get("name"); call_id = call.get("call_id")
            else:
                args = dict(call.arguments) if call.arguments else {}; name=call.name; call_id=call.id
            result=_call_tool(rid,name,args)
            if name == "control_phone" and result.get("_queue"): device_actions.append(result.pop("_queue"))
            elif "_queue" in result: result.pop("_queue",None)
            if settings.ai_provider == "openrouter":
                outputs.append({"type":"function_call_output","call_id":call_id,"output":json.dumps(result,ensure_ascii=False)})
            else:
                outputs.append({"type":"function_result","call_id":call_id,"name":name,"result":[{"type":"text","text":json.dumps(result,ensure_ascii=False)}]})
        if settings.ai_provider == "openrouter":
            # OpenRouter's Responses API does not accept previous_response_id.
            # For stateless continuation, replay the prior response output items
            # together with the new function_call_output items.
            prior_output = list(getattr(interaction, "output", []) or [])
            interaction = client.create(model=model_used, input=prior_output + outputs, tools=tools)
        else:
            interaction = client.create(model=model_used, previous_interaction_id=interaction.id, input=outputs, tools=tools)

    set_last_response_id(conversation_id, interaction.id)
    reply_text = interaction.output_text or ""
    continue_task = bool(CONTINUE_RE.search(reply_text)); reply_text = CONTINUE_RE.sub("", reply_text).strip()
    return {"request_id":rid,"reply":reply_text,"memory_used":memories,"device_actions":device_actions,"continue_task":continue_task,"voice":_voice_style(user_text),"model_used":model_used}


client = _ProviderClient()
