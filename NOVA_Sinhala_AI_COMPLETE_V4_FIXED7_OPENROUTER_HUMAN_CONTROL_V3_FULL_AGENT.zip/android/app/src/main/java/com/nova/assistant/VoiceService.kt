package com.nova.assistant

import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.speech.*
import android.speech.tts.TextToSpeech
import androidx.core.app.NotificationCompat
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.*
import org.json.JSONArray
import org.json.JSONObject
import com.nova.assistant.ui.NovaState

/**
 * The real, persistent NOVA voice loop.
 * - Foreground service (android:stopWithTask="false") so it survives the app
 *   being swiped away from Recents, and keeps working with the screen off.
 * - Passively listens for a wake word ("Nova"/"නෝවා"). Once triggered, opens
 *   an "active session" window where the user can talk naturally without
 *   repeating the wake word each time.
 * - Sends recognized speech to the VPS backend's /chat endpoint, speaks the
 *   reply with TTS, and executes any device_actions the AI requested
 *   (open apps, WhatsApp, dialer, search, settings panels, UI taps).
 */
class VoiceService : Service(), TextToSpeech.OnInitListener {

    companion object {
        const val CHANNEL_ID = "nova_voice"
        const val NOTIF_ID = 7
        const val ACTION_STOP = "com.nova.assistant.action.STOP"
        private val WAKE_WORDS = listOf("nova", "නෝවා", "නොවා", "නෝව")
        private const val ACTIVE_SESSION_MS = 60_000L

        var instance: VoiceService? = null
            private set
    }

    private var sr: SpeechRecognizer? = null
    private lateinit var tts: TextToSpeech
    private var running = true
    private var activeSessionUntil = 0L
    private var autoContinueDepth = 0
    private var pendingNotification: Triple<String, String, String>? = null // app, title, text
    private var lastRate = 1.0f
    private var lastPitch = 1.0f
    private var pendingActionResults = mutableListOf<String>()
    private val mainHandler = Handler(Looper.getMainLooper())

    private fun conversationId(): String {
        val p = getSharedPreferences("p", 0)
        var id = p.getString("conversation_id", null)
        if (id.isNullOrBlank()) {
            id = UUID.randomUUID().toString()
            p.edit().putString("conversation_id", id).apply()
        }
        return id
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        running = true
        NovaBus.isServiceRunning = true
        NovaBus.state = NovaState.IDLE
        NovaBus.lastError = ""

        tts = TextToSpeech(this, this)

        val nm = getSystemService(NotificationManager::class.java)
        val channel = NotificationChannel(
            CHANNEL_ID, "Nova Voice Assistant", NotificationManager.IMPORTANCE_LOW
        ).apply { description = "Nova is listening in the background" }
        nm.createNotificationChannel(channel)

        startForeground(NOTIF_ID, buildNotification("Nova is active", "සූදානම්... 'Nova' කියලා කතාකරන්න"))
        listen()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    private fun buildNotification(title: String, text: String): Notification {
        val stopIntent = PendingIntent.getService(
            this, 0, Intent(this, VoiceService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val openIntent = PendingIntent.getActivity(
            this, 0, packageManager.getLaunchIntentForPackage(packageName),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .setContentIntent(openIntent)
            .addAction(0, "නවත්වන්න", stopIntent)
            .build()
    }

    private fun updateNotification(text: String) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(NOTIF_ID, buildNotification("Nova is active", text))
    }

    private fun isSessionActive() = System.currentTimeMillis() < activeSessionUntil

    private fun extendSession() {
        activeSessionUntil = System.currentTimeMillis() + ACTIVE_SESSION_MS
    }

    /** Called by NovaNotificationListener when a monitored app gets a new message. */
    fun announceIncoming(app: String, title: String, text: String) {
        if (!running) return
        mainHandler.post {
            if (NovaBus.state == NovaState.THINKING || NovaBus.state == NovaState.SPEAKING ||
                NovaBus.state == NovaState.EXECUTING
            ) return@post // don't interrupt something already in progress
            pendingNotification = Triple(app, title, text)
            extendSession()
            speak("ආ, $app එකෙන් $title reply එකක් දැම්මා. අහන්නද?")
        }
    }

    private fun stripWakeWord(raw: String): Pair<Boolean, String> {
        val lower = raw.lowercase(Locale.ROOT)
        for (w in WAKE_WORDS) {
            val idx = lower.indexOf(w)
            if (idx >= 0) {
                val rest = (raw.substring(0, idx) + raw.substring(idx + w.length)).trim()
                return true to rest
            }
        }
        return false to raw
    }

    private fun listen() {
        if (!running) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            NovaBus.state = NovaState.ERROR
            NovaBus.lastError = "Speech recognition මෙ device එකේ නෑ."
            return
        }
        NovaBus.state = NovaState.LISTENING
        updateNotification(if (isSessionActive()) "සවන් දෙනවා..." else "'Nova' කියලා කතාකරන්න")

        sr?.destroy()
        sr = SpeechRecognizer.createSpeechRecognizer(this)
        sr!!.setRecognitionListener(object : RecognitionListener {
            override fun onResults(r: Bundle) {
                val x = r.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (x.isNullOrBlank()) {
                    if (running) mainHandler.postDelayed({ listen() }, 400)
                    return
                }

                val pending = pendingNotification
                if (pending != null) {
                    pendingNotification = null
                    val lower = x.lowercase(Locale.ROOT)
                    val yes = listOf("ඔව්", "ඔව", "අහන්නම්", "කියවන්න", "කියන්න", "yes", "read")
                    val no = listOf("එපා", "නෑ", "නැහැ", "no")
                    if (yes.any { lower.contains(it) }) {
                        NovaBus.transcript = x
                        speak("${pending.second} කිව්වේ — ${pending.third}")
                        return
                    } else if (no.any { lower.contains(it) }) {
                        speak("හරි.")
                        return
                    }
                    // else: not a yes/no — fall through and treat as a fresh command below
                }

                if (isSessionActive()) {
                    // Already in an active conversation: no wake word needed.
                    NovaBus.transcript = x
                    extendSession()
                    send(x)
                } else {
                    val (waked, rest) = stripWakeWord(x)
                    if (waked) {
                        extendSession()
                        if (rest.isBlank()) {
                            NovaBus.transcript = x
                            speak("මොකක්ද ඕන?")
                        } else {
                            NovaBus.transcript = rest
                            send(rest)
                        }
                    } else if (running) {
                        mainHandler.postDelayed({ listen() }, 350)
                    }
                }
            }
            override fun onError(e: Int) {
                if (running) mainHandler.postDelayed({ listen() }, 900)
            }
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(b: Bundle?) {}
            override fun onEvent(t: Int, p: Bundle?) {}
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "si-LK")
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        try {
            sr!!.startListening(i)
        } catch (e: Exception) {
            if (running) mainHandler.postDelayed({ listen() }, 900)
        }
    }

    private fun send(text: String, isAutoContinue: Boolean = false) {
        NovaBus.state = NovaState.THINKING
        updateNotification("හිතනවා...")
        Thread {
            try {
                val p = getSharedPreferences("p", 0)
                val u = p.getString("url", "") ?: ""
                val token = p.getString("token", "") ?: ""
                if (u.isBlank()) {
                    speak("මුලින් Settings එකෙන් VPS ලිපිනය සකස් කරන්න.")
                    return@Thread
                }
                val screen = NovaAccessibilityService.instance?.screenSnapshot() ?: emptyList()

                val body = JSONObject()
                    .put("text", text)
                    .put("conversation_id", conversationId())
                if (screen.isNotEmpty()) {
                    val arr = JSONArray()
                    screen.forEach { arr.put(it) }
                    body.put("screen", arr)
                }
                val activity = NovaNotificationListener.recentActivity(10)
                if (activity.isNotEmpty()) {
                    val arr = JSONArray()
                    activity.forEach {
                        arr.put(JSONObject().put("app", it.app).put("title", it.title).put("text", it.text))
                    }
                    body.put("recent_activity", arr)
                }

                if (pendingActionResults.isNotEmpty()) {
                    val arr = JSONArray()
                    pendingActionResults.forEach { arr.put(it) }
                    body.put("action_results", arr)
                    pendingActionResults = mutableListOf()
                }

                val c = URL(u.trimEnd('/') + "/chat").openConnection() as HttpURLConnection
                c.requestMethod = "POST"
                c.doOutput = true
                c.connectTimeout = 15000
                c.readTimeout = 60000
                c.setRequestProperty("Content-Type", "application/json")
                c.setRequestProperty("X-Nova-Token", token)
                c.outputStream.use { it.write(body.toString().toByteArray()) }

                if (c.responseCode >= 400) {
                    val err = c.errorStream?.bufferedReader()?.readText() ?: "HTTP ${c.responseCode}"
                    throw RuntimeException(err)
                }
                val resp = JSONObject(c.inputStream.bufferedReader().readText())
                val reply = resp.optString("reply", "")
                val continueTask = resp.optBoolean("continue_task", false)
                resp.optJSONObject("voice")?.let { v ->
                    lastRate = v.optDouble("rate", 1.0).toFloat()
                    lastPitch = v.optDouble("pitch", 1.0).toFloat()
                }

                resp.optJSONArray("device_actions")?.let { actions ->
                    mainHandler.post { executeDeviceActions(actions) }
                }

                if (reply.isNotBlank()) {
                    NovaBus.response = reply
                }

                if (continueTask && autoContinueDepth < 8) {
                    // Nova needs to see the result of what it just did to keep
                    // going on a multi-step task — no user input required.
                    autoContinueDepth++
                    if (reply.isNotBlank()) {
                        speakWithoutResumingListen(reply)
                    }
                    mainHandler.postDelayed({ send("[auto:screen_update]", isAutoContinue = true) }, 1200)
                } else {
                    autoContinueDepth = 0
                    if (reply.isBlank() && isAutoContinue) {
                        if (running) listen()
                    } else {
                        speak(reply.ifBlank { "හරි." })
                    }
                }
            } catch (e: Exception) {
                autoContinueDepth = 0
                NovaBus.lastError = e.message ?: "connection_error"
                NovaBus.state = NovaState.ERROR
                speak("VPS එකට සම්බන්ධ වෙන්න බැරි වුණා.")
            }
        }.start()
    }

    // ---------- Device action execution ----------

    private fun executeDeviceActions(actions: JSONArray) {
        val results = mutableListOf<String>()
        for (i in 0 until actions.length()) {
            try {
                val a = actions.getJSONObject(i)
                val name = a.optString("action")
                val args = a.optJSONObject("arguments") ?: JSONObject()
                var ok = true
                when (name) {
                    "ui.back" -> ok = NovaAccessibilityService.instance?.back() ?: false
                    "ui.home" -> ok = NovaAccessibilityService.instance?.home() ?: false
                    "ui.notifications" -> ok = NovaAccessibilityService.instance?.notifications() ?: false
                    "ui.click_text" -> ok = args.optString("text").takeIf { it.isNotBlank() }
                        ?.let { NovaAccessibilityService.instance?.clickText(it) } ?: false
                    "ui.click_description" -> ok = args.optString("description").takeIf { it.isNotBlank() }
                        ?.let { NovaAccessibilityService.instance?.clickByDescription(it) } ?: false
                    "ui.click_query" -> ok = args.optString("query").takeIf { it.isNotBlank() }
                        ?.let { NovaAccessibilityService.instance?.clickQuery(it) } ?: false
                    "ui.focus_input" -> ok = NovaAccessibilityService.instance?.focusInput() ?: false
                    "ui.clear_input" -> ok = NovaAccessibilityService.instance?.clearInput() ?: false
                    "ui.type_text" -> ok = NovaAccessibilityService.instance?.setText(args.optString("text")) ?: false
                    "ui.tap" -> ok = NovaAccessibilityService.instance?.tap(
                        args.optDouble("x").toFloat(), args.optDouble("y").toFloat()) ?: false
                    "ui.swipe" -> ok = NovaAccessibilityService.instance?.swipe(
                        args.optDouble("x").toFloat(), args.optDouble("y").toFloat(),
                        args.optDouble("x2").toFloat(), args.optDouble("y2").toFloat(),
                        args.optLong("duration_ms",350L)) ?: false
                    "ui.scroll" -> {
                        ok = if (args.optString("direction","forward").equals("backward",true))
                            NovaAccessibilityService.instance?.scrollBackward() ?: false
                        else NovaAccessibilityService.instance?.scrollForward() ?: false
                    }
                    "ui.long_press" -> ok = NovaAccessibilityService.instance?.longPress(
                        args.optDouble("x").toFloat(), args.optDouble("y").toFloat(),
                        args.optLong("duration_ms",650L)) ?: false
                    "ui.power_dialog" -> ok = NovaAccessibilityService.instance?.powerDialog() ?: false
                    "ui.lock_screen" -> ok = NovaAccessibilityService.instance?.lockScreen() ?: false
                    "ui.screenshot" -> ok = NovaAccessibilityService.instance?.takeScreenshot() ?: false
                    "ui.recent" -> ok = NovaAccessibilityService.instance?.performGlobalAction(
                        android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_RECENTS) ?: false
                    "ui.quick_settings" -> ok = NovaAccessibilityService.instance?.performGlobalAction(
                        android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS) ?: false
                    "media.volume_up" -> {
                        val am=getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
                        am.adjustVolume(android.media.AudioManager.ADJUST_RAISE, android.media.AudioManager.FLAG_SHOW_UI)
                    }
                    "media.volume_down" -> {
                        val am=getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
                        am.adjustVolume(android.media.AudioManager.ADJUST_LOWER, android.media.AudioManager.FLAG_SHOW_UI)
                    }
                    "media.mute" -> {
                        val am=getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
                        am.adjustVolume(android.media.AudioManager.ADJUST_MUTE, android.media.AudioManager.FLAG_SHOW_UI)
                    }
                    "app.open" -> { ok = openAppByName(args.optString("app_name")) }
                    "app.open_package" -> {
                        val pkg = args.optString("package_name")
                        ok = pkg.isNotBlank() && packageManager.getLaunchIntentForPackage(pkg)?.let { openIntent(it); true } == true
                    }
                    "app.youtube_search" -> { openUrl("https://www.youtube.com/results?search_query=" + enc(args.optString("query"))) }
                    "app.google_search" -> { openUrl("https://www.google.com/search?q=" + enc(args.optString("query"))) }
                    "whatsapp.open_chat" -> {
                        val num = args.optString("number").filter { it.isDigit() || it == '+' }
                        val msg = args.optString("message")
                        val autoSend = args.optBoolean("auto_send", false)
                        if (num.isBlank()) ok = false else {
                            val url = "https://wa.me/$num" + if (msg.isNotBlank()) "?text=" + enc(msg) else ""
                            openUrl(url)
                            if (autoSend && msg.isNotBlank()) {
                                mainHandler.postDelayed({
                                    val svc = NovaAccessibilityService.instance
                                    var sent = svc?.clickByDescription("Send") ?: false
                                    if (!sent) sent = svc?.clickByDescription("යවන්න") ?: false
                                    if (!sent) NovaBus.lastError = "whatsapp_send_button_not_found"
                                    pendingActionResults.add("whatsapp.send=${if (sent) "ok" else "failed"}")
                                }
                            }
                        }
                    }
                    "call.dial" -> {
                        val num = args.optString("number")
                        ok = num.isNotBlank()
                        if (ok) openIntent(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$num")))
                    }
                    "settings.open_wifi" -> openIntent(Intent(Settings.ACTION_WIFI_SETTINGS))
                    "settings.open_data" -> openIntent(Intent(Settings.ACTION_WIRELESS_SETTINGS))
                    "settings.open_bluetooth" -> openIntent(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
                    "settings.open_general" -> openIntent(Intent(Settings.ACTION_SETTINGS))
                    "reminder.set" -> {
                        ok = scheduleReminder(args.optString("message"), args.optInt("delay_minutes", -1), args.optString("at_hhmm"))
                    }
                    else -> ok = false
                }
                results.add("$name=${if (ok) "ok" else "failed"}")
            } catch (e: Exception) {
                results.add("${actions.optJSONObject(i)?.optString("action") ?: "unknown"}=error:${e.javaClass.simpleName}")
            }
        }
        pendingActionResults.addAll(results)
    }

    private fun scheduleReminder(message: String, delayMinutes: Int, atHhmm: String): Boolean {
        if (message.isBlank()) return false
        val alarm = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(this, ReminderReceiver::class.java).putExtra("message", message)
        val requestCode = (System.currentTimeMillis() and 0x7fffffff).toInt()
        val pi = PendingIntent.getBroadcast(
            this, requestCode, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val now = Calendar.getInstance()
        val whenMs: Long = when {
            delayMinutes >= 0 -> System.currentTimeMillis() + delayMinutes.coerceAtLeast(1) * 60_000L
            Regex("^\\d{2}:\\d{2}$").matches(atHhmm) -> {
                val parts = atHhmm.split(":")
                val h = parts[0].toIntOrNull() ?: return false
                val m = parts[1].toIntOrNull() ?: return false
                if (h !in 0..23 || m !in 0..59) return false
                now.set(Calendar.HOUR_OF_DAY, h)
                now.set(Calendar.MINUTE, m)
                now.set(Calendar.SECOND, 0)
                now.set(Calendar.MILLISECOND, 0)
                if (now.timeInMillis <= System.currentTimeMillis()) now.add(Calendar.DAY_OF_YEAR, 1)
                now.timeInMillis
            }
            else -> return false
        }
        alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, whenMs, pi)
        return true
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private fun openUrl(url: String) {
        openIntent(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
    }

    private fun openIntent(intent: Intent) {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { startActivity(intent) } catch (_: Exception) { }
    }

    private fun openAppByName(name: String): Boolean {
        if (name.isBlank()) return false
        val pm = packageManager
        val apps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
        val normalized = name.trim().lowercase(Locale.ROOT)
        val target = apps.firstOrNull {
            pm.getApplicationLabel(it).toString().lowercase(Locale.ROOT).contains(normalized)
        } ?: apps.firstOrNull {
            it.packageName.lowercase(Locale.ROOT).contains(normalized)
        } ?: return false
        val intent = pm.getLaunchIntentForPackage(target.packageName) ?: return false
        openIntent(intent)
        return true
    }

    // ---------- TTS ----------

    private fun speak(s: String) {
        mainHandler.post {
            NovaBus.state = NovaState.SPEAKING
            updateNotification("කතා කරනවා...")
            tts.setSpeechRate(lastRate)
            tts.setPitch(lastPitch)
            tts.speak(s, TextToSpeech.QUEUE_FLUSH, null, "nova")
        }
        mainHandler.postDelayed({ if (running) listen() }, estimateSpeechMs(s))
    }

    private fun speakWithoutResumingListen(s: String) {
        mainHandler.post {
            NovaBus.state = NovaState.EXECUTING
            updateNotification("කරගෙන යනවා...")
            tts.setSpeechRate(lastRate)
            tts.setPitch(lastPitch)
            tts.speak(s, TextToSpeech.QUEUE_FLUSH, null, "nova")
        }
    }

    private fun estimateSpeechMs(s: String): Long = (s.length * 70L).coerceIn(1200L, 12000L)

    override fun onInit(s: Int) {
        if (s == TextToSpeech.SUCCESS) {
            tts.language = Locale("si", "LK")
        }
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        // No-op on purpose: android:stopWithTask="false" + this override keep
        // Nova running after the app is swiped away from Recents.
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        instance = null
        running = false
        NovaBus.isServiceRunning = false
        NovaBus.state = NovaState.OFFLINE
        sr?.destroy()
        tts.shutdown()
        super.onDestroy()
    }

    override fun onBind(i: Intent?): IBinder? = null
}
