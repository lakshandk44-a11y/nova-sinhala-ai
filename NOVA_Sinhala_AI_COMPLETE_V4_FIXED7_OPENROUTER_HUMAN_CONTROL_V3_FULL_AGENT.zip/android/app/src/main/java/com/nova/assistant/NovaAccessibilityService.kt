package com.nova.assistant

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.graphics.Rect

class NovaAccessibilityService : AccessibilityService() {

    companion object {
        var instance: NovaAccessibilityService? = null
            private set
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun clickText(text: String): Boolean {
        val root=rootInActiveWindow ?: return false
        val nodes=root.findAccessibilityNodeInfosByText(text)
        for (node in nodes) {
            val ok=if (node.isClickable)
                node.performAction(AccessibilityNodeInfo.ACTION_CLICK) else false
            node.recycle()
            if (ok) return true
        }
        return false
    }

    /** For icon-only controls (e.g. WhatsApp's Send button has no visible text,
     * only a contentDescription), since findAccessibilityNodeInfosByText is not
     * reliable for those. */
    fun clickByDescription(description: String): Boolean {
        val root = rootInActiveWindow ?: return false
        var found = false
        fun walk(node: AccessibilityNodeInfo?, depth: Int) {
            if (node == null || found || depth > 20) return
            val desc = node.contentDescription?.toString()
            if (desc != null && desc.equals(description, ignoreCase = true) && node.isClickable) {
                found = node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                return
            }
            for (i in 0 until node.childCount) {
                if (found) break
                walk(node.getChild(i), depth + 1)
            }
        }
        walk(root, 0)
        return found
    }


    /** Generic screen-aware click. It matches visible text, contentDescription,
     * resource-id and (as a last resort) a normalized substring, then clicks the
     * nearest clickable node. This lets Nova act on unfamiliar apps without a
     * hard-coded action for every button. */
    fun clickQuery(query: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val q = query.trim().lowercase()
        if (q.isBlank()) return false
        var best: AccessibilityNodeInfo? = null
        var bestScore = Int.MIN_VALUE
        fun walk(node: AccessibilityNodeInfo?, depth: Int) {
            if (node == null || depth > 28) return
            val text = node.text?.toString()?.trim()?.lowercase().orEmpty()
            val desc = node.contentDescription?.toString()?.trim()?.lowercase().orEmpty()
            val rid = node.viewIdResourceName?.lowercase().orEmpty()
            var score = Int.MIN_VALUE
            if (text == q || desc == q || rid == q) score = 100
            else if (text.contains(q) || desc.contains(q) || rid.contains(q)) score = 80
            else {
                val tokens = q.split(Regex("\\s+")).filter { it.length > 1 }
                val hits = tokens.count { text.contains(it) || desc.contains(it) || rid.contains(it) }
                if (hits > 0) score = 40 + hits * 5
            }
            if (score > bestScore && node.isVisibleToUser && node.isEnabled) {
                var candidate: AccessibilityNodeInfo? = node
                while (candidate != null && !candidate.isClickable) {
                    candidate = candidate.parent
                }
                if (candidate != null && candidate.isClickable) {
                    best = AccessibilityNodeInfo.obtain(candidate)
                    bestScore = score
                }
            }
            for (i in 0 until node.childCount) walk(node.getChild(i), depth + 1)
        }
        walk(root, 0)
        val target = best ?: return false
        val ok = target.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        target.recycle()
        return ok
    }

    fun focusInput(): Boolean {
        val root = rootInActiveWindow ?: return false
        val node = findFirstEditable(root) ?: return false
        val ok = node.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        node.recycle()
        return ok
    }

    fun clearInput(): Boolean {
        val root = rootInActiveWindow ?: return false
        val node = findFirstEditable(root) ?: return false
        val current = node.text?.length ?: 0
        val b = android.os.Bundle()
        b.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT, 0)
        b.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT, current)
        node.performAction(AccessibilityNodeInfo.ACTION_SET_SELECTION, b)
        val empty = android.os.Bundle()
        empty.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, "")
        val ok = node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, empty)
        node.recycle()
        return ok
    }


    fun setText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val node = findFirstEditable(root) ?: return false
        val b = android.os.Bundle()
        b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        val ok = node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
        node.recycle()
        return ok
    }

    private fun findFirstEditable(node: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (node == null) return null
        if (node.isEditable && node.isEnabled) return node
        for (i in 0 until node.childCount) {
            val found = findFirstEditable(node.getChild(i))
            if (found != null) return found
        }
        return null
    }

    fun scrollForward(): Boolean {
        val root=rootInActiveWindow ?: return false
        val node=findScrollable(root) ?: return false
        val ok=node.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)
        node.recycle(); return ok
    }

    fun scrollBackward(): Boolean {
        val root=rootInActiveWindow ?: return false
        val node=findScrollable(root) ?: return false
        val ok=node.performAction(AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)
        node.recycle(); return ok
    }

    private fun findScrollable(node: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (node == null) return null
        if (node.isScrollable && node.isEnabled) return node
        for (i in 0 until node.childCount) {
            val found=findScrollable(node.getChild(i))
            if (found != null) return found
        }
        return null
    }

    fun swipe(x1:Float,y1:Float,x2:Float,y2:Float,durationMs:Long=350L):Boolean {
        val path=Path().apply { moveTo(x1,y1); lineTo(x2,y2) }
        val stroke=GestureDescription.StrokeDescription(path,0,durationMs.coerceIn(80L,2000L))
        return dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(),null,null)
    }

    fun longPress(x:Float,y:Float,durationMs:Long=650L):Boolean {
        val path=Path().apply { moveTo(x,y) }
        val stroke=GestureDescription.StrokeDescription(path,0,durationMs.coerceIn(300L,3000L))
        return dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(),null,null)
    }

    fun powerDialog(): Boolean = performGlobalAction(GLOBAL_ACTION_POWER_DIALOG)
    fun lockScreen(): Boolean = performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
    fun takeScreenshot(): Boolean {
        return if (android.os.Build.VERSION.SDK_INT >= 30)
            performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)
        else false
    }

    fun back(): Boolean = performGlobalAction(GLOBAL_ACTION_BACK)
    fun home(): Boolean = performGlobalAction(GLOBAL_ACTION_HOME)
    fun notifications(): Boolean = performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)

    fun tap(x:Float,y:Float):Boolean {
        val path=Path().apply { moveTo(x,y) }
        val stroke=GestureDescription.StrokeDescription(path,0,40)
        val gesture=GestureDescription.Builder().addStroke(stroke).build()
        return dispatchGesture(gesture,null,null)
    }

    /**
     * Best-effort snapshot of what's currently on screen — both what's
     * clickable/typeable AND plain readable text — so Nova can actually read
     * and reason about a screen ("meke mokakda thiyenne"), not just know
     * what's tappable. Each item is tagged so the AI knows what it can do
     * with it: [button], [input], or plain readable text.
     *
     * Real platform limits (not something Nova can work around): apps that
     * mark a screen FLAG_SECURE (banking PIN entry, some payment screens)
     * hide their content from accessibility entirely by OS design, and some
     * web pages only expose text once it's actually laid out on screen.
     */
    fun screenSnapshot(maxItems: Int = 90): List<String> {
        val root = rootInActiveWindow ?: return emptyList()
        val out = mutableListOf<String>()
        val seen = mutableSetOf<String>()
        fun walk(node: AccessibilityNodeInfo?, depth: Int) {
            if (node == null || out.size >= maxItems || depth > 28) return
            val text = node.text?.toString()?.trim().orEmpty()
            val desc = node.contentDescription?.toString()?.trim().orEmpty()
            val rid = node.viewIdResourceName?.trim().orEmpty()
            val label = when { text.isNotBlank() -> text; desc.isNotBlank() -> desc; rid.isNotBlank() -> rid; else -> "" }
            if (label.isNotBlank()) {
                val r = Rect()
                node.getBoundsInScreen(r)
                val meta = "bounds=${r.left},${r.top},${r.right},${r.bottom} class=${node.className ?: "?"} id=${rid.ifBlank { "-" }}"
                val flags = buildString {
                    if (node.isClickable) append(" clickable")
                    if (node.isEditable) append(" editable")
                    if (node.isScrollable) append(" scrollable")
                    if (node.isCheckable) append(" checkable=${node.isChecked}")
                    if (node.isSelected) append(" selected")
                    if (!node.isEnabled) append(" disabled")
                }
                val key = "$label|$rid|${r.left}|${r.top}|${node.className}"
                if (seen.add(key)) {
                    when {
                        node.isClickable -> out.add("[button x=${(r.left+r.right)/2} y=${(r.top+r.bottom)/2} desc=${desc.ifBlank { "-" }} id=${rid.ifBlank { "-" }}] $label | $meta$flags")
                        node.isEditable -> out.add("[input id=${rid.ifBlank { "-" }}] $label | $meta$flags")
                        else -> out.add("$label | $meta$flags")
                    }
                }
            }
            for (i in 0 until node.childCount) {
                if (out.size >= maxItems) break
                walk(node.getChild(i), depth + 1)
            }
        }
        walk(root, 0)
        return out
    }

    override fun onDestroy() {
        if (instance === this) instance = null
        super.onDestroy()
    }
}
