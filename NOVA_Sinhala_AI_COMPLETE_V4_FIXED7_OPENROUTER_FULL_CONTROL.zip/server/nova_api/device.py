from .audit import record
from .models import DeviceAction, ActionResult

# The VPS never directly controls Android. It creates signed/authenticated action requests;
# the Android client validates permission and executes the narrow allowlisted action.
ALLOWED = {
    "device.status": "LOW",
    "ui.back": "LOW",
    "ui.home": "LOW",
    "ui.notifications": "LOW",
    "ui.tap": "MEDIUM",
    "ui.click_text": "MEDIUM",
    "ui.click_description": "MEDIUM",
    "ui.type_text": "MEDIUM",
    "ui.swipe": "MEDIUM",
    "ui.scroll": "LOW",
    "ui.recent": "LOW",
    "ui.quick_settings": "LOW",
    "media.play_pause": "LOW",
    "media.volume_up": "LOW",
    "media.volume_down": "LOW",
    "media.mute": "LOW",
    "clipboard.read": "HIGH",
    "clipboard.write": "HIGH",
    "app.open": "LOW",                 # open an installed app by name/package
    "app.youtube_search": "LOW",       # open YouTube with a search query
    "app.google_search": "LOW",        # open a Google search (browser)
    "whatsapp.open_chat": "MEDIUM",    # open a WhatsApp chat (optionally pre-filled text)
    "call.dial": "MEDIUM",             # open dialer pre-filled with a number (user taps call)
    "call.place": "HIGH",              # actually place the call automatically
    "settings.open_wifi": "LOW",       # open the Wi-Fi settings panel
    "settings.open_data": "LOW",       # open the mobile data settings panel
    "settings.open_bluetooth": "LOW",  # open the Bluetooth settings panel
}

def validate_action(a: DeviceAction):
    expected=ALLOWED.get(a.action)
    if not expected:
        return False, "Action is not allowlisted."
    if a.permission != "android.device_control":
        return False, "Required Android permission is not granted."
    if a.requires_confirmation and a.risk in ("HIGH","CRITICAL"):
        return False, "User confirmation is required on the phone."
    return True, "validated"

def enqueue(a: DeviceAction):
    ok,msg=validate_action(a)
    result=ActionResult(a.request_id,a.action_id,ok,msg,{})
    record(a.request_id,a.action,a.risk,a.requires_confirmation,result.model_dump())
    return result
