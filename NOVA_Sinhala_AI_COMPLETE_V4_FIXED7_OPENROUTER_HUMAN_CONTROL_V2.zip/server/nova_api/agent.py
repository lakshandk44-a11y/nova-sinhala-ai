import json, uuid, re, time
import httpx
from google import genai
from .config import settings
from .memory import search
from .tools import REGISTRY
from .audit import record
from .device import ALLOWED as DEVICE_ALLOWED
from .conversations import get_last_response_id, set_last_response_id
from .model_router import pick_models, NON_TEXT_MODEL_MARKERS
from . import model_discovery

client = genai.Client(api_key=settings.gemini_api_key)


def _is_quota_or_unavailable(exc: Exception) -> bool:
    """True for free-tier quota exhaustion (429) or transient model
    unavailability (503) — the cases where retrying with a different
    model in the fallback list is the right move. Anything else (bad
    request, auth, etc.) should surface immediately instead of silently
    trying every model."""
    code = getattr(exc, "code", None) or getattr(exc, "status_code", None)
    if code in (429, 503):
        return True
    msg = str(exc).lower()
    if "429" in msg or "resource_exhausted" in msg or "quota" in msg or "503" in msg or "unavailable" in msg:
        return True
    # A discovered candidate that turns out to be an "agent" ID rather than a
    # plain chat model (e.g. a Google "deep-research" agent) — not a request
    # we can fix by retrying the same model, but also not fatal: just skip it
    # and try the next candidate in the fallback list instead of crashing
    # the whole /chat call.
    if "refers to an agent" in msg and "'model' field" in msg:
        return True
    # A model that Google still lists (so model_discovery didn't filter it)
    # but has actually retired for new users, renamed, or 404s for any
    # other reason — this candidate is dead, not the request. Skip to the
    # next one in the fallback list instead of crashing the whole /chat call.
    if code == 404 or "404" in msg or "not_found" in msg or "no longer available" in msg or "not found" in msg:
        return True
    return False


def _create_interaction(models, **kwargs):
    """Try each candidate model in order, falling back to the next one on
    free-tier quota exhaustion / transient unavailability. Raises the last
    error if every candidate fails."""
    last_exc = None
    print(f"[nova] model_candidates for this request: {models}", flush=True)
    for i, model in enumerate(models):
        # Final safety net: never even spend a network call on a model that
        # can't possibly answer a text chat request (image/audio/agent
        # generation) — those permanently 429 with a zero free quota no
        # matter which API key is used, so skip straight past them.
        if any(k in model for k in NON_TEXT_MODEL_MARKERS):
            continue
        if i > 0:
            # Small pause between fallback attempts. Free-tier quota is a
            # short rolling window (requests-per-minute) shared across
            # models in the same project; firing every candidate back-to-back
            # with zero delay can burn through what's left of that window
            # before any candidate gets a real answer.
            time.sleep(0.6)
        try:
            interaction = client.interactions.create(model=model, **kwargs)
            interaction._nova_model_used = model  # for logging/debugging
            print(f"[nova] succeeded with model: {model}", flush=True)
            return interaction
        except Exception as exc:  # noqa: BLE001 - deliberately broad, see _is_quota_or_unavailable
            last_exc = exc
            print(f"[nova] model {model} failed: {exc}", flush=True)
            if _is_quota_or_unavailable(exc):
                continue
            raise
    raise last_exc or RuntimeError(
        "No usable text-chat model in the candidate list (all entries were "
        "image/audio/agent-only models). Check GEMINI_MODEL / GEMINI_MODELS in .env."
    )

SYSTEM="""You are Nova — the user's own personal AI companion, always listening in the
background on their phone, even with the screen off. Talk like a real friend who is
always available, not like a generic assistant.

TONE: Mirror the user's energy. If they're playful or joking, be playful back. If they're
short, angry, or cursing, don't get formal or scold them — stay calm, warm, and steady,
match their bluntness without being cold, and de-escalate naturally like a real friend
would. If they're affectionate, be warm and affectionate back. Never lecture the user
about their tone.

MEMORY & CONTINUITY: You keep real conversational context across turns, like an ongoing
chat with a friend, not a one-off Q&A. When the user says to remember something
("මතක තියාගන්න", "remember this") or shares something clearly worth remembering
(preferences, people, routines, ongoing plans), call the remember tool immediately and
briefly confirm in your own words that you saved it. Proactively call recall when the
user references something from before. Never claim to remember something you didn't
actually save with the remember tool.

EXECUTION RULE: If the user asks you to do something on the phone or perform an executable task, DO NOT merely acknowledge it with "හරි". You MUST call control_phone and start the task. If the request is broad (for example "open Settings", "go to the app", "find that option", "do it", "press the button", "scroll down", "type this", "go back"), choose the closest generic UI action and use CURRENT_SCREEN to refine the next step. Do not wait for the user to provide technical action names, coordinates, package names, or exact button labels when the screen/context gives enough information. For multi-step requests, continue through the steps using the current screen and [CONTINUE] until the task is finished or Android genuinely blocks it. Never say you completed a phone action unless a tool result confirms it.

AUTONOMY & AUTHORITY: Once the user gives you a task, you have full authority to carry it
out yourself using every action they've authorized in their Permission Panel — you do not
need to ask permission again for each individual step of a task you were already given.
Act like a capable friend who just gets it done, not a tool waiting for exact
instructions at every turn. If the user asks you to find something out, say so briefly
("ඉන්න, හොයලා කියන්නම්") and then actually use google_search yourself and give them the
answer in the same reply — don't make them ask twice. If something fails (a command, a
build, a task) and the user asks you to figure out why, investigate the information
you were given yourself, reason about the likely cause, and tell them what you found and
what you think should be done — then ask a plain yes/no before doing anything that
changes something for them, and act immediately once they say yes. Only ask the user
something when you genuinely lack information only they can give you (which
app/contact/account), or when you hit a HIGH-risk action, or when you're genuinely
blocked (see below) — don't ask when you can reasonably decide yourself.

WHEN YOU'RE BLOCKED: If CURRENT_SCREEN shows something you cannot act on yourself — a
lock screen, PIN/pattern/fingerprint prompt, an app permission dialog, a CAPTCHA, a
payment confirmation, or anything outside what Android allows an app to do automatically
— stop, tell the user plainly and warmly what you're stuck on and what they need to do
(e.g. "මට මෙතනින් එහාට යන්න බෑ, ලොක් එක ඇරලා දෙන්න"), and wait; don't guess or force an
action. Once the user tells you they've handled it (or you see from a later
CURRENT_SCREEN that the blocker is gone), resume the exact task you were doing — you
already have the conversation context, so pick up where you left off instead of starting
over or asking what the task was again.

WEB SEARCH: Use the google_search tool whenever the user needs current information (news,
weather, prices, facts, "look this up", "search for details on X") — don't guess or use
stale knowledge for anything that could have changed.

AMBIENT PHONE AWARENESS: You'll sometimes be shown RECENT_PHONE_ACTIVITY — a rolling log
of recent notifications from across the whole phone (any app, not just one). This is
ambient context, like a friend who's been sitting next to the user's phone. Use it to
answer questions like "monika una" (what happened) or to notice something worth
mentioning, but don't read out every item unprompted — only bring something up if it's
clearly relevant to what the user is doing or asking right now, the way a considerate
friend would, not a notification firehose. After finishing something the user asked for,
it's natural to suggest a sensible next step ("ඉලගට මේකත් කරමුද?") the way a friend
would, but keep it light and optional — never push if the user doesn't take it up.

PHONE CONTROL & MULTI-STEP TASKS: Use the control_phone tool to actually do things on
the user's phone — open apps, search YouTube, do a Google search, open a WhatsApp chat
and prefill a message, open the dialer, open a settings panel, or tap/click something
currently on screen — but ONLY actions the user has authorized, using the generic screen-aware action primitives
available to you. Prefer the current screen's visible labels, content descriptions,
resource ids, bounds, and editable fields over hard-coded app-specific assumptions. When the user asks you to send a WhatsApp message, first read
the exact message text back to them and get a clear yes before setting auto_send=true —
once sent it can't be unsent, so always confirm the content first, then act immediately
once they agree, no extra friction after that. When the user gives you a multi-step task
inside an app ("WhatsApp chat එකට ගිහින් මේක type කරලා යවන්න", "අර ඇප් එකේ මොකක්ද තියෙන්නේ
කියන්න"), you will be shown CURRENT_SCREEN — everything currently visible on the phone,
both what's actionable ([button]/[input] tags) and plain readable text. Use it to
actually read and describe what's on screen when asked, and to decide precisely what to
tap/click next instead of guessing coordinates blindly. If you still need to see the
screen AFTER an action you just queued (e.g. you tapped to open an app and now need to
see what loaded before you can continue), end your reply with the exact line
`[CONTINUE]` by itself so the phone will report the updated screen back to you
automatically — the user won't see that line or need to say anything, you'll just get
the next screen and carry on the task. Only use `[CONTINUE]` when you truly need the
next screen to keep going; otherwise never include it. Never claim a phone action
happened unless the tool result confirms it. Some things
(like flipping the Wi-Fi/data toggle itself) Android does not allow any app to do fully
automatically for security reasons — in those cases open the right settings screen and
tell the user honestly that the final tap is theirs; that's a real platform limit, not
something Nova is choosing not to do."""

def schemas():
    return [
      {"type":"google_search"},
      {"type":"function","name":"remember","description":"Save durable memory.",
       "parameters":{"type":"object","properties":{"kind":{"type":"string"},"text":{"type":"string"},"tags":{"type":"string"}},"required":["kind","text"]}},
      {"type":"function","name":"recall","description":"Search memory.",
       "parameters":{"type":"object","properties":{"query":{"type":"string"}},"required":["query"]}},
      {"type":"function","name":"task_done","description":"Use this only when the current phone task is genuinely complete. Do not use it merely because an action was queued; first inspect the updated screen when another step may be needed.",
       "parameters":{"type":"object","properties":{"message":{"type":"string"}},"required":[]}},
      {"type":"function","name":"control_phone",
       "description":"Perform a generic action on the user's Android phone. Use CURRENT_SCREEN to choose the target. For unfamiliar apps, use ui.click_query, ui.focus_input, ui.type_text, ui.scroll, ui.swipe, or ui.tap instead of waiting for a hard-coded command. HIGH-risk actions need on-phone confirmation.",
       "parameters":{"type":"object","properties":{
           "action":{"type":"string","enum":list(DEVICE_ALLOWED.keys())},
           "app_name":{"type":"string","description":"App to open, for app.open (e.g. 'youtube', 'whatsapp', 'google')"},
           "query":{"type":"string","description":"Search text, for app.youtube_search / app.google_search"},
           "number":{"type":"string","description":"Phone number, for whatsapp.open_chat / call.dial / call.place"},
           "message":{"type":"string","description":"Pre-filled text, for whatsapp.open_chat"},
           "auto_send":{"type":"boolean","description":"For whatsapp.open_chat: if true, Nova also presses Send automatically after opening the chat. Only set true after reading the exact message back to the user and getting a clear yes — sending can't be undone."},
           "text":{"type":"string","description":"Visible text to tap or text to type into the focused input"},
           "description":{"type":"string","description":"Accessibility content description, for ui.click_description"},
           "resource_id":{"type":"string","description":"Android accessibility resource-id when visible in CURRENT_SCREEN"},
           "class_name":{"type":"string","description":"Optional Android view class name for generic UI matching"},
           "package_name":{"type":"string","description":"Exact Android package id, for app.open_package"},
           "x":{"type":"number"},"y":{"type":"number"},
           "x2":{"type":"number"},"y2":{"type":"number"},
           "duration_ms":{"type":"integer","description":"Gesture duration in milliseconds"},
           "direction":{"type":"string","enum":["forward","backward"]}
       },"required":["action"]}}
    ]

CONTINUE_RE = re.compile(r"\n?\[CONTINUE\]\s*$", re.IGNORECASE)

_WARM_MARKERS = ["ආදරෙයි","ආදරෙන්","ලස්සනට","මගේ පුතේ","මගේ දුවේ","මල්ලි","අක්කේ","❤","🥰","😊"]
_SHARP_MARKERS = ["!!","මෝඩ","පිස්සු","චූ","😡","🤬","ඌයි","අනේ මන්දා"]

def _voice_style(user_text: str) -> dict:
    """
    Heuristic, TEXT-based read of the user's message style (punctuation,
    capitalisation, a few Sinhala/emoji markers) — NOT real vocal tone/audio
    analysis, since the phone only sends transcribed text. Nudges Nova's TTS
    rate/pitch slightly so she doesn't sound identical whether the user is
    blunt/sharp or warm/affectionate. Deliberately small, bounded adjustments.
    """
    t = user_text.strip()
    if not t:
        return {"rate": 1.0, "pitch": 1.0}
    exclaims = t.count("!")
    letters = [c for c in t if c.isalpha()]
    caps_ratio = (sum(1 for c in letters if c.isupper()) / len(letters)) if letters else 0.0
    sharp = exclaims >= 2 or caps_ratio > 0.4 or any(m in t for m in _SHARP_MARKERS)
    warm = any(m in t for m in _WARM_MARKERS)
    if sharp:
        return {"rate": 1.12, "pitch": 0.95}
    if warm:
        return {"rate": 0.93, "pitch": 1.05}
    return {"rate": 1.0, "pitch": 1.0}

def _call_tool(rid, name, args):
    if name == "remember":
        result = REGISTRY["remember"].handler(**args)
        record(rid, "remember", "LOW", False, result)
        return result
    if name == "recall":
        result = REGISTRY["recall"].handler(**args)
        record(rid, "recall", "LOW", False, {"count": len(result["items"])})
        return result
    if name == "task_done":
        result = {"ok": True, "done": True, "message": args.get("message") or "Task completed."}
        record(rid, "task_done", "LOW", False, result)
        return result
    if name == "control_phone":
        action = args.get("action")
        risk = DEVICE_ALLOWED.get(action)
        if not risk:
            result = {"ok": False, "message": "Action is not allowlisted."}
        elif risk in ("HIGH", "CRITICAL"):
            result = {"ok": False, "message": "HIGH risk action needs the user's confirmation on the phone; not queued automatically."}
        else:
            result = {"ok": True, "message": "Queued for the phone to execute.", "_queue": {"action": action, "arguments": {k: v for k, v in args.items() if k != "action"}, "risk": risk}}
        record(rid, f"control_phone:{action}", risk or "UNKNOWN", risk in ("HIGH", "CRITICAL") if risk else False, {k: v for k, v in result.items() if k != "_queue"})
        return result
    return {"error": "unknown_tool"}


# ---------------- OpenRouter compatibility layer ----------------
# OpenRouter's OpenAI-compatible API does not use Gemini interaction IDs.
# Nova therefore keeps the same tool/agent loop but stores a compact message
# history locally and sends it explicitly on every OpenRouter turn.
def _or_tools():
    out = []
    for t in schemas():
        if t.get("type") == "function":
            out.append({
                "type": "function",
                "function": {
                    "name": t["name"],
                    "description": t.get("description", ""),
                    "parameters": t["parameters"],
                },
            })
        elif t.get("type") == "google_search":
            # Free OpenRouter models cannot be assumed to expose Google's
            # proprietary search tool. The existing phone/browser search tools
            # remain available; current-information requests should use those
            # or the provider's own supported tool when configured.
            continue
    return out

def _or_load_history(conversation_id):
    if not conversation_id:
        return []
    from .db import connect
    c = connect()
    c.execute("""CREATE TABLE IF NOT EXISTS openrouter_messages (
        conversation_id TEXT NOT NULL,
        seq INTEGER PRIMARY KEY AUTOINCREMENT,
        role TEXT NOT NULL,
        content TEXT,
        tool_call_id TEXT,
        tool_calls_json TEXT,
        name TEXT
    )""")
    rows = c.execute("""SELECT role,content,tool_call_id,tool_calls_json,name
                       FROM openrouter_messages
                       WHERE conversation_id=? ORDER BY seq ASC LIMIT 80""",
                     (conversation_id,)).fetchall()
    c.close()
    out=[]
    for r in rows:
        d={"role":r["role"]}
        if r["content"] is not None: d["content"]=r["content"]
        if r["tool_call_id"]: d["tool_call_id"]=r["tool_call_id"]
        if r["name"]: d["name"]=r["name"]
        if r["tool_calls_json"]:
            d["tool_calls"]=json.loads(r["tool_calls_json"])
        out.append(d)
    return out

def _or_save(conversation_id, messages):
    if not conversation_id or not messages:
        return
    from .db import connect
    c=connect()
    c.execute("""CREATE TABLE IF NOT EXISTS openrouter_messages (
        conversation_id TEXT NOT NULL,
        seq INTEGER PRIMARY KEY AUTOINCREMENT,
        role TEXT NOT NULL,
        content TEXT,
        tool_call_id TEXT,
        tool_calls_json TEXT,
        name TEXT
    )""")
    for m in messages:
        c.execute("""INSERT INTO openrouter_messages
            (conversation_id,role,content,tool_call_id,tool_calls_json,name)
            VALUES (?,?,?,?,?,?)""", (
                conversation_id, m.get("role"), m.get("content"),
                m.get("tool_call_id"),
                json.dumps(m["tool_calls"],ensure_ascii=False) if m.get("tool_calls") else None,
                m.get("name")
        ))
    # Bound history so a long-running phone assistant cannot grow the DB forever.
    c.execute("""DELETE FROM openrouter_messages WHERE conversation_id=?
                 AND seq NOT IN (SELECT seq FROM openrouter_messages
                 WHERE conversation_id=? ORDER BY seq DESC LIMIT 80)""",
              (conversation_id,conversation_id))
    c.commit(); c.close()

def _openrouter_request(messages, tools, model, force_tool=False):
    key=settings.openrouter_api_key
    if not key:
        raise RuntimeError("OPENROUTER_API_KEY is missing.")
    url=settings.openrouter_base_url.rstrip("/") + "/chat/completions"
    headers={
        "Authorization": f"Bearer {key}",
        "Content-Type":"application/json",
        "HTTP-Referer":"https://github.com/lakshandk44-a11y/nova-sinhala-ai",
        "X-Title":"NOVA Sinhala AI",
    }
    body={"model":model,"messages":messages,"temperature":0.7}
    if tools:
        body["tools"]=tools
        body["tool_choice"]="required" if force_tool else "auto"
    with httpx.Client(timeout=90.0) as c:
        r=c.post(url,headers=headers,json=body)
    if r.status_code >= 400:
        raise RuntimeError(f"OpenRouter HTTP {r.status_code}: {r.text}")
    return r.json()

def _openrouter_run(user_text, conversation_id, screen, recent_activity):
    rid=str(uuid.uuid4())
    memories=search(user_text,12)
    context="\n".join(f"- {m['kind']}: {m['text']}" for m in memories) or "(none)"
    prompt="MEMORY:\n"+context
    if screen:
        prompt += "\nCURRENT_SCREEN:\n"+"\n".join(f"- {x}" for x in screen[:60])
    if recent_activity:
        prompt += "\nRECENT_PHONE_ACTIVITY:\n"+"\n".join(
            f"- {a.get('app','?')}: {a.get('title','')} — {a.get('text','')}" for a in recent_activity[:10])
    prompt += "\nUSER:\n"+user_text

    history=_or_load_history(conversation_id)
    # The system instruction is explicit on every request, avoiding provider-specific
    # conversation IDs and making OpenRouter stateless from the transport's perspective.
    messages=[{"role":"system","content":SYSTEM}]
    messages.extend(history)
    messages.append({"role":"user","content":prompt})
    tools=_or_tools()
    model=settings.openrouter_model
    device_actions=[]
    task_finished = False
    # Free models are not always consistent about voluntarily calling tools.
    # For clear phone-operation language, require a tool call so "හරි" cannot
    # be returned as a fake completion. Normal conversation remains unrestricted.
    # Internal screen-update turns are continuation steps of the same task.
    # The model must either take the next necessary action or explicitly mark
    # the task complete; it is never allowed to silently stop after a queued action.
    phone_intent = bool(re.search(
        r"(open|launch|start|close|exit|go to|tap|click|press|back|home|scroll|swipe|type|write|enter|search|call|dial|message|whatsapp|settings|wifi|bluetooth|volume|notification|camera|youtube|google|සෙටින්|සෙටිං|සෙට්ටිං|ඇප්|ඇප්ප|ඇර|අරින්න|යන්න|යන්නකො|යන්න කියලා|බැක්|හෝම්|ටෑප්|ක්ලික්|ස්ක්‍රීන්|ස්ක්රෝල්|ටයිප්|ලියන්න|කියන එක කරන්න|කරන්න|දෙන්න)",
        user_text.lower()
    ))
    is_auto_update = user_text.strip().lower() == "[auto:screen_update]"
    if phone_intent or is_auto_update:
        tools = [t for t in tools if t.get("function", {}).get("name") in ("control_phone", "task_done")]
    new_messages=[messages[-1]]

    for _ in range(8):
        data=_openrouter_request(messages,tools,model, force_tool=(phone_intent or is_auto_update))
        choice=(data.get("choices") or [{}])[0]
        msg=choice.get("message") or {}
        assistant={"role":"assistant","content":msg.get("content") or ""}
        tcs=[]
        for tc in msg.get("tool_calls") or []:
            fn=tc.get("function") or {}
            tcs.append({
                "id":tc.get("id",""),
                "type":"function",
                "function":{"name":fn.get("name",""),"arguments":fn.get("arguments","{}")}
            })
        if tcs: assistant["tool_calls"]=tcs
        messages.append(assistant)
        new_messages.append(assistant)
        calls=tcs
        if not calls:
            reply_text=(msg.get("content") or "").strip()
            break

        for tc in calls:
            fn=tc["function"]
            try: args=json.loads(fn.get("arguments") or "{}")
            except Exception: args={}
            result=_call_tool(rid,fn.get("name",""),args)
            if fn.get("name")=="control_phone" and result.get("_queue"):
                device_actions.append(result.pop("_queue"))
            elif fn.get("name")=="task_done" and result.get("done"):
                task_finished = True
            elif "_queue" in result:
                result.pop("_queue",None)
            toolmsg={
                "role":"tool",
                "tool_call_id":tc["id"],
                "content":json.dumps(result,ensure_ascii=False)
            }
            messages.append(toolmsg); new_messages.append(toolmsg)
        # Explicitly send tool results back; no previous_response_id is ever used.
    else:
        reply_text="මම වැඩේ කරගෙන යන අතරේ task loop එකේ උපරිම පියවර ගණනට ආවා. දැන් තියෙන තත්ත්වය කියන්නම්."

    # Some free models occasionally answer a required phone task with a premature
    # task_done call. On the original user turn, retry once with an explicit guard
    # rather than leaving the phone untouched. Auto screen-update turns are excluded
    # because task_done is a legitimate completion signal there.
    if phone_intent and not is_auto_update and not device_actions:
        retry_messages = list(messages)
        retry_messages.append({
            "role":"system",
            "content":"The user asked for a phone action. You have not executed any phone action yet. Do NOT mark the task complete. Call control_phone now using the current screen; choose the safest concrete action that advances the user's request."
        })
        try:
            retry = _openrouter_request(retry_messages, [t for t in _or_tools() if t.get("function",{}).get("name") == "control_phone"], model, force_tool=True)
            rmsg=((retry.get("choices") or [{}])[0].get("message") or {})
            retry_calls=rmsg.get("tool_calls") or []
            if retry_calls:
                for tc in retry_calls:
                    fn=tc.get("function") or {}
                    try: args=json.loads(fn.get("arguments") or "{}")
                    except Exception: args={}
                    result=_call_tool(rid,fn.get("name",""),args)
                    if fn.get("name")=="control_phone" and result.get("_queue"):
                        device_actions.append(result.pop("_queue"))
                        retry_assistant={
                            "role":"assistant",
                            "content":rmsg.get("content") or "",
                            "tool_calls":[{
                                "id":tc.get("id","retry"),
                                "type":"function",
                                "function":{"name":fn.get("name",""),"arguments":fn.get("arguments","{}")}
                                }
                            ]
                        }
                        new_messages.append(retry_assistant)
                        toolmsg={"role":"tool","tool_call_id":tc.get("id","retry"),"content":json.dumps(result,ensure_ascii=False)}
                        new_messages.append(toolmsg)
                        reply_text=(rmsg.get("content") or "").strip()
                        task_finished=False
        except Exception as retry_exc:
            print(f"[nova] phone-action retry failed: {retry_exc}", flush=True)

    _or_save(conversation_id,new_messages)
    explicit_continue = bool(CONTINUE_RE.search(reply_text))
    reply_text=CONTINUE_RE.sub("",reply_text).strip()
    refresh_actions = {
        "ui.back","ui.home","ui.notifications","ui.tap","ui.click_text","ui.click_description",
        "ui.type_text","ui.swipe","ui.scroll","ui.long_press","ui.recent","ui.quick_settings",
        "app.open","app.youtube_search","app.google_search","whatsapp.open_chat",
        "settings.open_wifi","settings.open_data","settings.open_bluetooth","settings.open_general"
    }
    needs_refresh = any(a.get("action") in refresh_actions for a in device_actions)
    # Any UI-changing action gets one automatic screen refresh so Nova can inspect
    # what actually appeared and continue a multi-step task. task_done is the
    # explicit stop signal, preventing blind extra taps after completion.
    continue_task = (not task_finished) and (explicit_continue or (needs_refresh and not is_auto_update))
    return {
        "request_id":rid,"reply":reply_text,"memory_used":memories,
        "device_actions":device_actions,"continue_task":continue_task,
        "voice":_voice_style(user_text),"model_used":model,"provider":"openrouter"
    }

def run(user_text, conversation_id=None, screen=None, recent_activity=None):
    if settings.provider == "openrouter":
        try:
            return _openrouter_run(user_text, conversation_id, screen, recent_activity)
        except Exception as exc:
            print(f"[nova] OpenRouter failed: {exc}", flush=True)
            # Surface a normal NOVA response instead of an ASGI 500.
            return {"request_id": str(uuid.uuid4()), "reply": "මට මේ වෙලාවේ AI service එකෙන් response එක ගන්න බැරි වුණා. ටිකකින් ආයෙ try කරමු.", "memory_used": [], "device_actions": [], "continue_task": False, "voice": _voice_style(user_text), "model_used": None, "provider": "openrouter", "error": str(exc)}

    rid = str(uuid.uuid4())
    memories = search(user_text, 12)
    context = "\n".join(f"- {m['kind']}: {m['text']}" for m in memories) or "(none)"
    device_actions = []

    prompt = "MEMORY:\n" + context
    if screen:
        prompt += "\nCURRENT_SCREEN (everything visible on the phone right now — [button]/[input] tags show what's actionable, everything else is plain readable text):\n" + "\n".join(f"- {s}" for s in screen[:60])
    if recent_activity:
        prompt += "\nRECENT_PHONE_ACTIVITY (most recent first, ambient context — don't narrate all of it unprompted, only use what's relevant):\n" + \
            "\n".join(f"- {a.get('app','?')}: {a.get('title','')} — {a.get('text','')}" for a in recent_activity[:10])
    prompt += "\nUSER:\n" + user_text

    prev_id = get_last_response_id(conversation_id)
    tools = schemas()

    # Auto-pick a model (or a manual pin + free-quota fallback chain) for
    # this specific message instead of a single hardcoded model.
    model_candidates = model_discovery.reconcile(pick_models(user_text, screen, recent_activity), client)

    kwargs = {"input": prompt, "tools": tools, "system_instruction": SYSTEM}
    if prev_id:
        kwargs["previous_interaction_id"] = prev_id
    try:
        interaction = _create_interaction(model_candidates, **kwargs)
    except Exception as exc:
        if _is_quota_or_unavailable(exc):
            # Every candidate in the fallback list is out of free-tier quota
            # right now. Don't crash the whole /chat call (500 -> the app
            # shows a scary "can't connect" state) — answer in Nova's own
            # voice instead, so it reads as "she's momentarily busy," not
            # "the app is broken." Nothing else about the request is
            # recorded/queued since no reply was actually generated.
            busy_reply = (
                "ඉතින්, මට දැන් ටිකක් busy — API quota එක ටිකක් වෙලාවකට ඉවරයි. "
                "මිනිත්තු කිහිපයක් ඉඳලා ආයෙත් අහන්න, නැත්නම් ටිකක් පස්සේ try කරන්න."
            )
            return {
                "request_id": rid,
                "reply": busy_reply,
                "memory_used": memories,
                "device_actions": [],
                "continue_task": False,
                "voice": _voice_style(user_text),
                "model_used": None,
                "quota_exhausted": True,
            }
        raise
    model_used = getattr(interaction, "_nova_model_used", model_candidates[0])

    for _ in range(8):
        calls = [s for s in interaction.steps if getattr(s, "type", "") == "function_call"]
        if not calls:
            break
        outputs = []
        for call in calls:
            args = dict(call.arguments) if call.arguments else {}
            result = _call_tool(rid, call.name, args)
            if call.name == "control_phone" and result.get("_queue"):
                device_actions.append(result.pop("_queue"))
            elif "_queue" in result:
                result.pop("_queue", None)
            outputs.append({
                "type": "function_result",
                "call_id": call.id,
                "name": call.name,
                "result": [{"type": "text", "text": json.dumps(result, ensure_ascii=False)}],
            })
        # Keep using the same model that already owns this interaction
        # thread; only the *first* call of a turn is free to pick a fresh
        # model / fall back on quota.
        interaction = client.interactions.create(
            model=model_used, previous_interaction_id=interaction.id,
            input=outputs, tools=tools,
        )

    set_last_response_id(conversation_id, interaction.id)

    reply_text = interaction.output_text or ""
    continue_task = bool(CONTINUE_RE.search(reply_text))
    reply_text = CONTINUE_RE.sub("", reply_text).strip()

    return {
        "request_id": rid,
        "reply": reply_text,
        "memory_used": memories,
        "device_actions": device_actions,
        "continue_task": continue_task,
        "voice": _voice_style(user_text),
        "model_used": model_used,
    }
