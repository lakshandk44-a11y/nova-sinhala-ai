package com.nova.assistant

import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.speech.*
import android.speech.tts.TextToSpeech
import androidx.core.app.NotificationCompat
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.*
import org.json.JSONArray
import org.json.JSONObject
import com.nova.assistant.ui.NovaState

/**
 * The real, persistent NOVA voice loop.
 * - Foreground service (android:stopWithTask="false") so it survives the app
 *   being swiped away from Recents, and keeps working with the screen off.
 * - Passively listens for a wake word ("Nova"/"නෝවා"). Once triggered, opens
 *   an "active session" window where the user can talk naturally without
 *   repeating the wake word each time.
 * - Sends recognized speech to the VPS backend's /chat endpoint, speaks the
 *   reply with TTS, and executes any device_actions the AI requested
 *   (open apps, WhatsApp, dialer, search, settings panels, UI taps).
 */
class VoiceService : Service(), TextToSpeech.OnInitListener {

    companion object {
        const val CHANNEL_ID = "nova_voice"
        const val NOTIF_ID = 7
        const val ACTION_STOP = "com.nova.assistant.action.STOP"
        private val WAKE_WORDS = listOf("nova", "නෝවා", "නොවා", "නෝව")
        private const val ACTIVE_SESSION_MS = 60_000L

        var instance: VoiceService? = null
            private set
    }

    private var sr: SpeechRecognizer? = null
    private lateinit var tts: TextToSpeech
    private var running = true
    private var activeSessionUntil = 0L
    private var autoContinueDepth = 0
    private var pendingNotification: Triple<String, String, String>? = null // app, title, text
    private var lastRate = 1.0f
    private var lastPitch = 1.0f
    private val mainHandler = Handler(Looper.getMainLooper())

    private fun conversationId(): String {
        val p = getSharedPreferences("p", 0)
        var id = p.getString("conversation_id", null)
        if (id.isNullOrBlank()) {
            id = UUID.randomUUID().toString()
            p.edit().putString("conversation_id", id).apply()
        }
        return id
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        running = true
        NovaBus.isServiceRunning = true
        NovaBus.state = NovaState.IDLE
        NovaBus.lastError = ""

        tts = TextToSpeech(this, this)

        val nm = getSystemService(NotificationManager::class.java)
        val channel = NotificationChannel(
            CHANNEL_ID, "Nova Voice Assistant", NotificationManager.IMPORTANCE_LOW
        ).apply { description = "Nova is listening in the background" }
        nm.createNotificationChannel(channel)

        startForeground(NOTIF_ID, buildNotification("Nova is active", "සූදානම්... 'Nova' කියලා කතාකරන්න"))
        listen()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    private fun buildNotification(title: String, text: String): Notification {
        val stopIntent = PendingIntent.getService(
            this, 0, Intent(this, VoiceService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val openIntent = PendingIntent.getActivity(
            this, 0, packageManager.getLaunchIntentForPackage(packageName),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .setContentIntent(openIntent)
            .addAction(0, "නවත්වන්න", stopIntent)
            .build()
    }

    private fun updateNotification(text: String) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(NOTIF_ID, buildNotification("Nova is active", text))
    }

    private fun isSessionActive() = System.currentTimeMillis() < activeSessionUntil

    private fun extendSession() {
        activeSessionUntil = System.currentTimeMillis() + ACTIVE_SESSION_MS
    }

    /** Called by NovaNotificationListener when a monitored app gets a new message. */
    fun announceIncoming(app: String, title: String, text: String) {
        if (!running) return
        mainHandler.post {
            if (NovaBus.state == NovaState.THINKING || NovaBus.state == NovaState.SPEAKING ||
                NovaBus.state == NovaState.EXECUTING
            ) return@post // don't interrupt something already in progress
            pendingNotification = Triple(app, title, text)
            extendSession()
            speak("ආ, $app එකෙන් $title reply එකක් දැම්මා. අහන්නද?")
        }
    }

    private fun stripWakeWord(raw: String): Pair<Boolean, String> {
        val lower = raw.lowercase(Locale.ROOT)
        for (w in WAKE_WORDS) {
            val idx = lower.indexOf(w)
            if (idx >= 0) {
                val rest = (raw.substring(0, idx) + raw.substring(idx + w.length)).trim()
                return true to rest
            }
        }
        return false to raw
    }

    private fun listen() {
        if (!running) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            NovaBus.state = NovaState.ERROR
            NovaBus.lastError = "Speech recognition මෙ device එකේ නෑ."
            return
        }
        NovaBus.state = NovaState.LISTENING
        updateNotification(if (isSessionActive()) "සවන් දෙනවා..." else "'Nova' කියලා කතාකරන්න")

        sr?.destroy()
        sr = SpeechRecognizer.createSpeechRecognizer(this)
        sr!!.setRecognitionListener(object : RecognitionListener {
            override fun onResults(r: Bundle) {
                val x = r.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (x.isNullOrBlank()) {
                    if (running) mainHandler.postDelayed({ listen() }, 400)
                    return
                }

                val pending = pendingNotification
                if (pending != null) {
                    pendingNotification = null
                    val lower = x.lowercase(Locale.ROOT)
                    val yes = listOf("ඔව්", "ඔව", "අහන්නම්", "කියවන්න", "කියන්න", "yes", "read")
                    val no = listOf("එපා", "නෑ", "නැහැ", "no")
                    if (yes.any { lower.contains(it) }) {
                        NovaBus.transcript = x
                        speak("${pending.second} කිව්වේ — ${pending.third}")
                        return
                    } else if (no.any { lower.contains(it) }) {
                        speak("හරි.")
                        return
                    }
                    // else: not a yes/no — fall through and treat as a fresh command below
                }

                if (isSessionActive()) {
                    // Already in an active conversation: no wake word needed.
                    NovaBus.transcript = x
                    extendSession()
                    send(x)
                } else {
                    val (waked, rest) = stripWakeWord(x)
                    if (waked) {
                        extendSession()
                        if (rest.isBlank()) {
                            NovaBus.transcript = x
                            speak("මොකක්ද ඕන?")
                        } else {
                            NovaBus.transcript = rest
                            send(rest)
                        }
                    } else if (running) {
                        mainHandler.postDelayed({ listen() }, 350)
                    }
                }
            }
            override fun onError(e: Int) {
                if (running) mainHandler.postDelayed({ listen() }, 900)
            }
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(b: Bundle?) {}
            override fun onEvent(t: Int, p: Bundle?) {}
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "si-LK")
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        try {
            sr!!.startListening(i)
        } catch (e: Exception) {
            if (running) mainHandler.postDelayed({ listen() }, 900)
        }
    }

    private fun send(text: String, isAutoContinue: Boolean = false) {
        NovaBus.state = NovaState.THINKING
        updateNotification("හිතනවා...")
        Thread {
            try {
                val p = getSharedPreferences("p", 0)
                val u = p.getString("url", "") ?: ""
                val token = p.getString("token", "") ?: ""
                if (u.isBlank()) {
                    speak("මුලින් Settings එකෙන් VPS ලිපිනය සකස් කරන්න.")
                    return@Thread
                }
                val screen = NovaAccessibilityService.instance?.screenSnapshot() ?: emptyList()

                val body = JSONObject()
                    .put("text", text)
                    .put("conversation_id", conversationId())
                if (screen.isNotEmpty()) {
                    val arr = JSONArray()
                    screen.forEach { arr.put(it) }
                    body.put("screen", arr)
                }
                val activity = NovaNotificationListener.recentActivity(10)
                if (activity.isNotEmpty()) {
                    val arr = JSONArray()
                    activity.forEach {
                        arr.put(JSONObject().put("app", it.app).put("title", it.title).put("text", it.text))
                    }
                    body.put("recent_activity", arr)
                }

                val c = URL(u.trimEnd('/') + "/chat").openConnection() as HttpURLConnection
                c.requestMethod = "POST"
                c.doOutput = true
                c.connectTimeout = 15000
                c.readTimeout = 60000
                c.setRequestProperty("Content-Type", "application/json")
                c.setRequestProperty("X-Nova-Token", token)
                c.outputStream.use { it.write(body.toString().toByteArray()) }

                if (c.responseCode >= 400) {
                    val err = c.errorStream?.bufferedReader()?.readText() ?: "HTTP ${c.responseCode}"
                    throw RuntimeException(err)
                }
                val resp = JSONObject(c.inputStream.bufferedReader().readText())
                val reply = resp.optString("reply", "")
                val continueTask = resp.optBoolean("continue_task", false)
                resp.optJSONObject("voice")?.let { v ->
                    lastRate = v.optDouble("rate", 1.0).toFloat()
                    lastPitch = v.optDouble("pitch", 1.0).toFloat()
                }

                resp.optJSONArray("device_actions")?.let { actions ->
                    mainHandler.post { executeDeviceActions(actions) }
                }

                if (reply.isNotBlank()) {
                    NovaBus.response = reply
                }

                if (continueTask && autoContinueDepth < 8) {
                    // Nova needs to see the result of what it just did to keep
                    // going on a multi-step task — no user input required.
                    autoContinueDepth++
                    if (reply.isNotBlank()) {
                        speakWithoutResumingListen(reply)
                    }
                    mainHandler.postDelayed({ send("[auto:screen_update]", isAutoContinue = true) }, 1200)
                } else {
                    autoContinueDepth = 0
                    if (reply.isBlank() && isAutoContinue) {
                        if (running) listen()
                    } else {
                        speak(reply.ifBlank { "හරි." })
                    }
                }
            } catch (e: Exception) {
                autoContinueDepth = 0
                NovaBus.lastError = e.message ?: "connection_error"
                NovaBus.state = NovaState.ERROR
                speak("VPS එකට සම්බන්ධ වෙන්න බැරි වුණා.")
            }
        }.start()
    }

    // ---------- Device action execution ----------

    private fun executeDeviceActions(actions: JSONArray) {
        for (i in 0 until actions.length()) {
            try {
                val a = actions.getJSONObject(i)
                val args = a.optJSONObject("arguments") ?: JSONObject()
                when (a.optString("action")) {
                    "ui.back" -> NovaAccessibilityService.instance?.back()
                    "ui.home" -> NovaAccessibilityService.instance?.home()
                    "ui.notifications" -> NovaAccessibilityService.instance?.notifications()
                    "ui.click_text" -> args.optString("text").takeIf { it.isNotBlank() }
                        ?.let { NovaAccessibilityService.instance?.clickText(it) }
                    "ui.click_description" -> args.optString("description").takeIf { it.isNotBlank() }
                        ?.let { NovaAccessibilityService.instance?.clickByDescription(it) }
                    "ui.click_query" -> args.optString("query").takeIf { it.isNotBlank() }
                        ?.let { NovaAccessibilityService.instance?.clickQuery(it) }
                    "ui.focus_input" -> NovaAccessibilityService.instance?.focusInput()
                    "ui.clear_input" -> NovaAccessibilityService.instance?.clearInput()
                    "ui.type_text" -> args.optString("text").let { NovaAccessibilityService.instance?.setText(it) }
                    "ui.tap" -> NovaAccessibilityService.instance
                        ?.tap(args.optDouble("x").toFloat(), args.optDouble("y").toFloat())
                    "ui.swipe" -> NovaAccessibilityService.instance?.swipe(
                        args.optDouble("x").toFloat(), args.optDouble("y").toFloat(),
                        args.optDouble("x2").toFloat(), args.optDouble("y2").toFloat(),
                        args.optLong("duration_ms",350L)
                    )
                    "ui.scroll" -> {
                        if (args.optString("direction","forward").equals("backward",true))
                            NovaAccessibilityService.instance?.scrollBackward()
                        else NovaAccessibilityService.instance?.scrollForward()
                    }
                    "ui.long_press" -> NovaAccessibilityService.instance?.longPress(
                        args.optDouble("x").toFloat(), args.optDouble("y").toFloat(),
                        args.optLong("duration_ms",650L)
                    )
                    "ui.power_dialog" -> NovaAccessibilityService.instance?.powerDialog()
                    "ui.lock_screen" -> NovaAccessibilityService.instance?.lockScreen()
                    "ui.screenshot" -> NovaAccessibilityService.instance?.takeScreenshot()
                    "ui.recent" -> NovaAccessibilityService.instance?.performGlobalAction(
                        android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_RECENTS)
                    "ui.quick_settings" -> NovaAccessibilityService.instance?.performGlobalAction(
                        android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS)
                    "media.volume_up" -> {
                        val am=getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
                        am.adjustVolume(android.media.AudioManager.ADJUST_RAISE, android.media.AudioManager.FLAG_SHOW_UI)
                    }
                    "media.volume_down" -> {
                        val am=getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
                        am.adjustVolume(android.media.AudioManager.ADJUST_LOWER, android.media.AudioManager.FLAG_SHOW_UI)
                    }
                    "media.mute" -> {
                        val am=getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
                        am.adjustVolume(android.media.AudioManager.ADJUST_MUTE, android.media.AudioManager.FLAG_SHOW_UI)
                    }

                    "app.open" -> openAppByName(args.optString("app_name"))
                    "app.open_package" -> {
                        val pkg = args.optString("package_name")
                        if (pkg.isNotBlank()) packageManager.getLaunchIntentForPackage(pkg)?.let { openIntent(it) }
                    }
                    "app.youtube_search" -> openUrl("https://www.youtube.com/results?search_query=" + enc(args.optString("query")))
                    "app.google_search" -> openUrl("https://www.google.com/search?q=" + enc(args.optString("query")))
                    "whatsapp.open_chat" -> {
                        val num = args.optString("number").filter { it.isDigit() || it == '+' }
                        val msg = args.optString("message")
                        val autoSend = args.optBoolean("auto_send", false)
                        val url = "https://wa.me/$num" + if (msg.isNotBlank()) "?text=" + enc(msg) else ""
                        openUrl(url)
                        if (autoSend && msg.isNotBlank()) {
                            // Give WhatsApp time to open and lay out the chat before
                            // trying to find the Send button; icon-only, so we match
                            // by contentDescription rather than visible text.
                            mainHandler.postDelayed({
                                val svc = NovaAccessibilityService.instance
                                var sent = svc?.clickByDescription("Send") ?: false
                                if (!sent) sent = svc?.clickByDescription("යවන්න") ?: false
                                if (!sent) NovaBus.lastError = "whatsapp_send_button_not_found"
                            }, 2200)
                        }
                    }
                    "call.dial" -> {
                        val num = args.optString("number")
                        openIntent(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$num")))
                    }
                    "settings.open_wifi" -> openIntent(Intent(Settings.ACTION_WIFI_SETTINGS))
                    "settings.open_data" -> openIntent(Intent(Settings.ACTION_WIRELESS_SETTINGS))
                    "settings.open_bluetooth" -> openIntent(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
                    "settings.open_general" -> openIntent(Intent(Settings.ACTION_SETTINGS))
                    // call.place is HIGH risk and the backend never auto-queues it without
                    // on-phone confirmation, so there is intentionally no auto-dial path here.
                }
            } catch (_: Exception) { /* skip a malformed single action, don't crash the loop */ }
        }
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private fun openUrl(url: String) {
        openIntent(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
    }

    private fun openIntent(intent: Intent) {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { startActivity(intent) } catch (_: Exception) { }
    }

    private fun openAppByName(name: String) {
        if (name.isBlank()) return
        val pm = packageManager
        val apps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
        val target = apps.firstOrNull {
            pm.getApplicationLabel(it).toString().contains(name, ignoreCase = true)
        } ?: return
        pm.getLaunchIntentForPackage(target.packageName)?.let { openIntent(it) }
    }

    // ---------- TTS ----------

    private fun speak(s: String) {
        mainHandler.post {
            NovaBus.state = NovaState.SPEAKING
            updateNotification("කතා කරනවා...")
            tts.setSpeechRate(lastRate)
            tts.setPitch(lastPitch)
            tts.speak(s, TextToSpeech.QUEUE_FLUSH, null, "nova")
        }
        mainHandler.postDelayed({ if (running) listen() }, estimateSpeechMs(s))
    }

    private fun speakWithoutResumingListen(s: String) {
        mainHandler.post {
            NovaBus.state = NovaState.EXECUTING
            updateNotification("කරගෙන යනවා...")
            tts.setSpeechRate(lastRate)
            tts.setPitch(lastPitch)
            tts.speak(s, TextToSpeech.QUEUE_FLUSH, null, "nova")
        }
    }

    private fun estimateSpeechMs(s: String): Long = (s.length * 70L).coerceIn(1200L, 12000L)

    override fun onInit(s: Int) {
        if (s == TextToSpeech.SUCCESS) {
            tts.language = Locale("si", "LK")
        }
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        // No-op on purpose: android:stopWithTask="false" + this override keep
        // Nova running after the app is swiped away from Recents.
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        instance = null
        running = false
        NovaBus.isServiceRunning = false
        NovaBus.state = NovaState.OFFLINE
        sr?.destroy()
        tts.shutdown()
        super.onDestroy()
    }

    override fun onBind(i: Intent?): IBinder? = null
}
